"""Body orientation: IAU rotation elements and sub-observer geometry.

What a textured disk needs, per body and instant:

* the **sub-observer point** (planetographic longitude and latitude of the
  point at the centre of the apparent disk) — this is what decides which
  part of the map faces us;
* the **position angle of the north pole** on the sky, so the map is drawn
  the right way up;
* the sub-solar point, which together with the phase angle places the
  terminator.

Rotation elements are the IAU WGCCRE 2015 set (Archinal et al., *Celest.
Mech. Dyn. Astr.* 130:22, 2018): a fixed pole (α₀, δ₀) with a linear
secular drift plus a linear prime-meridian angle W.  The small periodic
libration terms (milli-degree level for the planets) are omitted, so the
orientation is **display grade**: good to a few hundredths of a degree in
pole direction and to ~0.05° in central-meridian longitude over a decade,
which is far below what a rendered disk can show.

Two bodies are not handled here because the package already carries
better, classical solutions for them:

* the **Moon** — :func:`astrarium.bodies.moon_info` returns the optical
  libration (= the selenographic longitude/latitude of the sub-Earth
  point) and the axis position angle from Meeus ch. 53;
* the **Sun** — :func:`astrarium.bodies.sun_axis` returns P, B₀ and the
  Carrington longitude L₀ from Meeus ch. 29.

Longitude convention
--------------------
``sub_observer()`` reports **planetographic** longitude, i.e. the one used
to label maps: it increases *westward* for a prograde rotator (Mercury,
Mars, Jupiter, Saturn, Neptune) and *eastward* for the retrograde ones
(Venus, Uranus), following the IAU definition.  ``lon_east_deg`` is also
returned because most modern image maps are gridded in east longitude.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

import erfa
import numpy as np

from .constants import JD_J2000
from .ephemeris import Ephemeris
from .frames import observer_bary_pv
from .timescale import Time

# IAU WGCCRE 2015: alpha0, delta0 [deg] with per-century drift, W0 [deg]
# and the rotation rate [deg/day].  Negative rate = retrograde.
IAU_ROTATION = {
    "mercury": dict(a0=281.0103, a0_T=-0.0328, d0=61.4155, d0_T=-0.0049,
                    w0=329.5988, wdot=6.1385108),
    "venus": dict(a0=272.76, a0_T=0.0, d0=67.16, d0_T=0.0,
                  w0=160.20, wdot=-1.4813688),
    "mars": dict(a0=317.269202, a0_T=-0.10927547, d0=54.432516,
                 d0_T=-0.05827105, w0=176.049863, wdot=350.891982443297),
    "jupiter": dict(a0=268.056595, a0_T=-0.006499, d0=64.495303,
                    d0_T=0.002413, w0=284.95, wdot=870.5360000),   # Sys III
    "saturn": dict(a0=40.589, a0_T=-0.036, d0=83.537, d0_T=-0.004,
                   w0=38.90, wdot=810.7939024),
    "uranus": dict(a0=257.311, a0_T=0.0, d0=-15.175, d0_T=0.0,
                   w0=203.81, wdot=-501.1600928),
    "neptune": dict(a0=299.36, a0_T=0.0, d0=43.46, d0_T=0.0,
                    w0=253.18, wdot=536.3128492),
}

# rotation sense, for the planetographic longitude convention
PROGRADE = {"mercury": True, "venus": False, "mars": True, "jupiter": True,
            "saturn": True, "uranus": False, "neptune": True}


@dataclass
class Orientation:
    """Sub-observer / sub-solar geometry of a body at one instant."""
    body: str
    lon_deg: float          # planetographic longitude of the disk centre
    lat_deg: float          # planetographic (≈ planetocentric) latitude
    lon_east_deg: float     # same point in east longitude
    pole_pa_deg: float      # PA of the north pole on the sky (N through E)
    sub_solar_lon_deg: float
    sub_solar_lat_deg: float
    np_ra_deg: float        # ICRF direction of the north pole
    np_dec_deg: float


def pole_vector(body: str, t: Time):
    """ICRF unit vector of the north pole, and (α₀, δ₀) in degrees."""
    e = IAU_ROTATION[body]
    T = (t.jd_tdb - JD_J2000) / 36525.0
    a0 = e["a0"] + e["a0_T"] * T
    d0 = e["d0"] + e["d0_T"] * T
    return (np.asarray(erfa.s2c(math.radians(a0), math.radians(d0))),
            a0, d0)


def prime_meridian_deg(body: str, t: Time) -> float:
    """W: angle from the ascending node of the body equator to the prime
    meridian, measured along the equator in the direction of rotation."""
    e = IAU_ROTATION[body]
    d = t.jd_tdb - JD_J2000
    return (e["w0"] + e["wdot"] * d) % 360.0


def _body_fixed_lonlat(body, t, vec_icrf):
    """(east longitude, latitude) of an ICRF direction in the body frame."""
    pole, a0, d0 = pole_vector(body, t)
    w = math.radians(prime_meridian_deg(body, t))
    # body-frame basis: z = pole, x = prime meridian, y = z x x
    node = np.cross(np.array([0.0, 0.0, 1.0]), pole)      # ICRF Z x pole
    n = np.linalg.norm(node)
    node = node / n if n > 1e-12 else np.array([1.0, 0.0, 0.0])
    east = np.cross(pole, node)
    x = node * math.cos(w) + east * math.sin(w)
    y = np.cross(pole, x)
    u = np.asarray(vec_icrf, dtype=float)
    u = u / np.linalg.norm(u)
    lon = math.degrees(math.atan2(float(np.dot(u, y)),
                                  float(np.dot(u, x)))) % 360.0
    lat = math.degrees(math.asin(max(-1.0, min(1.0, float(np.dot(u, pole))))))
    return lon, lat


def _pa_of_vector(vec_icrf, ra_rad, dec_rad) -> float:
    """Position angle (N through E) of a direction projected on the sky
    around the apparent place (ra, dec)."""
    v = np.asarray(vec_icrf, dtype=float)
    v = v / np.linalg.norm(v)
    north = np.array([-math.sin(dec_rad) * math.cos(ra_rad),
                      -math.sin(dec_rad) * math.sin(ra_rad),
                      math.cos(dec_rad)])
    east = np.array([-math.sin(ra_rad), math.cos(ra_rad), 0.0])
    return math.degrees(math.atan2(float(np.dot(v, east)),
                                   float(np.dot(v, north)))) % 360.0


def sub_observer(eph: Ephemeris, body: str, t: Time, site=None,
                 ra_deg=None, dec_deg=None) -> Orientation:
    """Sub-observer and sub-solar geometry of ``body``.

    ``ra_deg``/``dec_deg`` are the apparent place used for the position
    angle; when omitted the astrometric direction is used, which differs
    by aberration only (< 20″, invisible at disk scale).
    """
    if body not in IAU_ROTATION:
        raise KeyError(f"no IAU rotation elements for {body!r}")
    d1, d2 = t.tdb
    po, _, _ = observer_bary_pv(eph, t, site)
    pb, _ = eph.pv_bary(body, d1, d2)
    ps, _ = eph.pv_bary("sun", d1, d2)
    po = np.asarray(po, dtype=float).reshape(3)
    pb = np.asarray(pb, dtype=float).reshape(3)
    ps = np.asarray(ps, dtype=float).reshape(3)

    to_obs = po - pb            # body -> observer
    to_sun = ps - pb            # body -> Sun
    lon_e, lat = _body_fixed_lonlat(body, t, to_obs)
    slon_e, slat = _body_fixed_lonlat(body, t, to_sun)

    # planetographic longitude: westward for prograde rotators
    def graphic(lon_east):
        return lon_east % 360.0 if not PROGRADE[body] \
            else (360.0 - lon_east) % 360.0

    v = pb - po
    if ra_deg is None:
        u = v / np.linalg.norm(v)
        ra = math.atan2(u[1], u[0])
        dec = math.asin(max(-1.0, min(1.0, u[2])))
    else:
        ra, dec = math.radians(ra_deg), math.radians(dec_deg)
    pole, a0, d0 = pole_vector(body, t)
    return Orientation(
        body=body,
        lon_deg=graphic(lon_e), lat_deg=lat, lon_east_deg=lon_e,
        pole_pa_deg=_pa_of_vector(pole, ra, dec),
        sub_solar_lon_deg=graphic(slon_e), sub_solar_lat_deg=slat,
        np_ra_deg=a0 % 360.0, np_dec_deg=d0)
