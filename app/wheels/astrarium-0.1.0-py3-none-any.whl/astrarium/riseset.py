"""Rise / set / transit / twilight solver (spec §2, §6).

Method: direct root-finding on the topocentric geometric altitude of the
body center computed through the full apparent-place chain (no hour-angle
approximation formulas), as required for the "≤ a few seconds" accuracy
goal (spec §11).  A coarse scan (default 6 min) brackets sign changes of
alt(t) - h0, then bisection refines each event to <0.5 s.

Standard altitudes h0 (Explanatory Supplement / Meeus ch.15):
- Sun rise/set:      -50'   (34' refraction + 16' semidiameter)
- Moon rise/set:     0.7275*π_moon - 34'  (π = horizontal parallax;
                     accounts for the topocentric upper-limb convention)
- Stars/planets:     -34'
- Twilights (sun):   -6°/-12°/-18° (civil/nautical/astronomical),
                     geometric center, no refraction term.

Polar day/night: events may be absent; `DayArc` reports 'always_up' /
'always_down' explicitly (spec §6: 白夜・極夜は「なし」).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .constants import AU_KM
from .ephemeris import Ephemeris
from .frames import observe_body, observe_star
from .observer import Site
from .timescale import Time

SUN_H0 = -50.0 / 60.0
STAR_H0 = -34.0 / 60.0
TWILIGHT = {"civil": -6.0, "nautical": -12.0, "astronomical": -18.0}


# ---------------------------------------------------------------------------
@dataclass
class Event:
    kind: str          # 'rise' | 'set' | 'transit' | e.g. 'astronomical_dusk'
    time: Time
    az: float | None = None
    alt: float | None = None


@dataclass
class DayArc:
    """Rise/set/transit summary for one interval (usually one local day)."""
    body: str
    events: list = field(default_factory=list)
    always_up: bool = False
    always_down: bool = False

    def first(self, kind):
        for e in self.events:
            if e.kind == kind:
                return e
        return None


# ---------------------------------------------------------------------------
def _bisect(f, ta, tb, fa, tol_days=0.5 / 86400.0, maxit=60):
    """Root of scalar f between ta/tb (f(ta)=fa known, sign change assumed)."""
    for _ in range(maxit):
        tm = 0.5 * (ta + tb)
        fm = f(tm)
        if (fa < 0) == (fm < 0):
            ta, fa = tm, fm
        else:
            tb = tm
        if tb - ta < tol_days:
            break
    return 0.5 * (ta + tb)


def find_crossings(f_vec, t0: Time, t1: Time, n=None, step_min=6.0,
                   refine_tol_s=0.5, max_jump=90.0):
    """All roots of f(t)=0 in [t0,t1].

    f_vec: vectorized callable mapping jd-offset array (days from t0) to
    values.  Returns list of (jd_offset_days, direction) with direction
    +1 rising through zero, -1 falling.

    max_jump: sign changes accompanied by |Δy| larger than this are
    treated as wrap-around discontinuities of angle-valued functions
    (e.g. ±180° jumps) and skipped, not roots.
    """
    span = t1 - t0
    if n is None:
        n = max(int(span * 1440.0 / step_min) + 1, 8)
    x = np.linspace(0.0, span, n)
    y = f_vec(x)
    roots = []
    sign = np.sign(y)
    candidates = np.nonzero(sign[:-1] * sign[1:] < 0)[0]
    for i in candidates:
        if max_jump is not None and abs(y[i + 1] - y[i]) > max_jump:
            continue
        r = _bisect(lambda d: float(f_vec(np.array([d]))[0]),
                    x[i], x[i + 1], float(y[i]),
                    tol_days=refine_tol_s / 86400.0)
        roots.append((r, +1 if y[i] < 0 else -1))
    # exact zeros at grid points (rare)
    for i in np.nonzero(sign == 0)[0]:
        roots.append((float(x[i]), 0))
    return sorted(roots)


# ---------------------------------------------------------------------------
def _alt_func(eph, body, site, star=None):
    """Vectorized geometric-altitude function relative to a start Time."""
    def make(t_start: Time):
        def f(offset_days):
            t = Time(t_start.tt1, t_start.tt2 + np.asarray(offset_days))
            if star is not None:
                p = observe_star(star[0], star[1], t, site, refraction=False,
                                 pmra_mas_yr=star[2] if len(star) > 2 else 0.0,
                                 pmdec_mas_yr=star[3] if len(star) > 3 else 0.0)
            else:
                p = observe_body(eph, body, t, site, refraction=False)
            return np.atleast_1d(p.alt)
        return f
    return make


def moon_h0(eph: Ephemeris, time: Time, site: Site) -> float:
    """Standard altitude for moonrise/set: 0.7275*parallax - 34'."""
    p = observe_body(eph, "moon", time, site=None)
    dist_km = float(np.atleast_1d(p.distance_au)[0]) * AU_KM
    import math
    par = math.degrees(math.asin(6378.1366 / dist_km))
    return 0.7275 * par - 34.0 / 60.0


def rise_set(eph: Ephemeris, body: str, site: Site, t0: Time, t1: Time,
             h0: float | None = None, star=None,
             use_horizon_mask: bool = False) -> DayArc:
    """Rise/set/transit events for [t0, t1] (typically one local day).

    body: ephemeris name, or 'star' with star=(ra_deg, dec_deg[, pmra, pmdec]).
    h0: standard altitude override [deg]; default per body type.
    use_horizon_mask: use the site's terrain mask instead of h0.
    """
    if h0 is None:
        h0 = SUN_H0 if body == "sun" else (
            moon_h0(eph, t0, site) if body == "moon" else STAR_H0)

    make = _alt_func(eph, body, site, star)
    f = make(t0)

    if use_horizon_mask and site.horizon is not None:
        # subtract the mask altitude at the instantaneous azimuth
        base = f

        def f_masked(off):
            t = Time(t0.tt1, t0.tt2 + np.asarray(off))
            p = (observe_star(star[0], star[1], t, site, refraction=False)
                 if star is not None else
                 observe_body(eph, body, t, site, refraction=False))
            return np.atleast_1d(p.alt - site.horizon.min_alt(p.az))
        g = f_masked
    else:
        def g(off):
            return f(off) - h0

    arc = DayArc(body=body)
    roots = find_crossings(g, t0, t1)
    for r, direction in roots:
        t = t0 + r
        p = (observe_star(star[0], star[1], t, site, refraction=False)
             if star is not None else
             observe_body(eph, body, t, site, refraction=False))
        arc.events.append(Event("rise" if direction > 0 else "set", t,
                                az=float(np.atleast_1d(p.az)[0]),
                                alt=float(np.atleast_1d(p.alt)[0])))
    # transits: local hour angle crossing 0 (upper culmination)
    for tt, alt in _transits(eph, body, site, t0, t1, star):
        arc.events.append(Event("transit", tt, alt=alt))
    arc.events.sort(key=lambda e: e.time.jd_tt)
    if not roots:
        mid = g(np.array([0.5 * (t1 - t0)]))[0]
        arc.always_up = mid > 0
        arc.always_down = mid <= 0
    return arc


def _transits(eph, body, site, t0, t1, star=None):
    """Upper culminations via sin(HA)=0 with cos(HA)>0 rejection."""
    def ha_sin(off):
        t = Time(t0.tt1, t0.tt2 + np.asarray(off))
        p = (observe_star(star[0], star[1], t, site, refraction=False)
             if star is not None else
             observe_body(eph, body, t, site, refraction=False))
        ha = np.atleast_1d(p.hour_angle_h) * np.pi / 12.0
        return np.sin(ha), np.cos(ha)

    def f(off):
        s, c = ha_sin(off)
        return s

    out = []
    for r, direction in find_crossings(f, t0, t1, step_min=20.0):
        s, c = ha_sin(np.array([r]))
        if c[0] > 0:  # upper transit: HA goes -0+ (sin rising through 0)
            t = t0 + r
            p = (observe_star(star[0], star[1], t, site, refraction=False)
                 if star is not None else
                 observe_body(eph, body, t, site, refraction=False))
            out.append((t, float(np.atleast_1d(p.alt)[0])))
    return out


# ---------------------------------------------------------------------------
def twilight_times(eph: Ephemeris, site: Site, t0: Time, t1: Time) -> dict:
    """Sunrise/set + all twilight boundaries within [t0, t1].

    Returns dict with keys 'sunrise','sunset', '<kind>_dawn','<kind>_dusk'
    -> list[Time] (may be empty at high latitude: 白夜/極夜 -> なし).
    """
    make = _alt_func(eph, "sun", site)
    f = make(t0)
    out = {"sunrise": [], "sunset": []}
    for r, d in find_crossings(lambda o: f(o) - SUN_H0, t0, t1):
        out["sunrise" if d > 0 else "sunset"].append(t0 + r)
    for kind, h in TWILIGHT.items():
        dawn, dusk = [], []
        for r, d in find_crossings(lambda o: f(o) - h, t0, t1):
            (dawn if d > 0 else dusk).append(t0 + r)
        out[f"{kind}_dawn"] = dawn      # sun rising through h
        out[f"{kind}_dusk"] = dusk      # sun setting through h
    return out


def dark_windows(eph: Ephemeris, site: Site, t0: Time, t1: Time,
                 moon_alt_limit=0.0) -> list[tuple]:
    """実質的な暗夜時間: astronomical night minus moon-up time (spec §6).

    Returns list of (start Time, end Time) with sun < -18° and moon
    below moon_alt_limit.
    """
    make_s = _alt_func(eph, "sun", site)
    make_m = _alt_func(eph, "moon", site)
    fs, fm = make_s(t0), make_m(t0)
    span = t1 - t0
    n = max(int(span * 1440 / 5) + 1, 16)
    x = np.linspace(0, span, n)
    ok = (fs(x) < -18.0) & (fm(x) < moon_alt_limit)

    def refine(a, b):
        # boundary between grid points: bisect on combined condition
        def cond(t):
            return (float(fs(np.array([t]))[0]) < -18.0 and
                    float(fm(np.array([t]))[0]) < moon_alt_limit)
        for _ in range(20):
            m = 0.5 * (a + b)
            if cond(m) == cond(a):
                a = m
            else:
                b = m
        return 0.5 * (a + b)

    windows = []
    i = 0
    while i < n:
        if ok[i]:
            j = i
            while j + 1 < n and ok[j + 1]:
                j += 1
            a = x[i] if i == 0 else refine(x[i - 1], x[i])
            b = x[j] if j == n - 1 else refine(x[j], x[j + 1])
            windows.append((t0 + a, t0 + b))
            i = j + 1
        else:
            i += 1
    return windows
