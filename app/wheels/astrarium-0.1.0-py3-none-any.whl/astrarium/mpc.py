"""MPC / JPL small-body element retrieval & local registry (spec §2, §10).

- Comets: MPC "Observable Comets" file CometEls.txt (Export Format for
  Cometary Orbits, fixed columns).  The MPC magnitude slope column G is
  the activity exponent n; our comet law m1 = M1 + 5 logΔ + K1·log r
  uses K1 = 2.5·G.
- Asteroids: brightest numbered asteroids from the JPL SBDB Query API
  (element set equivalent to MPCORB; sorted by absolute magnitude H) —
  fetching all of MPCORB.DAT (~200 MB) is deliberately avoided.  MPCORB
  one-line rows can always be registered manually via
  orbits.Elements.from_mpc_1line.

Everything fetched is cached as JSON under data/mpc/ and reloaded from
there (offline operation, spec §10); each file records its retrieval
time.
"""
from __future__ import annotations

import json
import math
import os
import subprocess
import time as _time

import erfa

from .orbits import Elements

from .paths import data_path
_DATA = data_path("mpc")
COMETS_URL = "https://www.minorplanetcenter.net/iau/MPCORB/CometEls.txt"
SBDB_URL = ("https://ssd-api.jpl.nasa.gov/sbdb_query.api?"
            "fields=pdes,name,epoch,e,q,i,om,w,tp,H,G"
            "&sb-kind=a&sb-ns=n&sort=H&limit={limit}&full-prec=1")


def _download(url: str, timeout=180) -> str:
    """Fetch text via the system curl (anaconda's libcurl is broken on
    this host; /usr/bin/curl is reliable)."""
    r = subprocess.run(["/usr/bin/curl", "-sS", "--max-time", str(timeout),
                        url], capture_output=True, text=True)
    if r.returncode != 0 or not r.stdout:
        raise ConnectionError(f"download failed: {url}: {r.stderr[:200]}")
    return r.stdout


# ---------------------------------------------------------------------------
# comets (MPC)
# ---------------------------------------------------------------------------
def parse_comet_line(line: str) -> dict | None:
    """One row of CometEls.txt -> element dict (angles deg, ecliptic
    J2000, tp as TT JD).  Returns None for unparsable rows."""
    try:
        year = int(line[14:18])
        month = int(line[19:21])
        day = float(line[22:29])
        q = float(line[30:39])
        e = float(line[41:49])
        argp = float(line[51:59])
        node = float(line[60:69])
        incl = float(line[69:80])
        m1 = line[91:95].strip()
        g = line[96:100].strip()
        name = line[102:158].strip()
        d1, d2 = erfa.cal2jd(year, month, int(day))
        tp = d1 + d2 + (day - int(day))   # cal2jd -> JD at 0h TT
        num = line[0:4].strip()
        typ = line[4]
        return {
            "name": name or f"{num}{typ}",
            "kind": "comet",
            "q_au": q, "e": e, "incl_deg": incl, "node_deg": node,
            "argp_deg": argp, "tp_jd_tt": tp,
            "M1": float(m1) if m1 else None,
            "K1": 2.5 * float(g) if g else 10.0,   # MPC G = n
            "periodic": typ == "P",
        }
    except (ValueError, IndexError):
        return None


def fetch_comets(save: bool = True) -> list[dict]:
    """Download the current MPC comet file; cache to data/mpc/comets.json."""
    txt = _download(COMETS_URL)
    rows = [d for d in (parse_comet_line(l) for l in txt.splitlines())
            if d is not None and d["q_au"] > 0]
    payload = {"fetched_utc": _time.strftime("%Y-%m-%dT%H:%M:%SZ",
                                             _time.gmtime()),
               "source": COMETS_URL, "objects": rows}
    if save:
        os.makedirs(_DATA, exist_ok=True)
        with open(os.path.join(_DATA, "comets.json"), "w",
                  encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=0)
    return rows


# ---------------------------------------------------------------------------
# asteroids (JPL SBDB, MPCORB-equivalent elements)
# ---------------------------------------------------------------------------
def rows_from_sbdb_query(fields: list, data: list) -> list[dict]:
    """SBDB query columns -> element dicts.

    Split out from the download so the same parsing serves the offline
    build, where the page (or the native host) makes the request and
    only the text arrives here.
    """
    ix = {k: fields.index(k) for k in fields}
    rows = []
    for r in data:
        def g(k):
            v = r[ix[k]]
            return None if v is None else float(v)
        try:
            rows.append({
                "name": (r[ix["name"]] or r[ix["pdes"]]).strip(),
                "pdes": r[ix["pdes"]],
                "kind": "asteroid",
                "q_au": g("q"), "e": g("e"), "incl_deg": g("i"),
                "node_deg": g("om"), "argp_deg": g("w"),
                "tp_jd_tt": g("tp"), "epoch_jd_tt": g("epoch"),
                "H": g("H"), "G": g("G") if g("G") is not None else 0.15,
            })
        except (TypeError, ValueError, IndexError):
            continue
    return rows


def fetch_bright_asteroids(limit: int = 1000, save: bool = True) -> list[dict]:
    """Brightest `limit` numbered asteroids by H from JPL SBDB."""
    raw = json.loads(_download(SBDB_URL.format(limit=limit), timeout=300))
    rows = rows_from_sbdb_query(raw["fields"], raw["data"])
    payload = {"fetched_utc": _time.strftime("%Y-%m-%dT%H:%M:%SZ",
                                             _time.gmtime()),
               "source": "JPL SBDB Query API (MPC-equivalent elements)",
               "objects": rows}
    if save:
        os.makedirs(_DATA, exist_ok=True)
        with open(os.path.join(_DATA, "asteroids.json"), "w",
                  encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=0)
    return rows


# ---------------------------------------------------------------------------
# registry
# ---------------------------------------------------------------------------
class SmallBodyRegistry:
    """Loads cached MPC/SBDB files and serves Elements by id."""

    def __init__(self, data_dir: str | None = None):
        self.dir = data_dir or _DATA
        self.reload()

    def reload(self):
        self.comets: list[dict] = []
        self.asteroids: list[dict] = []
        self.fetched = {}
        for kind in ("comets", "asteroids"):
            p = os.path.join(self.dir, f"{kind}.json")
            if os.path.exists(p):
                with open(p, encoding="utf-8") as f:
                    d = json.load(f)
                setattr(self, kind, d.get("objects", []))
                self.fetched[kind] = d.get("fetched_utc")

    def update(self, kinds=("comets", "asteroids"), limit=1000):
        if "comets" in kinds:
            fetch_comets(save=True)
        if "asteroids" in kinds:
            fetch_bright_asteroids(limit=limit, save=True)
        self.reload()

    def catalog(self, kind: str) -> list[dict]:
        """id + display info for the UI list."""
        src = self.comets if kind == "comet" else self.asteroids
        out = []
        for i, o in enumerate(src):
            out.append({"id": f"{kind}:{i}", "name": o["name"],
                        "q_au": o.get("q_au"), "e": o.get("e"),
                        "mag_param": o.get("M1", o.get("H"))})
        return out

    def search(self, query: str, kind: str | None = None) -> list[dict]:
        q = query.casefold()
        out = []
        for k in (["comet", "asteroid"] if kind is None else [kind]):
            out += [c for c in self.catalog(k)
                    if q in c["name"].casefold()]
        return out

    def elements(self, obj_id: str) -> Elements:
        kind, idx = obj_id.split(":")
        o = (self.comets if kind == "comet" else self.asteroids)[int(idx)]
        return Elements(
            q_au=o["q_au"], e=o["e"], incl_deg=o["incl_deg"],
            node_deg=o["node_deg"], argp_deg=o["argp_deg"],
            tp_jd_tdb=o["tp_jd_tt"], name=o["name"],
            H=o.get("H"), G=o.get("G", 0.15),
            M1=o.get("M1"), K1=o.get("K1"),
            kind="comet" if kind == "comet" else "asteroid",
            epoch_jd_tdb=o.get("epoch_jd_tt"))
