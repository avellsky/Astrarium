"""Japanese calendar: 旧暦 (lunisolar date), 二十四節気 and 六曜.

The modern 旧暦 is the 天保暦 rule set, evaluated from the *true*
(apparent) geocentric longitudes of the Sun and Moon — the same ones the
rest of this package computes from the DE ephemeris — with all day
boundaries taken in Japan Standard Time (UTC+9):

* A month begins on the JST calendar day that contains the new moon (朔).
* 中気 are the apparent solar longitudes at multiples of 30°
  (冬至 = 270°); the intermediate 15° multiples are 節気.  Together they
  are the 二十四節気.
* The month containing 冬至 is the 11th month.  Between two consecutive
  11th months there are 12 or 13 months; in the 13-month case the first
  month that contains no 中気 becomes the leap month (閏月) and repeats
  the number of the month before it.
* 六曜 follows from the lunisolar date alone:
  (month + day) mod 6 -> 大安/赤口/先勝/友引/先負/仏滅.

Verified against the 国立天文台 暦要項 values in tests/test_koyomi.py
(新月・節気 times to the minute, 旧暦 dates and 六曜 exactly).

The zone matters: the same instant can fall on different JST and UTC
days, so a 旧暦 date is only defined with respect to Japan Standard Time.
That is deliberate — 旧暦 and 六曜 are Japanese civil conventions.
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass

import numpy as np

from .ephemeris import Ephemeris
from .frames import observe_body
from .timescale import Time

JST = _dt.timezone(_dt.timedelta(hours=9))

# 二十四節気: apparent solar longitude -> (key, 日本語, English)
SOLAR_TERMS = [
    (315, "risshun", "立春", "Start of spring"),
    (330, "usui", "雨水", "Rain water"),
    (345, "keichitsu", "啓蟄", "Awakening of insects"),
    (0, "shunbun", "春分", "Vernal equinox"),
    (15, "seimei", "清明", "Pure brightness"),
    (30, "kokuu", "穀雨", "Grain rain"),
    (45, "rikka", "立夏", "Start of summer"),
    (60, "shoman", "小満", "Grain full"),
    (75, "boshu", "芒種", "Grain in ear"),
    (90, "geshi", "夏至", "Summer solstice"),
    (105, "shosho", "小暑", "Minor heat"),
    (120, "taisho", "大暑", "Major heat"),
    (135, "risshu", "立秋", "Start of autumn"),
    (150, "shosho2", "処暑", "End of heat"),
    (165, "hakuro", "白露", "White dew"),
    (180, "shubun", "秋分", "Autumnal equinox"),
    (195, "kanro", "寒露", "Cold dew"),
    (210, "soko", "霜降", "Frost descent"),
    (225, "ritto", "立冬", "Start of winter"),
    (240, "shosetsu", "小雪", "Minor snow"),
    (255, "taisetsu", "大雪", "Major snow"),
    (270, "toji", "冬至", "Winter solstice"),
    (285, "shokan", "小寒", "Minor cold"),
    (300, "daikan", "大寒", "Major cold"),
]
_TERM_BY_LON = {lon: (k, ja, en) for lon, k, ja, en in SOLAR_TERMS}

# 六曜, indexed by (lunisolar month + day) mod 6
ROKUYO = [("taian", "大安"), ("shakko", "赤口"), ("sensho", "先勝"),
          ("tomobiki", "友引"), ("sakimake", "先負"), ("butsumetsu", "仏滅")]
ROKUYO_EN = {"taian": "Taian (most auspicious)",
             "shakko": "Shakkō (noon only)",
             "sensho": "Senshō (morning good)",
             "tomobiki": "Tomobiki (avoid funerals)",
             "sakimake": "Sakimake (afternoon good)",
             "butsumetsu": "Butsumetsu (least auspicious)"}


# ---------------------------------------------------------------------------
# basic instants
# ---------------------------------------------------------------------------
def jst_date(t: Time) -> _dt.date:
    """Calendar date in Japan Standard Time of an instant."""
    return t.datetime_utc().astimezone(JST).date()


def _sun_lon(eph: Ephemeris, t0: Time):
    def f(off):
        t = Time(t0.tt1, t0.tt2 + np.asarray(off))
        p = observe_body(eph, "sun", t, site=None, refraction=False)
        lam, _ = p.ecliptic(apparent=True)
        return np.asarray(lam)
    return f


def solar_term_crossing(eph: Ephemeris, lon_deg: float, t0: Time,
                        t1: Time) -> list[Time]:
    """Instants in [t0, t1] where the apparent solar longitude passes
    ``lon_deg`` (increasing)."""
    from .phenomena import find_crossings
    lam = _sun_lon(eph, t0)

    def f(off):
        return (lam(off) - lon_deg + 180.0) % 360.0 - 180.0

    return [t0 + r for r, d in find_crossings(f, t0, t1, step_min=1440.0)
            if d > 0]


def solar_terms(eph: Ephemeris, t0: Time, t1: Time) -> list[tuple]:
    """All 二十四節気 in [t0, t1] as (Time, key, ja, en), sorted."""
    out = []
    for lon, key, ja, en in SOLAR_TERMS:
        for t in solar_term_crossing(eph, lon, t0, t1):
            out.append((t, key, ja, en))
    out.sort(key=lambda x: x[0].jd_tt)
    return out


def new_moons(eph: Ephemeris, t0: Time, t1: Time) -> list[Time]:
    from .phenomena import find_moon_phases
    return [p.time for p in find_moon_phases(eph, t0, t1)
            if p.kind == "new_moon"]


# ---------------------------------------------------------------------------
# 旧暦
# ---------------------------------------------------------------------------
@dataclass
class LunisolarDate:
    year: int                  # 旧暦の年 (month 1 falls in this year)
    month: int                 # 1-12
    leap: bool                 # 閏月
    day: int                   # 1-30
    rokuyo_key: str
    rokuyo_ja: str
    month_start: _dt.date      # JST date the month begins on

    def label_ja(self) -> str:
        return (f"{self.year}年{'閏' if self.leap else ''}"
                f"{self.month}月{self.day}日")

    def label_en(self) -> str:
        return (f"{self.year}-{'i' if self.leap else ''}"
                f"{self.month:02d}-{self.day:02d}")


def _cycle(eph: Ephemeris, solstice_year: int) -> list[dict]:
    """Months of one 冬至-to-冬至 cycle starting in ``solstice_year``.

    Returns dicts {start: date, year, month, leap} covering the 11th
    month of that winter through the month before the next 11th month.
    """
    # the two winter solstices that bound the cycle
    w0 = solar_term_crossing(
        eph, 270, Time.from_utc(f"{solstice_year}-11-15T00:00:00"),
        Time.from_utc(f"{solstice_year + 1}-01-20T00:00:00"))[0]
    w1 = solar_term_crossing(
        eph, 270, Time.from_utc(f"{solstice_year + 1}-11-15T00:00:00"),
        Time.from_utc(f"{solstice_year + 2}-01-20T00:00:00"))[0]

    nm = new_moons(eph, w0 - 45.0, w1 + 45.0)
    starts = [jst_date(t) for t in nm]
    w0d, w1d = jst_date(w0), jst_date(w1)

    def month_index(day):
        """index of the month containing a JST date"""
        idx = None
        for i, s in enumerate(starts):
            if s <= day:
                idx = i
            else:
                break
        return idx

    i0, i1 = month_index(w0d), month_index(w1d)
    if i0 is None or i1 is None or i1 <= i0:
        raise ValueError("cannot bracket the 冬至 months")
    months = []
    for i in range(i0, i1 + 1):
        end = starts[i + 1] if i + 1 < len(starts) else starts[i] + \
            _dt.timedelta(days=31)
        months.append({"start": starts[i], "end": end})

    n = i1 - i0                      # months in the cycle (12 or 13)
    if n == 13:
        # 中気 = solar longitudes at multiples of 30 deg
        chuki = []
        for lon in range(0, 360, 30):
            chuki += [jst_date(t) for t in
                      solar_term_crossing(eph, lon, w0 - 45.0, w1 + 45.0)]
        leap_at = None
        for k in range(1, n):        # never the 11th month itself
            m = months[k]
            if not any(m["start"] <= c < m["end"] for c in chuki):
                leap_at = k
                break
        if leap_at is None:          # no ambiguous month: no leap
            leap_at = -1
    else:
        leap_at = -1

    num, year, prev = 11, solstice_year, None
    for k, m in enumerate(months[:n]):
        if k == leap_at and prev is not None:
            m["year"], m["month"], m["leap"] = prev[0], prev[1], True
        else:
            m["year"], m["month"], m["leap"] = year, num, False
            prev = (year, num)
            num += 1
            if num == 13:
                num, year = 1, year + 1
    return months[:n]


_cycle_cache: dict[int, list] = {}


def lunisolar(eph: Ephemeris, day: _dt.date) -> LunisolarDate:
    """旧暦 date (and 六曜) of a JST calendar day."""
    # the cycle that contains `day` starts at the 冬至 of this year or the
    # previous one, depending on where in the year `day` falls
    for sy in (day.year, day.year - 1, day.year - 2):
        if sy not in _cycle_cache:
            _cycle_cache[sy] = _cycle(eph, sy)
        months = _cycle_cache[sy]
        if months[0]["start"] <= day < months[-1]["end"]:
            for m in months:
                if m["start"] <= day < m["end"]:
                    d = (day - m["start"]).days + 1
                    key, ja = ROKUYO[(m["month"] + d) % 6]
                    return LunisolarDate(m["year"], m["month"], m["leap"],
                                         d, key, ja, m["start"])
    raise ValueError(f"no lunisolar cycle covers {day}")


def current_and_next_term(eph: Ephemeris, t: Time):
    """(current, next) 二十四節気 as (Time, key, ja, en) around ``t``."""
    terms = solar_terms(eph, t - 35.0, t + 35.0)
    cur = nxt = None
    for e in terms:
        if e[0].jd_tt <= t.jd_tt:
            cur = e
        elif nxt is None:
            nxt = e
    return cur, nxt
