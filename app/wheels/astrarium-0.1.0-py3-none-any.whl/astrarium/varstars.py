"""Variable-star extremum predictions (spec §2).

GCVS/VSX-style elements: epoch (HJD, UTC-based legacy convention) +
period.  Event times: HJD_n = epoch + n·P, inverted through the
heliocentric Romer delay (lighttime.time_from_hjd_utc).  Eclipsing
binaries predict minima; pulsating stars predict maxima (per the
`event` field of the catalog entry).

Caveats surfaced in the data file: Mira periods are unstable (±20 d),
β Lyr's period lengthens, RR Lyr shows the Blazhko effect — the
prediction honors catalog elements only (spec §11: 周期予報はカタログ
精度に従う).
"""
from __future__ import annotations

import json
import math
import os
from dataclasses import dataclass

import numpy as np

from .ephemeris import Ephemeris
from .frames import observe_star
from .lighttime import time_from_hjd_utc
from .observer import Site
from .timescale import Time

from .paths import data_path
_DATA = data_path("variable_stars.json")


@dataclass
class VarStarEvent:
    star: dict
    kind: str            # 'min' | 'max'
    n_epoch: int
    time: Time
    hjd: float
    alt_deg: float | None = None
    note: str = ""


class VariableStarCatalog:
    def __init__(self, path: str | None = None):
        with open(path or _DATA, encoding="utf-8") as f:
            self.stars = json.load(f)["stars"]

    def add(self, star: dict):
        """Register a star: name, ra_deg, dec_deg, epoch_hjd,
        period_days, event ('min'|'max')."""
        self.stars.append(star)

    def phase(self, star: dict, time: Time, eph: Ephemeris) -> float:
        """Current phase in [0,1) relative to the element epoch."""
        from .lighttime import hjd_utc
        h = float(hjd_utc(eph, time, star["ra_deg"], star["dec_deg"]))
        return ((h - star["epoch_hjd"]) / star["period_days"]) % 1.0

    def events(self, eph: Ephemeris, t0: Time, t1: Time,
               site: Site | None = None, names=None) -> list[VarStarEvent]:
        out = []
        for st in self.stars:
            if names and st["name"] not in names:
                continue
            P = st["period_days"]
            h0 = t0.jd_utc - 0.02
            h1 = t1.jd_utc + 0.02
            n0 = math.ceil((h0 - st["epoch_hjd"]) / P)
            n1 = math.floor((h1 - st["epoch_hjd"]) / P)
            for n in range(n0, n1 + 1):
                hjd = st["epoch_hjd"] + n * P
                t = time_from_hjd_utc(eph, hjd, st["ra_deg"],
                                      st["dec_deg"], site)
                if not (t0.jd_tt <= t.jd_tt <= t1.jd_tt):
                    continue
                ev = VarStarEvent(star=st, kind=st.get("event", "min"),
                                  n_epoch=n, time=t, hjd=hjd,
                                  note=st.get("note", ""))
                if site is not None:
                    sp = observe_star(st["ra_deg"], st["dec_deg"], t,
                                      site, refraction=False)
                    ev.alt_deg = float(np.atleast_1d(sp.alt)[0])
                out.append(ev)
        out.sort(key=lambda e: e.time.jd_tt)
        return out
