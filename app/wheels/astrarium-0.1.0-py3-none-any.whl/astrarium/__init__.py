"""astrarium — research-grade digital planisphere & observation planner.

計算コア (spec §12): time / frames / ephem / observer / catalog / events /
eclipse / occult / plan / export モジュール構成。GUI (webapp/, cli) はコア
から分離。

Quick start:
    from astrarium import Ephemeris, Time, SiteDB, observe_planet
    eph = Ephemeris()
    site = SiteDB().get("jp-tokyo")
    mars = observe_planet(eph, "mars", Time.now(), site)
"""
from .bodies import BodyView, moon_info, observe_planet, sun_axis
from .ephemeris import Ephemeris, get_ephemeris
from .frames import (SkyPosition, angular_separation_deg, observe_body,
                     observe_star)
from .observer import HorizonMask, Site, SiteDB
from .timescale import EOP, Time
from .i18n import I18n

__version__ = "0.1.0"
__all__ = [
    "BodyView", "EOP", "Ephemeris", "HorizonMask", "I18n", "Site",
    "SiteDB", "SkyPosition", "Time", "angular_separation_deg",
    "get_ephemeris", "moon_info", "observe_body", "observe_planet",
    "observe_star", "sun_axis",
]
