"""Export formats: iCalendar, CSV, ephemeris tables, FITS WCS headers,
telescope GOTO payloads (spec §12: エクスポート / 連携).

- :func:`to_ics` — RFC 5545 iCalendar (CRLF line endings, 75-octet line
  folding per RFC 5545 §3.1) for events from :mod:`astrarium.scanner`
  / :mod:`astrarium.phenomena` etc., with a bilingual (ja/en) summary
  map for the known event kinds.
- :func:`to_csv` — RFC 4180-style CSV via the stdlib csv module.
- :func:`ephemeris_table` — tabulated ephemerides (rows of dicts) ready
  for :func:`to_csv`.
- :func:`to_fits_wcs_header` — hand-rolled FITS WCS cards (FITS Standard
  4.0 §4.1: 80-character keyword records; WCS Paper II, Calabretta &
  Greisen 2002, A&A 395, 1077 for CTYPE/CD conventions).  No astropy.
- :func:`telescope_goto_payload` — integration seam for SkySafari /
  ASCOM / INDI GOTO (documented stubs; real drivers are out of scope).
"""
from __future__ import annotations

import csv
import hashlib
import io

import numpy as np

from .bodies import observe_planet
from .ephemeris import Ephemeris
from .frames import observe_star
from .observer import Site
from .timescale import Time

# ---------------------------------------------------------------------------
# iCalendar
# ---------------------------------------------------------------------------
#: kind -> (Japanese, English) summary labels for the event kinds
#: produced by phenomena.py / eclipses.py / meteors.py / scanner.py
#: plus exoplanet/variable-star events (exoplanets.py, varstars.py).
EVENT_NAMES: dict[str, tuple[str, str]] = {
    # moon phases (phenomena.find_moon_phases)
    "new_moon": ("新月", "New Moon"),
    "first_quarter": ("上弦", "First Quarter"),
    "full_moon": ("満月", "Full Moon"),
    "last_quarter": ("下弦", "Last Quarter"),
    # lunar apsides
    "moon_perigee": ("月の近地点", "Lunar perigee"),
    "moon_apogee": ("月の遠地点", "Lunar apogee"),
    # seasons (phenomena.find_seasons)
    "march_equinox": ("春分", "March equinox"),
    "june_solstice": ("夏至", "June solstice"),
    "september_equinox": ("秋分", "September equinox"),
    "december_solstice": ("冬至", "December solstice"),
    # planetary configurations
    "conjunction": ("合", "Conjunction"),
    "inferior_conjunction": ("内合", "Inferior conjunction"),
    "superior_conjunction": ("外合", "Superior conjunction"),
    "opposition": ("衝", "Opposition"),
    "greatest_elongation_east": ("東方最大離角",
                                 "Greatest eastern elongation"),
    "greatest_elongation_west": ("西方最大離角",
                                 "Greatest western elongation"),
    "station_direct": ("留（順行へ）", "Stationary point (direct)"),
    "station_retrograde": ("留（逆行へ）", "Stationary point (retrograde)"),
    # meteors / eclipses (scanner.scan_events)
    "meteor_shower_maximum": ("流星群極大", "Meteor shower maximum"),
    "solar_eclipse": ("日食", "Solar eclipse"),
    "lunar_eclipse": ("月食", "Lunar eclipse"),
    # rise/set/transit (riseset.Event kinds)
    "rise": ("出", "Rise"),
    "set": ("没", "Set"),
    "transit": ("南中", "Transit / culmination"),
    # user-registered targets
    "exoplanet_transit": ("系外惑星トランジット", "Exoplanet transit"),
    "varstar_min": ("変光星極小", "Variable-star minimum"),
    "varstar_max": ("変光星極大", "Variable-star maximum"),
    "min": ("極小", "Minimum"),
    "max": ("極大", "Maximum"),
}

BODY_NAMES: dict[str, tuple[str, str]] = {
    "sun": ("太陽", "Sun"), "moon": ("月", "Moon"),
    "mercury": ("水星", "Mercury"), "venus": ("金星", "Venus"),
    "mars": ("火星", "Mars"), "jupiter": ("木星", "Jupiter"),
    "saturn": ("土星", "Saturn"), "uranus": ("天王星", "Uranus"),
    "neptune": ("海王星", "Neptune"), "pluto": ("冥王星", "Pluto"),
}

#: kinds whose label already names the body (no prefix needed)
_SELF_NAMING = {
    "new_moon", "first_quarter", "full_moon", "last_quarter",
    "moon_perigee", "moon_apogee", "march_equinox", "june_solstice",
    "september_equinox", "december_solstice", "solar_eclipse",
    "lunar_eclipse",
}


def _fold_ics_line(line: str) -> str:
    """RFC 5545 §3.1 line folding: content lines <= 75 octets; longer
    lines are split with CRLF + single space, never inside a UTF-8
    multi-byte sequence (we split at character boundaries)."""
    chunks: list[str] = []
    cur = ""
    cur_octets = 0
    limit = 75  # first physical line; continuations get 74 (+1 space)
    for ch in line:
        n = len(ch.encode("utf-8"))
        if cur_octets + n > limit:
            chunks.append(cur)
            cur, cur_octets, limit = "", 0, 74
        cur += ch
        cur_octets += n
    chunks.append(cur)
    return chunks[0] + "".join("\r\n " + c for c in chunks[1:])


def _ics_escape(text: str) -> str:
    """Escape TEXT per RFC 5545 §3.3.11."""
    return (text.replace("\\", "\\\\").replace(";", "\\;")
            .replace(",", "\\,").replace("\n", "\\n"))


def _event_fields(ev):
    """Normalize ScanResult / duck-typed object / dict to a 5-tuple."""
    if isinstance(ev, dict):
        return (ev.get("kind", ""), ev.get("body", ""), ev["time"],
                ev.get("value"), ev.get("detail") or {})
    return (getattr(ev, "kind", ""), getattr(ev, "body", ""), ev.time,
            getattr(ev, "value", None), getattr(ev, "detail", None) or {})


def _dtstamp(time) -> str:
    """UTC DATE-TIME (YYYYMMDDTHHMMSSZ) from a Time or ISO string."""
    iso = time.iso_utc(0) if hasattr(time, "iso_utc") else str(time)
    return (iso.replace("-", "").replace(":", "").split(".")[0]
            .rstrip("Zz") + "Z")


def to_ics(events, path: str | None = None, lang: str = "ja") -> str:
    """Serialize events to a valid iCalendar (RFC 5545) string.

    events: iterable of scanner.ScanResult, any object with
    .kind/.body/.time (Time), or dicts {kind, body, time, value[,
    detail]}.  DTSTART is UTC (form YYYYMMDDTHHMMSSZ); UID is a content
    hash (stable across runs); SUMMARY is localized via EVENT_NAMES
    (lang 'ja' or 'en'); DESCRIPTION carries body/value/detail.  Lines
    use CRLF endings and are folded at 75 octets per RFC 5545 §3.1.
    If `path` is given the string is also written there (binary-exact).
    """
    li = 0 if lang == "ja" else 1
    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//astrarium//astronomical events//JA",
        "CALSCALE:GREGORIAN",
    ]
    for ev in events:
        kind, body, time, value, detail = _event_fields(ev)
        dt = _dtstamp(time)
        label = EVENT_NAMES.get(kind, (kind, kind))[li]

        if kind == "meteor_shower_maximum":
            shower = detail.get("name_ja" if li == 0 else "name_en", body)
            summary = f"{shower} {label}" if li == 0 else \
                f"{label}: {shower}"
        elif body and kind not in _SELF_NAMING:
            bname = BODY_NAMES.get(str(body).lower(),
                                   (str(body), str(body).capitalize()))[li]
            summary = f"{bname} {label}" if li == 0 else \
                f"{bname}: {label}"
        else:
            summary = label

        uid = hashlib.sha1(
            f"{kind}|{body}|{dt}".encode("utf-8")).hexdigest()[:16]
        desc_parts = []
        if body:
            desc_parts.append(f"body={body}")
        if value is not None:
            desc_parts.append(f"value={value}")
        for k, v in detail.items():
            desc_parts.append(f"{k}={v}")

        lines += [
            "BEGIN:VEVENT",
            f"UID:{uid}@astrarium",
            f"DTSTAMP:{dt}",
            f"DTSTART:{dt}",
            f"SUMMARY:{_ics_escape(summary)}",
        ]
        if desc_parts:
            lines.append(
                f"DESCRIPTION:{_ics_escape(', '.join(desc_parts))}")
        lines.append("END:VEVENT")
    lines.append("END:VCALENDAR")

    out = "\r\n".join(_fold_ics_line(l) for l in lines) + "\r\n"
    if path:
        with open(path, "w", encoding="utf-8", newline="") as f:
            f.write(out)
    return out


# ---------------------------------------------------------------------------
# CSV
# ---------------------------------------------------------------------------
def to_csv(rows: list[dict], path: str | None = None) -> str:
    """Serialize dict rows to CSV (stdlib csv module, UTF-8).

    The header is the union of all row keys with a deterministic order:
    'time', 'kind', 'body' first (when present, in that order), the
    remainder sorted alphabetically.  Missing cells are left empty.
    """
    keys: set[str] = set()
    for r in rows:
        keys.update(r.keys())
    first = [k for k in ("time", "kind", "body") if k in keys]
    header = first + sorted(keys - set(first))

    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=header, restval="",
                       extrasaction="ignore")
    w.writeheader()
    for r in rows:
        w.writerow(r)
    out = buf.getvalue()
    if path:
        with open(path, "w", encoding="utf-8", newline="") as f:
            f.write(out)
    return out


# ---------------------------------------------------------------------------
# Ephemeris tables
# ---------------------------------------------------------------------------
_ROUND = {"ra_apparent": 6, "dec_apparent": 6, "ra_icrs": 6, "dec_icrs": 6,
          "alt": 3, "az": 3, "distance_au": 6, "magnitude": 2,
          "illuminated_fraction": 4}


def _rounded(name, value):
    if value is None:
        return None
    v = float(np.atleast_1d(value)[0])
    if not np.isfinite(v):
        return v
    return round(v, _ROUND.get(name, 6))


def ephemeris_table(eph: Ephemeris, body_or_target, t0: Time, t1: Time,
                    step_days: float, site: Site | None = None,
                    quantities=("ra_apparent", "dec_apparent", "alt", "az",
                                "distance_au", "magnitude")) -> list[dict]:
    """Tabulate an ephemeris at fixed steps; rows suit :func:`to_csv`.

    body_or_target: solar-system body name (str, via observe_planet) or
    a dict {'ra_deg':…, 'dec_deg':…[, 'pmra_mas_yr', 'pmdec_mas_yr',
    'parallax_mas', 'vmag']} for a fixed target (observe_star).  Each
    row carries 'time_utc' (ISO) plus 'time_local' (site.tz) when a
    site is given, and the requested quantities rounded sensibly
    (RA/Dec 6 dp, alt/az 3 dp).  Topocentric quantities (alt/az) are
    omitted when site is None.
    """
    n = int(np.floor((t1 - t0) / step_days + 1e-9)) + 1
    rows = []
    for i in range(max(n, 1)):
        t = t0 + i * step_days
        row = {"time_utc": t.iso_utc(0)}
        if site is not None:
            row["time_local"] = t.iso_local(site.tz)

        if isinstance(body_or_target, str):
            bv = observe_planet(eph, body_or_target, t, site)
            pos = bv.position
            source = {"magnitude": bv.magnitude,
                      "illuminated_fraction": bv.illuminated_fraction,
                      "distance_au": bv.position.distance_au}
        else:
            d = body_or_target
            pos = observe_star(
                d["ra_deg"], d["dec_deg"], t, site,
                pmra_mas_yr=d.get("pmra_mas_yr", 0.0),
                pmdec_mas_yr=d.get("pmdec_mas_yr", 0.0),
                parallax_mas=d.get("parallax_mas", 0.0))
            source = {"magnitude": d.get("vmag"),
                      "distance_au": pos.distance_au}

        for q in quantities:
            val = source[q] if q in source else getattr(pos, q, None)
            if val is None:
                continue          # e.g. alt/az without a site
            row[q] = _rounded(q, val)
        rows.append(row)
    return rows


# ---------------------------------------------------------------------------
# FITS WCS header
# ---------------------------------------------------------------------------
def _card(key: str, value, comment: str = "") -> str:
    """One 80-character FITS keyword record (FITS Standard 4.0 §4.1).

    Strings are quoted starting in column 11 (padded to >= 8 chars
    inside the quotes); numbers are right-justified in columns 11-30
    (fixed format).
    """
    if isinstance(value, str):
        body = f"{key:<8}= '{value:<8}'"
    elif isinstance(value, bool):
        body = f"{key:<8}= {'T' if value else 'F':>20}"
    elif isinstance(value, int):
        body = f"{key:<8}= {value:>20d}"
    else:
        body = f"{key:<8}= {value:>20.12E}"
    if comment:
        body += f" / {comment}"
    return body[:80].ljust(80)


def to_fits_wcs_header(ra_deg: float, dec_deg: float,
                       scale_arcsec_per_px: float,
                       width_px: int, height_px: int,
                       rotation_deg: float = 0.0,
                       projection: str = "TAN") -> str:
    """FITS WCS header cards for a tangent-plane (or other) projection.

    Conventions per WCS Papers I/II (Greisen & Calabretta 2002;
    Calabretta & Greisen 2002, A&A 395):

    - CRPIX at the image center ((N+1)/2 in FITS 1-based pixels),
    - CD matrix from pixel scale s [deg/px] and rotation theta,
      east-left (RA increases to the left) standard orientation:
      CD1_1 = -s cos(theta), CD1_2 = s sin(theta),
      CD2_1 =  s sin(theta), CD2_2 = s cos(theta),
    - RADESYS='ICRS', EQUINOX=2000.0.

    Returns only the WCS card block (each card exactly 80 characters,
    joined with newlines, 'END' last) — SIMPLE/BITPIX etc. are the
    caller's concern.  Hand-rolled, no astropy dependency.
    """
    s = scale_arcsec_per_px / 3600.0        # deg / px
    th = np.deg2rad(rotation_deg)
    c, sn = np.cos(th), np.sin(th)
    proj = projection.upper()
    cards = [
        _card("WCSAXES", 2, "number of WCS axes"),
        _card("CTYPE1", f"RA---{proj}", "RA gnomonic projection"),
        _card("CTYPE2", f"DEC--{proj}", "Dec gnomonic projection"),
        _card("CRVAL1", float(ra_deg), "RA at reference pixel [deg]"),
        _card("CRVAL2", float(dec_deg), "Dec at reference pixel [deg]"),
        _card("CRPIX1", (width_px + 1) / 2.0, "reference pixel X"),
        _card("CRPIX2", (height_px + 1) / 2.0, "reference pixel Y"),
        _card("CD1_1", -s * c, "CD matrix [deg/px], east-left"),
        _card("CD1_2", s * sn, "CD matrix [deg/px]"),
        _card("CD2_1", s * sn, "CD matrix [deg/px]"),
        _card("CD2_2", s * c, "CD matrix [deg/px]"),
        _card("RADESYS", "ICRS", "reference frame"),
        _card("EQUINOX", 2000.0, "equinox of coordinates"),
        "END".ljust(80),
    ]
    return "\n".join(cards)


# ---------------------------------------------------------------------------
# Telescope GOTO payloads (integration seam)
# ---------------------------------------------------------------------------
def telescope_goto_payload(protocol: str, ra_deg: float, dec_deg: float,
                           name: str = ""):
    """Build a GOTO command payload for external telescope software.

    This is an *integration seam* (spec: ASCOM / INDI / SkySafari 拡張)
    — it constructs the data a driver layer would send, but performs no
    network or COM/driver I/O itself; actual device drivers are out of
    scope for this package.

    - 'skysafari': dict {'type': 'skysafari', 'payload': str} where the
      payload is the SkySafari-style telescope-control line
      ``RA <hours.ddddd> Dec <deg.ddddd>`` (decimal hours / degrees).
    - 'ascom': dict describing the ASCOM ITelescope call
      (SlewToCoordinatesAsync with RightAscension in hours,
      Declination in degrees) — documented stub.
    - 'indi': dict describing the INDI EQUATORIAL_EOD_COORD number
      vector (RA hours, DEC degrees) — documented stub.
    """
    ra_h = (float(ra_deg) % 360.0) / 15.0
    dec = float(dec_deg)
    p = protocol.lower()
    if p == "skysafari":
        return {"type": "skysafari",
                "payload": f"RA {ra_h:.5f} Dec {dec:+.5f}",
                "name": name}
    if p == "ascom":
        return {"type": "ascom", "interface": "ITelescope",
                "method": "SlewToCoordinatesAsync",
                "args": {"RightAscension": round(ra_h, 6),
                         "Declination": round(dec, 6)},
                "name": name,
                "note": "stub: pass to an ASCOM driver via win32com "
                        "or Alpaca REST; no driver I/O performed here"}
    if p == "indi":
        return {"type": "indi", "device": name or "Telescope",
                "property": "EQUATORIAL_EOD_COORD",
                "elements": {"RA": round(ra_h, 6), "DEC": round(dec, 6)},
                "note": "stub: send as an INDI newNumberVector; "
                        "no client connection performed here"}
    raise ValueError(f"unknown protocol {protocol!r} "
                     "(expected skysafari|ascom|indi)")
