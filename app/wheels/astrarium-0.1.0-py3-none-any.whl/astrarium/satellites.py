"""Planetary satellite configurations (spec §2: ガリレオ衛星・土星衛星).

Positions from JPL Horizons osculating planetocentric elements
(data/planet_moons.json, epoch 2026-07-01), two-body propagated with the
universal-variable solver (orbits.py).  µ is derived self-consistently
from n²a³ of the element set.

Accuracy: configuration-display grade.  Two-body drift vs the full
integrated ephemerides stays well under 0.1 satellite-orbit radii for
~±2 years around the element epoch for the Galilean moons and the
classical Saturn moons except Hyperion (chaotic rotation/strong Titan
coupling — treat as approximate).  Verified against Horizons geocentric
astrometric positions in tests/test_satellites.py.  For µas-grade work
substitute a JPL satellite SPK (jup365/sat441) via the same interface.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass

import numpy as np

from .constants import AU_KM
from .ephemeris import Ephemeris
from .orbits import Elements
from .observer import Site
from .timescale import Time

from .paths import data_path
_DATA = data_path("planet_moons.json")

MOON_PARENT = {
    "phobos": "mars", "deimos": "mars",
    "io": "jupiter", "europa": "jupiter", "ganymede": "jupiter",
    "callisto": "jupiter",
    "mimas": "saturn", "enceladus": "saturn", "tethys": "saturn",
    "dione": "saturn", "rhea": "saturn", "titan": "saturn",
    "hyperion": "saturn", "iapetus": "saturn",
}
MOON_NAMES_JA = {
    "phobos": "フォボス", "deimos": "ダイモス",
    "io": "イオ", "europa": "エウロパ", "ganymede": "ガニメデ",
    "callisto": "カリスト", "mimas": "ミマス", "enceladus": "エンケラドゥス",
    "tethys": "テティス", "dione": "ディオネ", "rhea": "レア",
    "titan": "タイタン", "hyperion": "ヒペリオン", "iapetus": "イアペトゥス",
}
MARTIAN = ["phobos", "deimos"]
GALILEAN = ["io", "europa", "ganymede", "callisto"]
SATURNIAN = ["mimas", "enceladus", "tethys", "dione", "rhea", "titan",
             "hyperion", "iapetus"]
PLANET_RADIUS_AU = {"mars": 3396.2 / AU_KM,
                    "jupiter": 71492.0 / AU_KM,
                    "saturn": 60268.0 / AU_KM}


@dataclass
class SatellitePosition:
    name: str
    parent: str
    # offsets from the planet on the sky, in planet equatorial radii
    dx_radii: float     # +east  (RA direction)
    dy_radii: float     # +north (Dec direction)
    dx_arcsec: float
    dy_arcsec: float
    in_front: bool      # nearer to the observer than the planet center
    ra_deg: float       # geocentric/topocentric astrometric ICRS
    dec_deg: float


class SatelliteEphemeris:
    def __init__(self, path: str | None = None):
        with open(path or _DATA, encoding="utf-8") as f:
            raw = json.load(f)
        self.elements: dict[str, Elements] = {}
        for name, parent in MOON_PARENT.items():
            if name in raw:
                self.elements[name] = Elements.from_horizons_json(
                    raw[name], name=name, kind="moon")
        self.meta = raw.get("_meta", {})

    def positions(self, eph: Ephemeris, time: Time, moons=None,
                  site: Site | None = None) -> list[SatellitePosition]:
        """Sky-plane configuration of the requested moons."""
        from .frames import observer_bary_pv
        out = []
        d1, d2 = time.tdb
        po, _, _ = observer_bary_pv(eph, time, site)
        for name in (moons or list(self.elements)):
            el = self.elements[name]
            parent = MOON_PARENT[name]
            pp, _ = eph.pv_bary(parent, d1, d2)
            # light time to the planet (shared by planet & moon: adequate
            # for configuration work)
            tau = np.linalg.norm(pp - po, axis=-1) / 173.144632674
            pp_e, _ = eph.pv_bary(parent, d1, d2 - tau)
            rel, _ = el.state_icrs(d1 + d2 - tau)
            pm_e = pp_e + rel

            up = (pp_e - po)
            um = (pm_e - po)
            dp = np.linalg.norm(up, axis=-1)
            dm = np.linalg.norm(um, axis=-1)
            import erfa
            ra_p, de_p = erfa.c2s(up / dp[..., None])
            ra_m, de_m = erfa.c2s(um / dm[..., None])
            dra = ((ra_m - ra_p + np.pi) % (2 * np.pi) - np.pi) \
                * np.cos(de_p)
            dde = de_m - de_p
            scale = np.rad2deg(1) * 3600.0
            rad = PLANET_RADIUS_AU[parent] / dp   # planet radius in rad
            # the ephemeris chain is vectorised, so these are 1-element
            # arrays; index before converting (bare float() on an array
            # is deprecated in NumPy >= 1.25)
            def _f(x):
                return float(np.atleast_1d(x)[0])

            out.append(SatellitePosition(
                name=name, parent=parent,
                dx_radii=_f(dra / rad), dy_radii=_f(dde / rad),
                dx_arcsec=_f(dra * scale), dy_arcsec=_f(dde * scale),
                in_front=bool(np.atleast_1d(dm < dp)[0]),
                ra_deg=_f(np.rad2deg(ra_m % (2 * np.pi))),
                dec_deg=_f(np.rad2deg(de_m))))
        return out
