"""Apparent visual magnitudes of solar-system bodies.

Planets: Mallama, A. & Hilton, J.L. (2018), "Computing apparent planetary
magnitudes for The Astronomical Almanac", Astronomy & Computing 25, 10
(arXiv:1808.01973).  Coefficients cross-checked against the reference
implementation Ap_Mag_V3.f90 via Skyfield's magnitudelib (MIT).
Validity limits per the paper: Saturn nan beyond phase angle 6.5°
(rings), Neptune nan beyond 1.9° before year 2000; the Mars rotational
correction (±0.06 mag) is not applied.

Moon: Allen "Astrophysical Quantities" polynomial phase law, scaled by
distances (approximation, ±0.2 mag; documented per spec §13).

Sun: V = -26.74 at 1 au (Cox 2000).
"""
from __future__ import annotations

import numpy as np

# IAU pole unit vectors in ICRS (from IAU/WGCCRE report values;
# identical to the vectors used by Skyfield "design/planet_tilts.py")
SATURN_POLE = np.array([0.08547883, 0.07323576, 0.99364475])
URANUS_POLE = np.array([-0.21199958, -0.94155916, -0.26176809])


def _dist_factor(r, delta):
    return 5.0 * np.log10(r * delta)


def mercury(r, delta, a):
    return (-0.613 + _dist_factor(r, delta)
            + 6.3280e-2 * a - 1.6336e-3 * a**2 + 3.3644e-5 * a**3
            - 3.4265e-7 * a**4 + 1.6893e-9 * a**5 - 3.0334e-12 * a**6)


def venus(r, delta, a):
    a = np.asarray(a, dtype=float)
    low = -1.044e-3 * a + 3.687e-4 * a**2 - 2.814e-6 * a**3 + 8.938e-9 * a**4
    high = 236.05828 + 4.384 - 2.81914 * a + 8.39034e-3 * a**2
    return -4.384 + _dist_factor(r, delta) + np.where(a < 163.7, low, high)


def earth(r, delta, a):
    return (-3.99 + _dist_factor(r, delta)
            - 1.060e-3 * a + 2.054e-4 * a**2)


def mars(r, delta, a):
    a = np.asarray(a, dtype=float)
    lo = -1.601 + 2.267e-2 * a - 1.302e-4 * a**2
    hi = -0.367 - 0.02573 * a + 0.0003445 * a**2
    return _dist_factor(r, delta) + np.where(a <= 50.0, lo, hi)


def jupiter(r, delta, a):
    a = np.asarray(a, dtype=float)
    x = a / 180.0
    lo = -9.395 - 3.7e-4 * a + 6.16e-4 * a**2
    with np.errstate(invalid="ignore"):
        hi = -9.428 - 2.5 * np.log10(
            1.0 - 1.507 * x - 0.363 * x**2 - 0.062 * x**3
            + 2.809 * x**4 - 1.876 * x**5)
    return _dist_factor(r, delta) + np.where(a <= 12.0, lo, hi)


def saturn(r, delta, a, sun_sub_lat_deg, earth_sub_lat_deg):
    """Globe + rings (eq. 10); nan beyond 6.5° phase (paper limit)."""
    a = np.asarray(a, dtype=float)
    product = sun_sub_lat_deg * earth_sub_lat_deg
    sub = np.where(product >= 0, np.sqrt(np.abs(product)), 0.0)
    s = np.sin(np.deg2rad(sub))
    mag = -8.914 - 1.825 * s + 0.026 * a - 0.378 * s * np.exp(-2.25 * a)
    mag = np.where((a <= 6.5) & (sub <= 27.0), mag, np.nan)
    return mag + _dist_factor(r, delta)


def uranus(r, delta, a, sun_sub_lat_deg, earth_sub_lat_deg):
    sub = (np.abs(sun_sub_lat_deg) + np.abs(earth_sub_lat_deg)) / 2.0
    mag = -7.110 - 0.00084 * sub + _dist_factor(r, delta)
    a = np.asarray(a, dtype=float)
    return mag + np.where(a > 3.1, 6.587e-3 * a + 1.045e-4 * a**2, 0.0)


def neptune(r, delta, a, year):
    base = np.clip(-6.89 - 0.0054 * (np.asarray(year) - 1980.0), -7.00, -6.89)
    mag = base + _dist_factor(r, delta)
    a = np.asarray(a, dtype=float)
    phase_term = np.where(np.asarray(year) >= 2000.0,
                          7.944e-3 * a + 9.617e-5 * a**2, np.nan)
    return np.where(a > 1.9, mag + phase_term, mag)


def moon(r_au, delta_au, a):
    """Allen phase law; distances rescale from mean 384400 km / 1 au.

    Approximation (±0.2 mag): no opposition surge or libration terms.
    """
    a = np.abs(np.asarray(a, dtype=float))
    m0 = -12.73 + 0.026 * a + 4.0e-9 * a**4
    mean_delta_au = 384400.0 / 149597870.7
    return m0 + 5.0 * np.log10((delta_au / mean_delta_au) * (r_au / 1.0))


def sun(delta_au):
    return -26.74 + 5.0 * np.log10(delta_au)


def sub_latitude_deg(pole_icrs, vec_from_body_au):
    """Planetocentric sub-point latitude of the direction -vec (deg).

    vec_from_body_au: vector from the body to the Sun or to the observer
    (i.e. body->X); returns latitude of X as seen from the body.
    """
    v = np.asarray(vec_from_body_au, dtype=float)
    n = v / np.linalg.norm(v, axis=-1, keepdims=True)
    cosang = np.clip(np.sum(n * pole_icrs, axis=-1), -1, 1)
    return 90.0 - np.rad2deg(np.arccos(cosang))


def apparent_magnitude(body: str, r_au, delta_au, phase_angle_deg,
                       sun_vec_au=None, obs_vec_au=None, year=None):
    """Dispatch by body name.

    sun_vec_au / obs_vec_au: vectors body->Sun and body->observer
    (needed for Saturn ring tilt and Uranus sub-latitudes).
    """
    b = body.lower()
    if b == "sun":
        return sun(delta_au)
    if b == "moon":
        return moon(r_au, delta_au, phase_angle_deg)
    if b in ("mercury", "venus", "earth", "mars", "jupiter"):
        return {"mercury": mercury, "venus": venus, "earth": earth,
                "mars": mars, "jupiter": jupiter}[b](
            r_au, delta_au, phase_angle_deg)
    if b == "saturn":
        s1 = sub_latitude_deg(SATURN_POLE, sun_vec_au)
        s2 = sub_latitude_deg(SATURN_POLE, obs_vec_au)
        return saturn(r_au, delta_au, phase_angle_deg, s1, s2)
    if b == "uranus":
        s1 = sub_latitude_deg(URANUS_POLE, sun_vec_au)
        s2 = sub_latitude_deg(URANUS_POLE, obs_vec_au)
        return uranus(r_au, delta_au, phase_angle_deg, s1, s2)
    if b == "neptune":
        return neptune(r_au, delta_au, phase_angle_deg, year)
    raise ValueError(body)
