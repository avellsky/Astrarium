"""Meteor shower predictions (spec §2: IMO 準拠カレンダー).

Data: data/meteor_showers.json (IMO Working List values: peak solar
longitude λ☉ (J2000), radiant + daily drift, v∞, r, ZHR).

- Peak time: root-solve λ☉(t) = λ☉_peak using the Sun's apparent
  geocentric longitude reduced to the J2000 ecliptic (IMO convention;
  nutation residual < 0.005° ≈ 7 min, well under quoted peak accuracy).
- Local circumstances: radiant rise/set & altitude, moonlight rating
  (illuminated fraction × moon altitude), and a naive observable rate
  HR = ZHR·sin(h_radiant)·(moon factor) for planning purposes.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass

import numpy as np

from .ephemeris import Ephemeris
from .frames import (icrs_to_ecliptic, observe_body, observe_star,
                     of_date_to_icrs)
from .observer import Site
from .riseset import find_crossings
from .timescale import Time

from .paths import data_path
_DATA = data_path("meteor_showers.json")


def solar_longitude_j2000(eph: Ephemeris, time: Time):
    """Apparent geocentric solar longitude, ecliptic & equinox J2000 [deg]."""
    p = observe_body(eph, "sun", time, site=None, refraction=False)
    # apparent (of date, incl. aberration) -> J2000 frame -> ecliptic
    ra_j, de_j = of_date_to_icrs(p.ra_apparent, p.dec_apparent, time)
    lon, _ = icrs_to_ecliptic(ra_j, de_j, None)
    return np.asarray(lon)


@dataclass
class ShowerEvent:
    iau_code: str
    name_ja: str
    name_en: str
    peak: Time
    zhr: float
    r: float
    vinf_km_s: float
    radiant_ra_deg: float
    radiant_dec_deg: float
    parent_ja: str = ""              # parent comet / asteroid
    parent_en: str = ""
    activity_start_sollon: float | None = None
    activity_end_sollon: float | None = None
    # local circumstances (None if no site given)
    radiant_alt_at_peak: float | None = None
    moon_illum: float | None = None
    moon_alt_at_peak: float | None = None
    moon_condition: str | None = None    # 'excellent'|'good'|'poor'|'bad'
    note: str = ""


class MeteorCalendar:
    def __init__(self, path: str | None = None):
        with open(path or _DATA, encoding="utf-8") as f:
            self.data = json.load(f)["showers"]

    def peaks_between(self, eph: Ephemeris, t0: Time, t1: Time,
                      site: Site | None = None) -> list[ShowerEvent]:
        """All shower maxima in [t0, t1] with local circumstances."""
        out = []
        for sh in self.data:
            target = sh["peak_sollon"]

            def f(off):
                t = Time(t0.tt1, t0.tt2 + np.asarray(off))
                return (solar_longitude_j2000(eph, t) - target + 180.0) \
                    % 360.0 - 180.0

            for r_off, d in find_crossings(f, t0, t1, step_min=1440.0):
                if d <= 0:
                    continue
                t_peak = t0 + r_off
                dl = 0.0
                ra = sh["radiant_ra_deg"] + sh.get(
                    "drift_ra_deg_per_sollon", 0.0) * dl
                dec = sh["radiant_dec_deg"] + sh.get(
                    "drift_dec_deg_per_sollon", 0.0) * dl
                ev = ShowerEvent(
                    iau_code=sh["iau_code"], name_ja=sh["name_ja"],
                    name_en=sh["name_en"], peak=t_peak, zhr=sh["zhr"],
                    r=sh.get("r", 2.5), vinf_km_s=sh.get("vinf_km_s", 40),
                    radiant_ra_deg=ra, radiant_dec_deg=dec,
                    parent_ja=sh.get("parent_ja", ""),
                    parent_en=sh.get("parent_en", ""),
                    activity_start_sollon=sh.get("activity_start_sollon"),
                    activity_end_sollon=sh.get("activity_end_sollon"),
                    note=sh.get("note", ""))
                if site is not None:
                    self._local(eph, ev, site)
                out.append(ev)
        return sorted(out, key=lambda e: e.peak.jd_tt)

    def _local(self, eph, ev: ShowerEvent, site: Site):
        from .bodies import observe_planet
        sp = observe_star(ev.radiant_ra_deg, ev.radiant_dec_deg, ev.peak,
                          site, refraction=False)
        ev.radiant_alt_at_peak = float(np.atleast_1d(sp.alt)[0])
        mv = observe_planet(eph, "moon", ev.peak, site, refraction=False)
        ev.moon_illum = float(np.atleast_1d(mv.illuminated_fraction)[0])
        ev.moon_alt_at_peak = float(np.atleast_1d(mv.alt)[0])
        if ev.moon_alt_at_peak < 0 or ev.moon_illum < 0.15:
            ev.moon_condition = "excellent"
        elif ev.moon_illum < 0.4:
            ev.moon_condition = "good"
        elif ev.moon_illum < 0.75:
            ev.moon_condition = "poor"
        else:
            ev.moon_condition = "bad"

    def observable_rate(self, eph: Ephemeris, sh_code: str, time: Time,
                        site: Site, limiting_mag=6.5) -> float:
        """Naive expected hourly rate for an observer:
        HR = ZHR · sin(h_R) · r^(6.5-lm) damped by moonlight.
        (Planning aid, not a flux model.)"""
        sh = next(s for s in self.data if s["iau_code"] == sh_code)
        sp = observe_star(sh["radiant_ra_deg"], sh["radiant_dec_deg"],
                          time, site, refraction=False)
        alt = float(np.atleast_1d(sp.alt)[0])
        if alt <= 0:
            return 0.0
        from .bodies import observe_planet
        mv = observe_planet(eph, "moon", time, site, refraction=False)
        moon_pen = 1.0
        if float(np.atleast_1d(mv.alt)[0]) > 0:
            moon_pen = max(0.05, 1.0 - 0.9 * float(
                np.atleast_1d(mv.illuminated_fraction)[0]))
        r = sh.get("r", 2.5)
        return (sh["zhr"] * np.sin(np.deg2rad(alt))
                * r ** (limiting_mag - 6.5) * moon_pen)
