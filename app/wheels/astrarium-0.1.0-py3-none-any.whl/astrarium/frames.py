"""Reference frames and the apparent-place chain (spec §2 common, §5).

Coordinate systems: ICRS/J2000 equatorial, equatorial of date (true
equinox), CIRS, ecliptic (mean of date / J2000), galactic, horizontal.

Apparent-place chain for solar-system bodies (research grade):

  1. observer barycentric state = Earth(DE) + site GCRS offset
     (site: ERFA pvtob in CIRS, rotated to GCRS with c2i06a^T)
  2. light-time iteration against DE barycentric body position
  3. gravitational light deflection by the Sun (ERFA ldsun; skipped for
     the Sun itself)
  4. annual+diurnal aberration (ERFA ab, relativistic)
  5. GCRS -> CIRS with the IAU 2006/2000A CIO-based matrix (c2i06a);
     equinox-of-date apparent RA = RA_CIRS - EO (eo06a)
  6. CIRS -> observed az/alt/HA with ERFA atioq/apio13 (polar motion,
     Earth rotation, refraction)

Refraction: ERFA model (A tan z + B tan^3 z, apio13/refco), disabled by
setting pressure to zero.  Stated ERFA accuracy: ~0.05" above 15° alt,
<1" down to 5°, degrading to ~0.3° at the horizon for optical
wavelengths.  All steps follow the SOFA "Astrometry Tools" cookbook.

Star (catalog) places use ERFA atco13/atci13 (proper motion, parallax,
radial velocity, space motion — Gaia-compatible).
"""
from __future__ import annotations

from dataclasses import dataclass

import erfa
import numpy as np

from .constants import AU_KM, C_AU_PER_DAY, DEG
from .ephemeris import Ephemeris
from .observer import Site
from .timescale import Time

TURNAS = 1296000.0  # arcsec per turn


# ---------------------------------------------------------------------------
# low-level helpers
# ---------------------------------------------------------------------------
def _site_gcrs_pv(time: Time, site: Site):
    """Site geocentric position [au] and velocity [au/day] in GCRS axes."""
    xp_as, yp_as = time.polar_motion
    xp, yp = xp_as * erfa.DAS2R, yp_as * erfa.DAS2R
    sp = erfa.sp00(*time.tt)
    u1, u2 = time.ut1
    theta = erfa.era00(u1, u2)
    # position/velocity in the CIRS (celestial intermediate) frame
    pv = erfa.pvtob(site.lon_rad, site.lat_rad, site.elev_m,
                    xp, yp, sp, theta)
    p_cirs = pv["p"] / (AU_KM * 1000.0)            # m -> au
    v_cirs = pv["v"] / (AU_KM * 1000.0) * 86400.0  # m/s -> au/day
    rc2i = erfa.c2i06a(*time.tt)                   # GCRS -> CIRS
    # transpose(s) applied to the last axis: r_gcrs = rc2i^T @ r_cirs
    p_g = np.einsum("...ji,...j->...i", rc2i, p_cirs)
    v_g = np.einsum("...ji,...j->...i", rc2i, v_cirs)
    return p_g, v_g, rc2i


def observer_bary_pv(eph: Ephemeris, time: Time, site: Site | None):
    """Observer barycentric position [au] / velocity [au/day], ICRF axes."""
    d1, d2 = time.tdb
    pe, ve = eph.pv_bary("earth", d1, d2)
    if site is None:
        rc2i = erfa.c2i06a(*time.tt)
        return pe, ve, rc2i
    pg, vg, rc2i = _site_gcrs_pv(time, site)
    return pe + pg, ve + vg, rc2i


@dataclass
class SkyPosition:
    """Result of an apparent-place computation (angles in degrees, deg)."""
    # astrometric ICRS (light-time corrected, no aberration/deflection)
    ra_icrs: object
    dec_icrs: object
    # apparent, equinox & equator of date
    ra_apparent: object
    dec_apparent: object
    # CIRS (CIO based)
    ra_cirs: object
    dec_cirs: object
    # observed (refracted) horizontal + hour angle; None if geocentric
    az: object = None
    alt: object = None
    alt_unrefracted: object = None
    hour_angle_h: object = None
    distance_au: object = None      # true (geometric) distance at t
    light_time_min: object = None
    # bookkeeping
    time: object = None
    site: object = None

    # ---- derived coordinate systems (spec §5: one call each) ----
    def ecliptic(self, of_date=True, apparent=True):
        """Ecliptic lon/lat [deg] (geocentric/topocentric of this position)."""
        ra = np.deg2rad(self.ra_apparent if apparent else self.ra_icrs)
        dec = np.deg2rad(self.dec_apparent if apparent else self.dec_icrs)
        if apparent:
            # apparent place is referred to the true equator/equinox of date;
            # rotate about the x-axis by the true obliquity
            eps = erfa.obl06(*self.time.tt) + erfa.nut06a(*self.time.tt)[1]
            ce, se = np.cos(eps), np.sin(eps)
            x = np.cos(dec) * np.cos(ra)
            y = np.cos(dec) * np.sin(ra) * ce + np.sin(dec) * se
            z = -np.cos(dec) * np.sin(ra) * se + np.sin(dec) * ce
            lon = np.arctan2(y, x) % (2 * np.pi)
            lat = np.arcsin(np.clip(z, -1, 1))
            return np.rad2deg(lon), np.rad2deg(lat)
        tt = self.time.tt if of_date else (2451545.0, 0.0)
        rm = erfa.ecm06(*tt)                    # ICRS -> ecliptic
        v = erfa.s2c(ra, dec)
        e = np.einsum("...ij,...j->...i", rm, v)
        lon, lat = erfa.c2s(e)
        return np.rad2deg(lon % (2 * np.pi)), np.rad2deg(lat)

    def galactic(self):
        """IAU 1958 galactic l, b [deg] from the ICRS place (ERFA icrs2g)."""
        l, b = erfa.icrs2g(np.deg2rad(self.ra_icrs), np.deg2rad(self.dec_icrs))
        return np.rad2deg(l), np.rad2deg(b)

    def airmass(self):
        """Relative airmass, Kasten & Young (1989); inf below horizon."""
        return airmass_kasten_young(self.alt)


# ---------------------------------------------------------------------------
# the apparent-place engine
# ---------------------------------------------------------------------------
def observe_body(eph: Ephemeris, body: str, time: Time,
                 site: Site | None = None, refraction: bool = True,
                 apply_deflection: bool = True) -> SkyPosition:
    """Topocentric (or geocentric) apparent place of a solar-system body.

    Algorithm: SOFA astrometry cookbook chain against the JPL DE kernel
    (see module docstring).  Accuracy: limited by the kernel and the
    ERFA models — sub-mas geocentric, sub-arcsecond observed (refraction
    model dominated near horizon).
    """
    d1, d2 = time.tdb
    po, vo, rc2i = observer_bary_pv(eph, time, site)

    # --- light time iteration (3 rounds: converges to <1e-10 au) ---
    tau = 0.0
    for _ in range(3):
        pb, vb = eph.pv_bary(body, d1, d2 - tau)
        d = pb - po
        dist = np.linalg.norm(d, axis=-1)
        tau = dist / C_AU_PER_DAY
    geometric_dist = np.linalg.norm(
        eph.pv_bary(body, d1, d2)[0] - po, axis=-1)

    u = d / dist[..., None]                       # astrometric direction
    ra_icrs, dec_icrs = erfa.c2s(u)

    # --- light deflection by the Sun (skip for the Sun itself) ---
    ps, _ = eph.pv_bary("sun", d1, d2)
    if apply_deflection and body != "sun":
        e_h = po - ps                              # Sun -> observer [au]
        em = np.linalg.norm(e_h, axis=-1)
        # erfa.ldsun(p, e, em): p = natural direction, e = Sun-to-observer
        # unit vector, em = Sun-observer distance [au]
        u1 = erfa.ldsun(u, _unit(e_h), em)
    else:
        u1 = u
    # --- aberration (relativistic, ERFA ab) ---
    v_c = vo / C_AU_PER_DAY
    bm1 = np.sqrt(1.0 - np.sum(v_c * v_c, axis=-1))
    em_obs = np.linalg.norm(po - ps, axis=-1)
    u2 = erfa.ab(u1, v_c, em_obs, bm1)

    # --- GCRS -> CIRS ---
    p_cirs = np.einsum("...ij,...j->...i", rc2i, u2)
    ri, di = erfa.c2s(p_cirs)
    eo = erfa.eo06a(*time.tt)
    ra_app = (ri - eo) % (2 * np.pi)

    pos = SkyPosition(
        ra_icrs=np.rad2deg(ra_icrs % (2 * np.pi)),
        dec_icrs=np.rad2deg(dec_icrs),
        ra_apparent=np.rad2deg(ra_app), dec_apparent=np.rad2deg(di),
        ra_cirs=np.rad2deg(ri % (2 * np.pi)), dec_cirs=np.rad2deg(di),
        distance_au=geometric_dist, light_time_min=tau * 1440.0,
        time=time, site=site)

    if site is not None:
        _add_observed(pos, ri, di, time, site, refraction)
    return pos


def _unit(v):
    return v / np.linalg.norm(v, axis=-1)[..., None]


def _apio(time: Time, site: Site, refraction: bool):
    u1, u2 = time.utc
    dut1 = time.dut1
    xp_as, yp_as = time.polar_motion
    phpa = site.default_pressure_hpa() if refraction else 0.0
    astrom = erfa.apio13(u1, u2, dut1, site.lon_rad, site.lat_rad,
                         site.elev_m,
                         xp_as * erfa.DAS2R, yp_as * erfa.DAS2R,
                         phpa, site.temperature_c, site.rel_humidity, 0.55)
    # Diurnal aberration is already included upstream (observer velocity
    # in erfa.ab / apco13 astrom); zero apio's term to avoid applying it
    # twice in atioq (SOFA convention: apco-based astrom has diurab=0).
    astrom["diurab"] = 0.0
    return astrom


def _add_observed(pos: SkyPosition, ri, di, time: Time, site: Site,
                  refraction: bool):
    astrom = _apio(time, site, refraction)
    aob, zob, hob, dob, rob = erfa.atioq(ri, di, astrom)
    pos.az = np.rad2deg(aob % (2 * np.pi))
    pos.alt = 90.0 - np.rad2deg(zob)
    pos.hour_angle_h = np.rad2deg(hob) / 15.0
    if refraction:
        astrom0 = _apio(time, site, False)
        _, z0, _, _, _ = erfa.atioq(ri, di, astrom0)
        pos.alt_unrefracted = 90.0 - np.rad2deg(z0)
    else:
        pos.alt_unrefracted = pos.alt
    return pos


def observe_star(ra_icrs_deg, dec_icrs_deg, time: Time,
                 site: Site | None = None, refraction: bool = True,
                 pmra_mas_yr=0.0, pmdec_mas_yr=0.0, parallax_mas=0.0,
                 rv_km_s=0.0, epoch_jd_tt=2451545.0) -> SkyPosition:
    """Apparent/observed place of a catalog star (Gaia/HIP style data).

    pmra is proper motion in RA*cos(dec) [mas/yr] (catalog convention);
    ERFA wants dRA/dt, so we divide by cos(dec).  Uses ERFA atci13 (+
    atioq for the observed place) — IAU 2006/2000A, space motion,
    parallax, annual aberration, deflection.
    """
    rc = np.deg2rad(np.asarray(ra_icrs_deg, dtype=float))
    dc = np.deg2rad(np.asarray(dec_icrs_deg, dtype=float))
    pr = np.asarray(pmra_mas_yr, dtype=float) * erfa.DMAS2R / np.cos(dc)
    pd = np.asarray(pmdec_mas_yr, dtype=float) * erfa.DMAS2R
    px = np.maximum(np.asarray(parallax_mas, dtype=float), 0.0) / 1000.0
    rv = np.asarray(rv_km_s, dtype=float)

    # Catalog epoch other than J2000 must be pre-propagated with
    # erfa.pmsafe by the caller (catalog.py does).
    if site is None:
        # geocentric apparent
        ri, di, eo = erfa.atci13(rc, dc, pr, pd, px, rv, *time.tt)
    else:
        # topocentric apparent (includes diurnal aberration & parallax):
        # apco13 astrom with p=0 (refraction handled separately in atioq)
        u1, u2 = time.utc
        xp_as, yp_as = time.polar_motion
        astrom, eo = erfa.apco13(u1, u2, time.dut1,
                                 site.lon_rad, site.lat_rad, site.elev_m,
                                 xp_as * erfa.DAS2R, yp_as * erfa.DAS2R,
                                 0.0, 0.0, 0.0, 0.55)
        ri, di = erfa.atciq(rc, dc, pr, pd, px, rv, astrom)
    ra_app = (ri - eo) % (2 * np.pi)

    pos = SkyPosition(
        ra_icrs=np.rad2deg(rc % (2 * np.pi)), dec_icrs=np.rad2deg(dc),
        ra_apparent=np.rad2deg(ra_app), dec_apparent=np.rad2deg(di),
        ra_cirs=np.rad2deg(ri % (2 * np.pi)), dec_cirs=np.rad2deg(di),
        distance_au=(np.where(px > 0, 1.0 / (px * 4.84813681109536e-6), np.inf)
                     if np.any(px > 0) else np.inf),
        time=time, site=site)
    if site is not None:
        _add_observed(pos, ri, di, time, site, refraction)
    return pos


# ---------------------------------------------------------------------------
# frame conversion utilities (spec §5: any-to-any, one call)
# ---------------------------------------------------------------------------
def icrs_to_of_date(ra_deg, dec_deg, time: Time):
    """Mean ICRS -> true equator & equinox of date (bias-precession-nutation).

    Geometric rotation only (no aberration): use for grids/boundaries.
    """
    rbpn = erfa.pnm06a(*time.tt)
    v = erfa.s2c(np.deg2rad(ra_deg), np.deg2rad(dec_deg))
    w = np.einsum("...ij,...j->...i", rbpn, v)
    r, d = erfa.c2s(w)
    return np.rad2deg(r % (2 * np.pi)), np.rad2deg(d)


def of_date_to_icrs(ra_deg, dec_deg, time: Time):
    rbpn = erfa.pnm06a(*time.tt)
    v = erfa.s2c(np.deg2rad(ra_deg), np.deg2rad(dec_deg))
    w = np.einsum("...ji,...j->...i", rbpn, v)
    r, d = erfa.c2s(w)
    return np.rad2deg(r % (2 * np.pi)), np.rad2deg(d)


def icrs_to_ecliptic(ra_deg, dec_deg, time: Time | None = None):
    """ICRS -> ecliptic lon/lat [deg]; J2000 ecliptic if time is None."""
    tt = time.tt if time is not None else (2451545.0, 0.0)
    lon, lat = _ecl(ra_deg, dec_deg, erfa.ecm06(*tt))
    return lon, lat


def ecliptic_to_icrs(lon_deg, lat_deg, time: Time | None = None):
    tt = time.tt if time is not None else (2451545.0, 0.0)
    rm = erfa.ecm06(*tt)
    v = erfa.s2c(np.deg2rad(lon_deg), np.deg2rad(lat_deg))
    w = np.einsum("...ji,...j->...i", rm, v)
    r, d = erfa.c2s(w)
    return np.rad2deg(r % (2 * np.pi)), np.rad2deg(d)


def _ecl(ra_deg, dec_deg, rm):
    v = erfa.s2c(np.deg2rad(ra_deg), np.deg2rad(dec_deg))
    e = np.einsum("...ij,...j->...i", rm, v)
    lon, lat = erfa.c2s(e)
    return np.rad2deg(lon % (2 * np.pi)), np.rad2deg(lat)


def icrs_to_galactic(ra_deg, dec_deg):
    l, b = erfa.icrs2g(np.deg2rad(ra_deg), np.deg2rad(dec_deg))
    return np.rad2deg(l), np.rad2deg(b)


def galactic_to_icrs(l_deg, b_deg):
    r, d = erfa.g2icrs(np.deg2rad(l_deg), np.deg2rad(b_deg))
    return np.rad2deg(r % (2 * np.pi)), np.rad2deg(d)


def altaz_to_radec(az_deg, alt_deg, time: Time, site: Site):
    """Observed az/alt -> ICRS-free apparent HA/Dec -> RA of date (no refr.)."""
    ha, dec = erfa.ae2hd(np.deg2rad(az_deg), np.deg2rad(alt_deg),
                         site.lat_rad)
    last = time.gast() + site.lon_rad
    ra = (last - ha) % (2 * np.pi)
    return np.rad2deg(ra), np.rad2deg(dec)


def angular_separation_deg(ra1, dec1, ra2, dec2):
    """Great-circle separation [deg] (ERFA seps, numerically robust)."""
    return np.rad2deg(erfa.seps(np.deg2rad(ra1), np.deg2rad(dec1),
                                np.deg2rad(ra2), np.deg2rad(dec2)))


def position_angle_deg(ra1, dec1, ra2, dec2):
    """PA of point 2 wrt point 1, N through E [deg] (ERFA pas)."""
    return np.rad2deg(erfa.pas(np.deg2rad(ra1), np.deg2rad(dec1),
                               np.deg2rad(ra2), np.deg2rad(dec2))) % 360.0


def airmass_kasten_young(alt_deg):
    """Relative airmass, Kasten & Young (1989).  inf below -1°."""
    alt = np.asarray(alt_deg, dtype=float)
    with np.errstate(divide="ignore", invalid="ignore"):
        am = 1.0 / (np.sin(np.deg2rad(alt))
                    + 0.50572 * (alt + 6.07995) ** -1.6364)
    return np.where(alt > -1.0, am, np.inf)


def refraction_bennett_deg(alt_app_deg, pressure_hpa=1013.25, temp_c=10.0):
    """Bennett (1982) refraction R [deg] from *apparent* altitude.

    Accuracy ~0.07' typical; used for rise/set standard altitudes and
    quick estimates (the observed-place chain uses the ERFA model).
    """
    h = np.asarray(alt_app_deg, dtype=float)
    r_arcmin = 1.0 / np.tan(np.deg2rad(h + 7.31 / (h + 4.4)))
    scale = (pressure_hpa / 1010.0) * (283.0 / (273.0 + temp_c))
    return np.where(h > -1.0, r_arcmin * scale / 60.0, 0.58 * scale)
