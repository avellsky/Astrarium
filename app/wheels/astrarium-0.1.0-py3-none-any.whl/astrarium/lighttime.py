"""Barycentric / heliocentric time corrections: BJD_TDB, HJD (spec §4).

BJD_TDB = JD_TDB + Romer delay = JD_TDB + (r_obs · n̂)/c, where r_obs is
the observer's barycentric position (DE kernel + site offset) and n̂ the
unit vector toward the (distant) source.  The Shapiro delay (<0.12 ms)
and source-parallax term are neglected — documented; total error budget
well under the 10 ms requirement (spec §11).  Convention follows
Eastman, Siverd & Gaudi (2010, PASP 122, 935).

HJD uses the Sun's center instead of the SSB (legacy variable-star
convention; can differ from BJD by ±4 s).
"""
from __future__ import annotations

import numpy as np

from .constants import C_AU_PER_DAY
from .ephemeris import Ephemeris
from .frames import observer_bary_pv
from .observer import Site
from .timescale import Time


def _unit_from_radec(ra_deg, dec_deg):
    ra = np.deg2rad(np.asarray(ra_deg, dtype=float))
    dec = np.deg2rad(np.asarray(dec_deg, dtype=float))
    return np.stack([np.cos(dec) * np.cos(ra),
                     np.cos(dec) * np.sin(ra),
                     np.sin(dec)], axis=-1)


def romer_delay_days(eph: Ephemeris, time: Time, ra_deg, dec_deg,
                     site: Site | None = None, heliocentric=False):
    """Light-travel-time correction [days], sign such that
    BJD = JD + delay (positive when the observer is on the source side
    of the barycenter)."""
    po, _, _ = observer_bary_pv(eph, time, site)
    if heliocentric:
        d1, d2 = time.tdb
        ps, _ = eph.pv_bary("sun", d1, d2)
        po = po - ps
    n = _unit_from_radec(ra_deg, dec_deg)
    return np.sum(po * n, axis=-1) / C_AU_PER_DAY


def bjd_tdb(eph: Ephemeris, time: Time, ra_deg, dec_deg,
            site: Site | None = None):
    """BJD_TDB of the observation instant `time` for source at ICRS ra/dec."""
    return time.jd_tdb + romer_delay_days(eph, time, ra_deg, dec_deg, site)


def hjd_utc(eph: Ephemeris, time: Time, ra_deg, dec_deg,
            site: Site | None = None):
    """HJD based on UTC (legacy convention used by GCVS/AAVSO elements)."""
    return time.jd_utc + romer_delay_days(eph, time, ra_deg, dec_deg, site,
                                          heliocentric=True)


def hjd_tt(eph: Ephemeris, time: Time, ra_deg, dec_deg,
           site: Site | None = None):
    return time.jd_tt + romer_delay_days(eph, time, ra_deg, dec_deg, site,
                                         heliocentric=True)


def time_from_bjd_tdb(eph: Ephemeris, bjd, ra_deg, dec_deg,
                      site: Site | None = None) -> Time:
    """Invert BJD_TDB -> Time (fixed-point iteration, converges < 1 µs)."""
    t = Time.from_tdb_jd(float(bjd))
    for _ in range(3):
        d = romer_delay_days(eph, t, ra_deg, dec_deg, site)
        t = Time.from_tdb_jd(float(bjd) - float(np.atleast_1d(d)[0]))
    return t


def time_from_hjd_utc(eph: Ephemeris, hjd, ra_deg, dec_deg,
                      site: Site | None = None) -> Time:
    t = Time.from_utc_jd(float(hjd))
    for _ in range(3):
        d = romer_delay_days(eph, t, ra_deg, dec_deg, site,
                             heliocentric=True)
        t = Time.from_utc_jd(float(hjd) - float(np.atleast_1d(d)[0]))
    return t
