"""Data-directory resolution.

Priority:
1. ASTRARIUM_DATA environment variable (wheel installs, web/WASM
   builds, containers)
2. the repository layout <pkg>/../../data (editable install)
"""
from __future__ import annotations

import os

_REPO_DATA = os.path.normpath(
    os.path.join(os.path.dirname(__file__), "..", "..", "data"))


def data_dir() -> str:
    env = os.environ.get("ASTRARIUM_DATA")
    if env:
        return env
    return _REPO_DATA


def data_path(*parts: str) -> str:
    return os.path.join(data_dir(), *parts)
