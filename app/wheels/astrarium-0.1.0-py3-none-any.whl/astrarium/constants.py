"""Physical and astronomical constants.

Sources:
- IAU 2012 Resolution B2 (au), IAU 2015 Resolution B3 (nominal radii)
- IERS Conventions 2010
- Explanatory Supplement to the Astronomical Almanac, 3rd ed.
"""

# --- length / speed ---
AU_KM = 149597870.700          # IAU 2012 definition [km]
C_KM_S = 299792.458            # speed of light [km/s]
C_AU_PER_DAY = C_KM_S * 86400.0 / AU_KM   # ~173.1446 au/day
AU_LIGHT_TIME_S = AU_KM / C_KM_S          # ~499.0048 s

# --- Earth ---
EARTH_RADIUS_EQ_KM = 6378.1366     # IERS 2010 equatorial radius
EARTH_FLATTENING = 1.0 / 298.25642 # IERS 2010

# --- bodies: equatorial radii [km] (IAU 2015 nominal / WGCCRE 2015) ---
BODY_RADIUS_KM = {
    "sun": 695700.0,
    "moon": 1737.4,
    "mercury": 2440.53,
    "venus": 6051.8,
    "earth": 6378.1366,
    "mars": 3396.19,
    "jupiter": 71492.0,
    "saturn": 60268.0,
    "uranus": 25559.0,
    "neptune": 24764.0,
}

# --- eclipse geometry (spec §11) ---
K_MOON = 0.2725076      # ratio Moon radius / Earth equatorial radius (IAU 1982, used for Besselian elements)
DANJON_ENLARGEMENT = 1.01  # enlargement of Earth's shadow for lunar eclipses (Danjon rule)

# --- time ---
TT_MINUS_TAI_S = 32.184
GPS_MINUS_TAI_S = -19.0     # TAI - GPS = 19 s exactly
JD_J2000 = 2451545.0
DAYS_PER_JULIAN_CENTURY = 36525.0
DAYS_PER_JULIAN_YEAR = 365.25
SECONDS_PER_DAY = 86400.0

# --- angles ---
import math
DEG = math.pi / 180.0
ARCSEC = DEG / 3600.0
MAS = ARCSEC / 1000.0

# NAIF body ids
NAIF = {
    "ssb": 0, "sun": 10, "moon": 301, "earth": 399, "emb": 3,
    "mercury": 199, "venus": 299, "mars": 4, "jupiter": 5,
    "saturn": 6, "uranus": 7, "neptune": 8, "pluto": 9,
}
# note: for DE421, Mars..Pluto are only available as system barycenters;
# the barycenter-vs-planet offset is negligible for Earth-based apparent
# place work at the sub-mas level for Jupiter/Saturn (offset < body radius
# fraction of the barycenter separation) and is the standard practice
# (Skyfield does the same).  Mercury/Venus have explicit 199/299 segments.
