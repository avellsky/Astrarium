"""Star and deep-sky-object catalogs (spec §2).

Sources
-------
- Stars: Yale Bright Star Catalogue, 5th rev. ed. (Hoffleit & Warren
  1991), 9096 stars complete to V≈6.5; positions ICRS(FK5 J2000),
  epoch J2000; proper motions µα·cosδ / µδ [mas/yr].
- Constellation line figures: Stellarium's "modern" sky culture, which
  the project licenses as CC BY-SA 4.0 ("Text and data: CC BY-SA 4.0",
  skycultures/modern/description.md).  Credit: Stellarium project,
  https://stellarium.org.  88 IAU constellations, 672 segments keyed by
  HIP number (segments reaching stars fainter than the BSC are dropped
  at build time).  Rebuild with scripts/fetch_constellation_lines.py.
- Constellation names: IAU abbreviations with Latin and Japanese names.
- Proper star names: IAU Working Group on Star Names (WGSN) bulletin
  list, embedded below as a name -> HIP table (the SQLite star_name
  table carries only Bayer/Flamsteed designations).
- DSOs: data/dso.json — Messier + selected Caldwell objects with
  Japanese/English names, types, magnitudes and sizes.

Gaia-ready schema note: the star table's pm columns are µα·cosδ and µδ
in mas/yr (catalog convention), directly compatible with
frames.observe_star's pmra_mas_yr/pmdec_mas_yr arguments; a Gaia-based
build only swaps the id column for source_id and refines the epoch.

All bulk transformations are vectorized: one observe_star call per
catalog query (numpy arrays for ra/dec/pm), fast enough for interactive
charting (~10 ms for the whole BSC at V<=6.5).
"""
from __future__ import annotations

import json
import os
import re
import sqlite3
import unicodedata

import numpy as np

from .frames import observe_star
from .observer import Site
from .timescale import Time

from .paths import data_dir
_DATA_DIR = data_dir()

# ---------------------------------------------------------------------------
# HIP entries referenced by the Stellarium linework but absent from the
# BSC5 HIP cross-index (bright multiple systems whose components carry
# separate HR numbers without a combined HIP entry).  Resolved to the
# primary component's HR number so line endpoints stay consistent with
# the plotted star positions.
# ---------------------------------------------------------------------------
_HIP_TO_HR = {
    8832: 546,     # gamma Ari
    9640: 603,     # gamma And (Almach)
    13847: 897,    # theta1 Eri (Acamar)
    17797: 1212,   # 32/f Eri
    50583: 4057,   # gamma Leo (Algieba)
    65378: 5054,   # zeta UMa (Mizar)
    71683: 5459,   # alpha Cen (Rigil Kentaurus)
    76276: 5788,   # delta Ser
    85112: 6485,   # rho Her
    93825: 7226,   # gamma CrA
    95947: 7417,   # beta Cyg (Albireo)
    107310: 8309,  # mu Cyg
    110960: 8559,  # zeta Aqr
}

# IAU WGSN proper names -> HIP (bright/common subset).
PROPER_NAMES = {
    "Sirius": 32349, "Canopus": 30438, "Rigil Kentaurus": 71683,
    "Arcturus": 69673, "Vega": 91262, "Capella": 24608, "Rigel": 24436,
    "Procyon": 37279, "Achernar": 7588, "Betelgeuse": 27989,
    "Hadar": 68702, "Altair": 97649, "Acrux": 60718, "Aldebaran": 21421,
    "Antares": 80763, "Spica": 65474, "Pollux": 37826,
    "Fomalhaut": 113368, "Deneb": 102098, "Mimosa": 62434,
    "Regulus": 49669, "Adhara": 33579, "Castor": 36850, "Shaula": 85927,
    "Gacrux": 61084, "Bellatrix": 25336, "Elnath": 25428,
    "Miaplacidus": 45238, "Alnilam": 26311, "Alnair": 109268,
    "Alnitak": 26727, "Alioth": 62956, "Dubhe": 54061, "Mirfak": 15863,
    "Wezen": 34444, "Sargas": 86228, "Kaus Australis": 90185,
    "Avior": 41037, "Alkaid": 67301, "Menkalinan": 28360,
    "Atria": 82273, "Alhena": 31681, "Peacock": 100751, "Mirzam": 30324,
    "Alphard": 46390, "Polaris": 11767, "Hamal": 9884, "Diphda": 3419,
    "Nunki": 92855, "Menkent": 68933, "Mirach": 5447, "Alpheratz": 677,
    "Rasalhague": 86032, "Kochab": 72607, "Saiph": 27366,
    "Denebola": 57632, "Algol": 14576, "Sadr": 100453, "Eltanin": 87833,
    "Schedar": 3179, "Caph": 746, "Mintaka": 25930, "Merak": 53910,
    "Phecda": 58001, "Megrez": 59774, "Mizar": 65378, "Alcor": 65477,
    "Albireo": 95947, "Algieba": 50583, "Almach": 9640, "Acamar": 13847,
    "Thuban": 68756, "Arneb": 25985, "Alderamin": 105199, "Enif": 107315,
    "Markab": 113963, "Scheat": 113881, "Algenib": 1067, "Ankaa": 2081,
    "Unukalhai": 77070, "Alphecca": 76267, "Izar": 72105,
    "Vindemiatrix": 63608, "Zubenelgenubi": 72622,
    "Zubeneschamali": 74785, "Menkar": 14135, "Suhail": 44816,
    "Rastaban": 85670, "Tarazed": 97278, "Sabik": 84012,
    "Sadalmelik": 109074, "Sadalsuud": 106278, "Alsephina": 42913,
}

_GREEK = {
    "alpha": "α", "beta": "β", "gamma": "γ", "delta": "δ",
    "epsilon": "ε", "zeta": "ζ", "eta": "η", "theta": "θ", "iota": "ι",
    "kappa": "κ", "lambda": "λ", "mu": "μ", "nu": "ν", "xi": "ξ",
    "omicron": "ο", "pi": "π", "rho": "ρ", "sigma": "σ", "tau": "τ",
    "upsilon": "υ", "phi": "φ", "chi": "χ", "psi": "ψ", "omega": "ω",
}


def _norm(s: str) -> str:
    """Normalize a designation for matching: NFKC, casefold, '_'->' ',
    spelled-out Greek letters -> Greek characters."""
    s = unicodedata.normalize("NFKC", s).casefold().replace("_", " ")
    words = [_GREEK.get(w, w) for w in s.split()]
    return " ".join(words)


# ---------------------------------------------------------------------------
class StarCatalog:
    """Yale BSC5 star catalog (SQLite, read-only)."""

    _COLS = ("id, hip, ra_deg, dec_deg, pmra_mas_yr, pmdec_mas_yr, "
             "vmag, bv, sptype")

    def __init__(self, path: str | None = None):
        path = path or os.path.join(_DATA_DIR, "catalog_bsc5.sqlite")
        self._db = sqlite3.connect(f"file:{os.path.abspath(path)}?mode=ro",
                                   uri=True, check_same_thread=False)
        self._name_by_hip: dict[int, str] | None = None
        self._pos_by_hip: dict[int, tuple] | None = None

    # ---- name resolution --------------------------------------------
    def _names(self) -> dict[int, str]:
        """Best display designation per HIP: IAU proper name, else Bayer,
        else Flamsteed (underscores replaced by spaces)."""
        if self._name_by_hip is None:
            best: dict[int, str] = {}
            greek = set(_GREEK.values())
            for hip, desig in self._db.execute(
                    "SELECT hip, designation FROM star_name"):
                d = desig.replace("_", " ")
                if hip not in best or (d[0] in greek
                                       and best[hip][0] not in greek):
                    best[hip] = d
            for name, hip in PROPER_NAMES.items():
                best[hip] = name
            self._name_by_hip = best
        return self._name_by_hip

    def _row_dict(self, row) -> dict:
        hr, hip, ra, dec, pmra, pmdec, vmag, bv, sp = row
        return {"hr": hr, "hip": hip, "ra_deg": ra, "dec_deg": dec,
                "pmra_mas_yr": pmra or 0.0, "pmdec_mas_yr": pmdec or 0.0,
                "vmag": vmag, "bv": bv, "sptype": sp,
                "name": self._names().get(hip) if hip is not None else None}

    # ---- queries -----------------------------------------------------
    def stars_brighter_than(self, vmag_limit: float) -> list[dict]:
        """All stars with V <= vmag_limit, brightest first."""
        rows = self._db.execute(
            f"SELECT {self._COLS} FROM star WHERE vmag <= ? ORDER BY vmag",
            (vmag_limit,)).fetchall()
        return [self._row_dict(r) for r in rows]

    def star_by_name(self, query: str) -> dict | None:
        """Case-insensitive lookup: proper name / Bayer / Flamsteed
        (partial match ok), or 'HR 7001' / 'HIP 91262'."""
        q = query.strip()
        m = re.match(r"^(HR|HIP)\s*(\d+)$", q, re.IGNORECASE)
        if m:
            num = int(m.group(2))
            col = "id" if m.group(1).upper() == "HR" else "hip"
            row = self._db.execute(
                f"SELECT {self._COLS} FROM star WHERE {col} = ? "
                "ORDER BY vmag LIMIT 1", (num,)).fetchone()
            return self._row_dict(row) if row else None

        nq = _norm(q)
        if not nq:
            return None
        hips: set[int] = set()
        for name, hip in PROPER_NAMES.items():
            if nq in _norm(name):
                hips.add(hip)
        for hip, desig in self._db.execute(
                "SELECT hip, designation FROM star_name"):
            if nq in _norm(desig):
                hips.add(hip)
        best = None
        for hip in hips:
            row = self._hip_row(hip)
            if row and (best is None or row[6] < best[6]):
                best = row
        return self._row_dict(best) if best else None

    def _hip_row(self, hip: int):
        """Brightest star row for a HIP (with the multiple-system HR
        fallback for HIPs missing from the BSC cross-index)."""
        row = self._db.execute(
            f"SELECT {self._COLS} FROM star WHERE hip = ? "
            "ORDER BY vmag LIMIT 1", (hip,)).fetchone()
        if row is None and hip in _HIP_TO_HR:
            row = self._db.execute(
                f"SELECT {self._COLS} FROM star WHERE id = ?",
                (_HIP_TO_HR[hip],)).fetchone()
            if row is not None:                 # keep the requested HIP
                row = (row[0], hip) + row[2:]
        return row

    def _positions_by_hip(self) -> dict[int, tuple]:
        """hip -> (ra, dec) of the brightest component, incl. fallbacks."""
        if self._pos_by_hip is None:
            pos = {}
            for hip, ra, dec in self._db.execute(
                    "SELECT hip, ra_deg, dec_deg FROM star "
                    "WHERE hip IS NOT NULL ORDER BY vmag DESC"):
                pos[hip] = (ra, dec)        # brightest written last
            for hip, hr in _HIP_TO_HR.items():
                r = self._db.execute(
                    "SELECT ra_deg, dec_deg FROM star WHERE id = ?",
                    (hr,)).fetchone()
                if r:
                    pos[hip] = r
            self._pos_by_hip = pos
        return self._pos_by_hip

    def constellation_lines(self) -> list[tuple]:
        """All 676 line segments as (abbr, ra1, dec1, ra2, dec2) [ICRS deg]."""
        pos = self._positions_by_hip()
        out = []
        for abbr, h1, h2 in self._db.execute(
                "SELECT abbr, hip1, hip2 FROM constellation_line"):
            p1, p2 = pos.get(h1), pos.get(h2)
            if p1 is None or p2 is None:
                continue
            out.append((abbr, p1[0], p1[1], p2[0], p2[1]))
        return out

    def constellations(self) -> list[dict]:
        """88 rows: abbr, name_latin, name_ja, label ra/dec [ICRS deg].

        The label position is the mean of the constellation's line-star
        unit vectors (RA-wraparound safe), converted back to ra/dec.
        """
        pos = self._positions_by_hip()
        stars_by_con: dict[str, set] = {}
        for abbr, h1, h2 in self._db.execute(
                "SELECT abbr, hip1, hip2 FROM constellation_line"):
            s = stars_by_con.setdefault(abbr, set())
            for h in (h1, h2):
                if h in pos:
                    s.add(pos[h])
        out = []
        for abbr, latin, ja in self._db.execute(
                "SELECT abbr, name_latin, name_ja FROM constellation "
                "ORDER BY abbr"):
            pts = np.array(sorted(stars_by_con.get(abbr, ())), dtype=float)
            if len(pts):
                ra = np.deg2rad(pts[:, 0])
                dec = np.deg2rad(pts[:, 1])
                v = np.array([np.cos(dec) * np.cos(ra),
                              np.cos(dec) * np.sin(ra),
                              np.sin(dec)]).mean(axis=1)
                v /= np.linalg.norm(v)
                lab_ra = float(np.rad2deg(np.arctan2(v[1], v[0])) % 360.0)
                lab_dec = float(np.rad2deg(np.arcsin(np.clip(v[2], -1, 1))))
            else:                               # pragma: no cover
                lab_ra = lab_dec = float("nan")
            out.append({"abbr": abbr, "name_latin": latin, "name_ja": ja,
                        "ra_deg": lab_ra, "dec_deg": lab_dec})
        return out

    def apparent_stars(self, time: Time, site: Site, vmag_limit: float = 6.5,
                       refraction: bool = False) -> list[dict]:
        """Catalog rows with az/alt/ra_apparent/dec_apparent added.

        One vectorized observe_star call for the whole set (proper
        motion applied; BSC parallaxes are negligible at chart scale).
        """
        rows = self.stars_brighter_than(vmag_limit)
        if not rows:
            return rows
        arr = np.array([(r["ra_deg"], r["dec_deg"],
                         r["pmra_mas_yr"], r["pmdec_mas_yr"])
                        for r in rows], dtype=float)
        p = observe_star(arr[:, 0], arr[:, 1], time, site=site,
                         refraction=refraction,
                         pmra_mas_yr=arr[:, 2], pmdec_mas_yr=arr[:, 3])
        for i, r in enumerate(rows):
            r["ra_apparent"] = float(p.ra_apparent[i])
            r["dec_apparent"] = float(p.dec_apparent[i])
            r["az"] = float(p.az[i])
            r["alt"] = float(p.alt[i])
        return rows


# ---------------------------------------------------------------------------
class DSOCatalog:
    """Messier / Caldwell deep-sky objects (data/dso.json)."""

    def __init__(self, path: str | None = None):
        path = path or os.path.join(_DATA_DIR, "dso.json")
        with open(path, encoding="utf-8") as f:
            self._objects = json.load(f)["objects"]

    def all(self) -> list[dict]:
        return [dict(o) for o in self._objects]

    def by_id(self, ident: str) -> dict | None:
        """Lookup by catalog id ('M31', 'C14'), case-insensitive."""
        q = ident.strip().upper().replace(" ", "")
        for o in self._objects:
            if o["id"].upper() == q:
                return dict(o)
        return None

    def visible(self, time: Time, site: Site, min_alt_deg: float = 20.0,
                vmag_limit: float = 10.0) -> list[dict]:
        """Objects above min_alt_deg and brighter than vmag_limit, with
        az/alt/ra_apparent/dec_apparent added (vectorized, pm = 0)."""
        objs = [o for o in self._objects
                if o.get("vmag") is not None and o["vmag"] <= vmag_limit]
        if not objs:
            return []
        ra = np.array([o["ra_deg"] for o in objs], dtype=float)
        dec = np.array([o["dec_deg"] for o in objs], dtype=float)
        p = observe_star(ra, dec, time, site=site, refraction=False)
        out = []
        for i, o in enumerate(objs):
            if p.alt[i] >= min_alt_deg:
                d = dict(o)
                d["ra_apparent"] = float(p.ra_apparent[i])
                d["dec_apparent"] = float(p.dec_apparent[i])
                d["az"] = float(p.az[i])
                d["alt"] = float(p.alt[i])
                out.append(d)
        out.sort(key=lambda d: d["vmag"])
        return out


# ---------------------------------------------------------------------------
# free-form target parsing (spec §2 突発天体 / transient follow-up)
# ---------------------------------------------------------------------------
_NUM = r"[0-9]{1,3}(?:\.[0-9]+)?"
_SEXA = r"[0-9]{1,2}[\s:hH]+[0-9]{1,2}[\s:mM]+[0-9]{1,2}(?:\.[0-9]+)?[sS]?"
_SEXA_D = (r"[+\-]?[0-9]{1,2}[\s:dD°]+[0-9]{1,2}[\s:mM'′]+"
           r"[0-9]{1,2}(?:\.[0-9]+)?[\"″sS]?")


def _sexa_to_deg(text: str, hours: bool) -> float | None:
    sign = -1.0 if text.lstrip().startswith("-") else 1.0
    parts = [p for p in re.split(r"[^0-9.]+", text) if p]
    if not 1 <= len(parts) <= 3:
        return None
    f = [float(p) for p in parts]
    if len(f) >= 2 and f[1] >= 60:
        return None
    if len(f) >= 3 and f[2] >= 60:
        return None
    val = f[0] + (f[1] if len(f) > 1 else 0) / 60 + \
        (f[2] if len(f) > 2 else 0) / 3600
    val *= 15.0 if hours else 1.0
    return sign * val


def parse_target(text: str) -> dict | None:
    """Parse free-form transient/target coordinates.

    Accepted forms (spec §2 突発天体):
      "05 34 31.94 +22 00 52.2"                    HMS DMS sexagesimal
      "83.633 22.0145"                             decimal degrees
      "RA 05:34:31.9 Dec +22:00:52"                labeled sexagesimal
      "... RA = 05:34:31.94, DEC = +22:00:52.2 ..." TNS-style report line

    Returns {"ra_deg", "dec_deg", "name"} (name may be None) or None.
    """
    if not isinstance(text, str) or not text.strip():
        return None
    s = text.strip()

    # TNS-style "RA = .., DEC = .." or labeled "RA .. Dec .."
    m = re.search(
        rf"RA\.?\s*[=:]?\s*({_SEXA})\s*[,;]?\s+DEC\.?L?\.?\s*[=:]?\s*"
        rf"({_SEXA_D})", s, re.IGNORECASE)
    if m:
        ra = _sexa_to_deg(m.group(1), hours=True)
        dec = _sexa_to_deg(m.group(2), hours=False)
        if ra is None or dec is None or not (0 <= ra < 360 and
                                             -90 <= dec <= 90):
            return None
        name = re.sub(r"[\s,;:]+$", "", s[:m.start()]).strip() or None
        return {"ra_deg": ra, "dec_deg": dec, "name": name}

    # plain sexagesimal pair
    m = re.fullmatch(rf"({_SEXA})\s+({_SEXA_D})", s)
    if m:
        ra = _sexa_to_deg(m.group(1), hours=True)
        dec = _sexa_to_deg(m.group(2), hours=False)
        if ra is None or dec is None or not (0 <= ra < 360 and
                                             -90 <= dec <= 90):
            return None
        return {"ra_deg": ra, "dec_deg": dec, "name": None}

    # decimal degrees pair
    m = re.fullmatch(r"([0-9]{1,3}(?:\.[0-9]+)?)[\s,]+"
                     r"([+\-]?[0-9]{1,2}(?:\.[0-9]+)?)", s)
    if m:
        ra, dec = float(m.group(1)), float(m.group(2))
        if 0 <= ra < 360 and -90 <= dec <= 90:
            return {"ra_deg": ra, "dec_deg": dec, "name": None}
    return None
