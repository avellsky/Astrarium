"""Observing sites (spec §3).

- Site model: WGS84 geodetic latitude/longitude/height, IANA time zone,
  optional IAU/MPC observatory code, optional horizon (elevation) mask.
- Preset database data/sites.json: 47 prefectural capitals, Japanese
  dark-sky sites, world cities, domestic/international observatories.
- DMS <-> decimal-degree helpers.
- Geodetic -> geocentric via ERFA gd2gc (WGS84).
"""
from __future__ import annotations

import json
import math
import os
import re
import unicodedata
from dataclasses import dataclass, field

import erfa
import numpy as np

from .paths import data_dir
_DATA_DIR = data_dir()


# ---------------------------------------------------------------- DMS utils
def dms_to_deg(d, m=0.0, s=0.0, sign=None):
    """Degrees-minutes-seconds to decimal degrees.

    `sign` may be +1/-1 or one of 'N','S','E','W'; if omitted, the sign
    of `d` is used (beware -0°).
    """
    if isinstance(sign, str):
        sign = -1 if sign.upper() in ("S", "W") else 1
    if sign is None:
        sign = -1 if str(d).strip().startswith("-") else 1
    return sign * (abs(float(d)) + float(m) / 60.0 + float(s) / 3600.0)


def deg_to_dms(deg, ndp=1):
    """Decimal degrees -> (sign, d, m, s)."""
    sign = -1 if deg < 0 else 1
    a = abs(deg)
    d = int(a)
    m = int((a - d) * 60)
    s = round((a - d - m / 60) * 3600, ndp)
    if s >= 60:
        s -= 60; m += 1
    if m >= 60:
        m -= 60; d += 1
    return sign, d, m, s


def format_dms(deg, kind="lat", ndp=1):
    sign, d, m, s = deg_to_dms(deg, ndp)
    hemi = {"lat": ("N", "S"), "lon": ("E", "W")}[kind][0 if sign > 0 else 1]
    return f"{d:d}°{m:02d}′{s:04.{ndp}f}″{hemi}"


# ---------------------------------------------------------------- HorizonMask
@dataclass
class HorizonMask:
    """User-defined terrain obstruction: minimum visible altitude vs azimuth.

    azimuth_deg: ascending array 0..360 (N=0, E=90); alt_deg same length.
    Linear interpolation with wraparound.
    """
    azimuth_deg: np.ndarray
    alt_deg: np.ndarray

    @classmethod
    def flat(cls, alt=0.0):
        return cls(np.array([0.0, 360.0]), np.array([alt, alt]))

    @classmethod
    def from_table(cls, table):
        """table: list of [az, alt] pairs (deg)."""
        arr = np.asarray(sorted((a % 360.0, h) for a, h in table))
        az = np.concatenate([arr[:, 0], [arr[0, 0] + 360.0]])
        al = np.concatenate([arr[:, 1], [arr[0, 1]]])
        return cls(az, al)

    def min_alt(self, az_deg):
        return np.interp(np.asarray(az_deg) % 360.0,
                         self.azimuth_deg, self.alt_deg)


# ---------------------------------------------------------------- Site
#: Japan bounding box, used to separate domestic from overseas sites
JP_BOX = (24.0, 46.5, 122.0, 154.0)      # lat0, lat1, lon0, lon1


def region_of(lat: float, lon: float) -> str:
    """Continent key from position alone.

    This is a menu-grouping aid, not geography: coarse boxes, applied in
    order.  scripts/fetch_mpc_observatories.py uses the same rule so the
    2500 MPC stations and the curated sites land in the same places.
    """
    lo = ((lon + 180.0) % 360.0) - 180.0
    if JP_BOX[0] <= lat <= JP_BOX[1] and JP_BOX[2] <= lo <= JP_BOX[3]:
        return "japan"
    if lat < -60.0:
        return "antarctica"
    if -170.0 <= lo <= -30.0:
        return "north_america" if lat >= 13.0 else "south_america"
    if lat < 0.0 and (110.0 <= lo <= 180.0 or -180.0 <= lo <= -140.0):
        return "oceania"
    if -30.0 <= lo <= 60.0 and lat >= 34.0:
        return "europe"
    if -30.0 <= lo <= 52.0 and -40.0 <= lat < 34.0:
        return "africa"
    return "asia"



_TZ_NAME = re.compile(r"[A-Za-z][A-Za-z0-9_+-]*(?:/[A-Za-z0-9_+-]+){0,2}")


def custom_site(spec: str) -> Site:
    """An observing site given directly as coordinates.

    ``spec`` is ``@lat,lon[,elev_m[,tz]]`` in degrees, east and north
    positive — the form the app puts in the site field when the observer
    types their own position instead of picking a listed one.  Every
    endpoint takes a site id, so accepting one here makes an arbitrary
    position work everywhere without a second code path.

    This is what lets the app run with location services refused: the
    observer can always say where they are.
    """
    parts = [p.strip() for p in spec.lstrip("@").split(",")]
    if len(parts) < 2:
        raise ValueError("site spec needs at least lat,lon")
    try:
        lat = float(parts[0])
        lon = float(parts[1])
        elev = float(parts[2]) if len(parts) > 2 and parts[2] else 0.0
    except ValueError:
        raise ValueError(f"bad coordinates in site spec: {spec!r}") from None
    tz = parts[3] if len(parts) > 3 and parts[3] else "UTC"
    if not -90.0 <= lat <= 90.0:
        raise ValueError(f"latitude out of range: {lat}")
    if not -180.0 <= lon <= 360.0:
        raise ValueError(f"longitude out of range: {lon}")
    if lon > 180.0:
        lon -= 360.0
    # the deepest mine and the highest summit bracket anywhere a person
    # can stand; beyond that it is a typing slip, not an observing site
    if not -500.0 <= elev <= 9000.0:
        raise ValueError(f"elevation out of range: {elev}")
    # the zone name reaches zoneinfo, which resolves it against the tz
    # database directory: anything but a plain IANA name is refused so a
    # crafted site id cannot walk the filesystem
    if len(tz) > 64 or not _TZ_NAME.fullmatch(tz):
        raise ValueError(f"bad time zone: {tz!r}")
    ns, ew = ("N" if lat >= 0 else "S"), ("E" if lon >= 0 else "W")
    label = f"{abs(lat):.4f}\u00b0{ns} {abs(lon):.4f}\u00b0{ew}"
    return Site(lat_deg=lat, lon_deg=lon, elev_m=elev, tz=tz,
                name_ja=label, name_en=label,
                id=f"@{lat:.6f},{lon:.6f},{elev:.1f},{tz}",
                category="custom", region=region_of(lat, lon))

@dataclass
class Site:
    """An observing location (WGS84)."""
    lat_deg: float
    lon_deg: float           # east positive
    elev_m: float = 0.0
    tz: str = "UTC"
    name_ja: str = ""
    name_en: str = ""
    #: reading of name_ja, for menus that sort by sound.  Only names
    #: written in kanji need one — 北京 belongs under ペ, not among the
    #: characters that happen to share its first codepoint.
    name_kana: str = ""
    id: str = ""
    category: str = "custom"
    mpc_code: str | None = None
    country_ja: str = ""
    country_en: str = ""
    region: str | None = None   # hierarchy key (japan/asia/europe/...)
    horizon: HorizonMask | None = None
    # default meteorological conditions for refraction (editable)
    pressure_hpa: float | None = None   # None -> derive from elevation
    temperature_c: float = 10.0
    rel_humidity: float = 0.5

    def name(self, lang="ja"):
        return (self.name_ja if lang == "ja" else self.name_en) or \
            self.name_en or self.name_ja or self.id or "custom site"

    @property
    def lat_rad(self):
        return math.radians(self.lat_deg)

    @property
    def lon_rad(self):
        return math.radians(self.lon_deg)

    def default_pressure_hpa(self):
        """Standard-atmosphere pressure at site elevation (for refraction)."""
        if self.pressure_hpa is not None:
            return self.pressure_hpa
        return 1013.25 * math.exp(-self.elev_m / 8434.0)

    def geocentric_xyz_km(self):
        """ITRF geocentric position [km] via ERFA gd2gc (WGS84)."""
        xyz = erfa.gd2gc(1, self.lon_rad, self.lat_rad, self.elev_m)
        return np.asarray(xyz) / 1000.0

    def is_visible(self, az_deg, alt_deg):
        """Above the local horizon mask?"""
        if self.horizon is None:
            return np.asarray(alt_deg) > 0.0
        return np.asarray(alt_deg) > self.horizon.min_alt(az_deg)


# ---------------------------------------------------------------- database
class SiteDB:
    """Preset site database with bilingual partial-match search."""

    #: top level of the site hierarchy shown in the UI.  Observatories
    #: are split into domestic and overseas because the overseas list is
    #: the whole MPC register (~2500 stations) and is sub-grouped by
    #: region inside its own menu.
    GROUPS = [
        ("japan", "日本", "Japan"),
        ("jp_dark", "国内星見スポット", "Japan · dark-sky sites"),
        ("jp_obs", "国内天文台", "Japan · observatories"),
        ("obs", "海外天文台 (MPC)", "Overseas observatories (MPC)"),
        ("world_city", "海外主要都市", "Major world cities"),
        ("asia", "アジア", "Asia"),
        ("oceania", "オセアニア", "Oceania"),
        ("north_america", "北アメリカ", "North America"),
        ("south_america", "南アメリカ", "South America"),
        ("europe", "ヨーロッパ", "Europe"),
        ("africa", "アフリカ", "Africa"),
        ("antarctica", "南極", "Antarctica"),
    ]

    #: sub-grouping inside the observatory menus
    REGIONS = [
        ("japan", "日本", "Japan"),
        ("asia", "アジア", "Asia"),
        ("oceania", "オセアニア", "Oceania"),
        ("north_america", "北アメリカ", "North America"),
        ("south_america", "南アメリカ", "South America"),
        ("europe", "ヨーロッパ", "Europe"),
        ("africa", "アフリカ", "Africa"),
        ("antarctica", "南極", "Antarctica"),
    ]

    def __init__(self, path: str | None = None):
        path = path or os.path.join(_DATA_DIR, "sites.json")
        with open(path, encoding="utf-8") as f:
            raw = json.load(f)
        self.sites: list[Site] = []
        for s in raw["sites"]:
            self.sites.append(self._mk(s))
        # world capitals (data/capitals.json, optional)
        cap_path = os.path.join(os.path.dirname(path), "capitals.json")
        if os.path.exists(cap_path):
            with open(cap_path, encoding="utf-8") as f:
                caps = json.load(f)
            have = {s.id for s in self.sites}
            # A capital that is already in the curated list as a
            # prefecture — Tokyo is both — would appear twice in the same
            # menu.  Cities listed under 主要都市 are a different menu and
            # may legitimately repeat there.
            pref_names = {x.name_ja for x in self.sites
                          if x.category == "prefecture"}
            for s in caps["sites"]:
                if s["id"] in have or s.get("name_ja") in pref_names:
                    continue
                self.sites.append(self._mk(s, category="capital"))
        # Japanese stargazing sites (optional; fetched by
        # scripts/fetch_stargazing_spots.py from the two published
        # lists, geocoded against OpenStreetMap)
        spot_path = os.path.join(os.path.dirname(path),
                                 "stargazing_spots.json")
        if os.path.exists(spot_path):
            with open(spot_path, encoding="utf-8") as f:
                spots = json.load(f)
            have = {s.id for s in self.sites}
            for s in spots["sites"]:
                if s["id"] in have:
                    continue
                # The curated list already holds a few of these.  Drop a
                # new spot when an existing site carries the same name,
                # or sits within ~3 km of it — two entries for one place
                # at slightly different coordinates help nobody, and the
                # hand-entered position is the one to trust.
                base = s.get("name_ja", "").split("（")[0].strip()
                if any(x.name_ja.split("（")[0].strip() == base or
                       (abs(x.lat_deg - s["lat_deg"]) < 0.027 and
                        abs(x.lon_deg - s["lon_deg"]) < 0.034)
                       for x in self.sites
                       if x.category in ("jp_dark_site", "observatory")):
                    continue
                self.sites.append(self._mk(s, category="jp_dark_site"))

        # the full MPC observatory register (optional; fetched by
        # scripts/fetch_mpc_observatories.py).  Curated entries win: they
        # carry a proper IANA time zone and a Japanese name.
        mpc_path = os.path.join(os.path.dirname(path),
                                "mpc_observatories.json")
        if os.path.exists(mpc_path):
            with open(mpc_path, encoding="utf-8") as f:
                obs = json.load(f)
            have_code = {s.mpc_code for s in self.sites if s.mpc_code}
            have_id = {s.id for s in self.sites}
            for s in obs["sites"]:
                if s.get("mpc_code") in have_code or s["id"] in have_id:
                    continue
                self.sites.append(self._mk(s, category="observatory"))
        # fill in the region of any site that did not declare one
        for s in self.sites:
            if not s.region:
                s.region = region_of(s.lat_deg, s.lon_deg)

        # user-defined terrain masks (spec §3: 地平線の仰角マスク):
        # data/horizon_masks.json = {site_id: [[az_deg, min_alt_deg], ...]}
        mask_path = os.path.join(os.path.dirname(path),
                                 "horizon_masks.json")
        if os.path.exists(mask_path):
            with open(mask_path, encoding="utf-8") as f:
                masks = json.load(f)
            by_id = {s.id: s for s in self.sites}
            for sid, table in masks.items():
                if sid in by_id and isinstance(table, list) and table:
                    by_id[sid].horizon = HorizonMask.from_table(table)
        self._favorites_path = os.path.join(_DATA_DIR, "favorites.json")

    @staticmethod
    def _mk(s: dict, category=None) -> Site:
        return Site(
            lat_deg=s["lat_deg"], lon_deg=s["lon_deg"],
            elev_m=s.get("elev_m", 0.0), tz=s.get("tz", "UTC"),
            name_ja=s.get("name_ja", ""), name_en=s.get("name_en", ""),
            name_kana=s.get("name_kana", ""),
            id=s["id"], category=category or s.get("category", "preset"),
            mpc_code=s.get("mpc_code"),
            country_ja=s.get("country_ja", ""),
            country_en=s.get("country_en", ""),
            region=s.get("region"))

    def group_of(self, s: Site) -> str:
        """Top-level menu a site belongs to."""
        if s.category == "prefecture":
            return "japan"
        if s.category == "jp_dark_site":
            return "jp_dark"
        if s.category == "observatory":
            return "jp_obs" if s.region == "japan" else "obs"
        if s.category == "capital" and s.region:
            return s.region
        if s.category == "world_city":
            return "world_city"
        return s.region or "world_city"

    def get(self, site_id: str) -> Site:
        if site_id.startswith("@"):
            return custom_site(site_id)
        for s in self.sites:
            if s.id == site_id:
                return s
        raise KeyError(site_id)

    @staticmethod
    def _norm(s: str) -> str:
        return unicodedata.normalize("NFKC", s).casefold()

    def search(self, query: str) -> list[Site]:
        """Partial match on Japanese or English names, id, or MPC code."""
        q = self._norm(query)
        hits = []
        for s in self.sites:
            hay = " ".join(filter(None, [s.name_ja, s.name_en, s.id,
                                         s.mpc_code or "", s.country_ja,
                                         s.country_en]))
            if q in self._norm(hay):
                hits.append(s)
        return hits

    # -- favorites (JSON, human-readable per spec §12) --
    def load_favorites(self) -> list[str]:
        if os.path.exists(self._favorites_path):
            with open(self._favorites_path, encoding="utf-8") as f:
                return json.load(f)
        return []

    def save_favorites(self, ids: list[str]):
        with open(self._favorites_path, "w", encoding="utf-8") as f:
            json.dump(ids, f, ensure_ascii=False, indent=1)
