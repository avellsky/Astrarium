"""Sun / Moon / planet physical circumstances (spec §2).

- Apparent place via frames.observe_body (DE + ERFA chain).
- Phase angle / elongation computed from the DE vectors directly
  (exact geometry, no series).
- Magnitudes: magnitudes.py (Mallama & Hilton 2018 etc.)
- Moon: phase, age, illuminated fraction, bright-limb PA (Meeus ch.48),
  optical libration & axis PA (Meeus ch.53; physical libration ≤0.04°
  omitted — documented), horizontal parallax, semidiameter.
- Sun: P / B0 / L0 (Meeus ch.29, Carrington elements).
"""
from __future__ import annotations

import math
from dataclasses import dataclass

import erfa
import numpy as np

from .constants import AU_KM, BODY_RADIUS_KM, C_AU_PER_DAY, JD_J2000
from .ephemeris import Ephemeris
from .frames import SkyPosition, observe_body, observer_bary_pv
from .observer import Site
from .timescale import Time

PLANETS = ["mercury", "venus", "mars", "jupiter", "saturn",
           "uranus", "neptune"]


# ---------------------------------------------------------------------------
@dataclass
class BodyView:
    """Apparent place + physical circumstances of a solar-system body."""
    body: str
    position: SkyPosition
    r_sun_au: object            # heliocentric distance of the body
    delta_au: object            # observer -> body distance
    phase_angle_deg: object     # Sun - body - observer angle
    elongation_deg: object      # Sun - observer - body angle
    elongation_side: object     # 'E' (evening) or 'W' (morning)
    illuminated_fraction: object
    magnitude: object
    diameter_arcsec: object     # equatorial angular diameter

    @property
    def alt(self):
        return self.position.alt

    @property
    def az(self):
        return self.position.az


def observe_planet(eph: Ephemeris, body: str, time: Time,
                   site: Site | None = None,
                   refraction: bool = True) -> BodyView:
    """Full apparent + physical circumstances for sun/moon/planets."""
    pos = observe_body(eph, body, time, site, refraction)
    d1, d2 = time.tdb
    po, vo, _ = observer_bary_pv(eph, time, site)
    pb, _ = eph.pv_bary(body, d1, d2)
    ps, _ = eph.pv_bary("sun", d1, d2)

    obs_to_body = pb - po
    delta = np.linalg.norm(obs_to_body, axis=-1)
    body_to_sun = ps - pb
    r_sun = np.linalg.norm(body_to_sun, axis=-1)
    obs_to_sun = ps - po

    def _ang(u, v):
        cu = np.linalg.norm(u, axis=-1)
        cv = np.linalg.norm(v, axis=-1)
        cosang = np.clip(np.sum(u * v, axis=-1) / (cu * cv), -1.0, 1.0)
        return np.rad2deg(np.arccos(cosang))

    if body == "sun":
        phase = np.zeros_like(delta)
        elong = np.zeros_like(delta)
    else:
        phase = _ang(body_to_sun, po - pb)   # angle at the body
        elong = _ang(obs_to_sun, obs_to_body)  # angle at the observer

    # East/West: body east of the Sun in apparent geocentric ecliptic
    # longitude -> evening sky ('E')
    lam_b, _ = pos.ecliptic(apparent=True)
    sun_pos = observe_body(eph, "sun", time, site=None, refraction=False)
    lam_s, _ = sun_pos.ecliptic(apparent=True)
    dlam = (np.asarray(lam_b) - np.asarray(lam_s)) % 360.0
    side = np.where(dlam < 180.0, "E", "W")

    k = (1.0 + np.cos(np.deg2rad(phase))) / 2.0

    from . import magnitudes
    mag = magnitudes.apparent_magnitude(
        body, r_sun, delta, phase,
        sun_vec_au=body_to_sun, obs_vec_au=po - pb,
        year=time.decimal_year)

    radius = BODY_RADIUS_KM.get(body, 0.0)
    diam = 2.0 * np.rad2deg(np.arcsin(
        np.minimum(radius / (delta * AU_KM), 1.0))) * 3600.0

    return BodyView(body=body, position=pos, r_sun_au=r_sun, delta_au=delta,
                    phase_angle_deg=phase, elongation_deg=elong,
                    elongation_side=side, illuminated_fraction=k,
                    magnitude=mag, diameter_arcsec=diam)


# ---------------------------------------------------------------------------
# Moon specifics
# ---------------------------------------------------------------------------
MOON_PHASE_NAMES = [
    ("new_moon", "新月", "New Moon"),
    ("waxing_crescent", "三日月(既朔)", "Waxing Crescent"),
    ("first_quarter", "上弦", "First Quarter"),
    ("waxing_gibbous", "十日夜〜小望月", "Waxing Gibbous"),
    ("full_moon", "満月", "Full Moon"),
    ("waning_gibbous", "居待〜更待", "Waning Gibbous"),
    ("last_quarter", "下弦", "Last Quarter"),
    ("waning_crescent", "有明の月", "Waning Crescent"),
]


def _moon_mean_elements(T):
    """Meeus ch.47 mean elements [deg]: L', D, M, M', F, Ω."""
    Lp = (218.3164477 + 481267.88123421 * T - 0.0015786 * T**2
          + T**3 / 538841.0 - T**4 / 65194000.0)
    D = (297.8501921 + 445267.1114034 * T - 0.0018819 * T**2
         + T**3 / 545868.0 - T**4 / 113065000.0)
    M = 357.5291092 + 35999.0502909 * T - 0.0001536 * T**2 + T**3 / 24490000.0
    Mp = (134.9633964 + 477198.8675055 * T + 0.0087414 * T**2
          + T**3 / 69699.0 - T**4 / 14712000.0)
    F = (93.2720950 + 483202.0175233 * T - 0.0036539 * T**2
         - T**3 / 3526000.0 + T**4 / 863310000.0)
    Om = (125.0445479 - 1934.1362891 * T + 0.0020754 * T**2
          + T**3 / 467441.0 - T**4 / 60616000.0)
    return Lp % 360, D % 360, M % 360, Mp % 360, F % 360, Om % 360


@dataclass
class MoonView(BodyView):
    age_days: float = 0.0
    phase_key: str = ""
    phase_name_ja: str = ""
    phase_name_en: str = ""
    bright_limb_pa_deg: float = 0.0     # position angle of bright limb
    libration_lon_deg: float = 0.0      # optical libration in longitude
    libration_lat_deg: float = 0.0
    axis_pa_deg: float = 0.0            # position angle of rotation axis
    horizontal_parallax_deg: float = 0.0
    semidiameter_arcsec: float = 0.0
    distance_geocentric_km: float = 0.0
    distance_topocentric_km: float = 0.0


def moon_info(eph: Ephemeris, time: Time, site: Site | None = None,
              refraction: bool = True) -> MoonView:
    bv = observe_planet(eph, "moon", time, site, refraction)
    geo = observe_body(eph, "moon", time, site=None, refraction=False)
    sun_geo = observe_body(eph, "sun", time, site=None, refraction=False)

    dist_geo_km = float(np.atleast_1d(geo.distance_au)[0]) * AU_KM
    dist_topo_km = float(np.atleast_1d(bv.delta_au)[0]) * AU_KM
    hp = math.degrees(math.asin(6378.1366 / dist_geo_km))
    sd = math.degrees(math.asin(BODY_RADIUS_KM["moon"] / dist_topo_km)) * 3600

    # --- phase / age ---
    lam_m, beta_m = geo.ecliptic(apparent=True)
    lam_s, _ = sun_geo.ecliptic(apparent=True)
    d_lam = (float(np.atleast_1d(lam_m)[0])
             - float(np.atleast_1d(lam_s)[0])) % 360.0
    synodic = 29.530588861
    age = d_lam / 360.0 * synodic          # first-order age estimate
    idx = int(((d_lam + 22.5) % 360) // 45)
    key, ja, en = MOON_PHASE_NAMES[idx]

    # --- bright limb PA (Meeus 48.5, apparent equatorial coords) ---
    a_s = math.radians(float(np.atleast_1d(sun_geo.ra_apparent)[0]))
    d_s = math.radians(float(np.atleast_1d(sun_geo.dec_apparent)[0]))
    a_m = math.radians(float(np.atleast_1d(geo.ra_apparent)[0]))
    d_m = math.radians(float(np.atleast_1d(geo.dec_apparent)[0]))
    chi = math.atan2(
        math.cos(d_s) * math.sin(a_s - a_m),
        math.sin(d_s) * math.cos(d_m)
        - math.cos(d_s) * math.sin(d_m) * math.cos(a_s - a_m))
    chi = math.degrees(chi) % 360.0

    # --- optical libration + axis PA (Meeus ch.53) ---
    T = (time.jd_tt - JD_J2000) / 36525.0
    _, _, _, _, F, Om = _moon_mean_elements(T)
    dpsi, deps = erfa.nut06a(*time.tt)
    eps = erfa.obl06(*time.tt) + deps
    I = math.radians(1.54242)
    lam = math.radians(float(np.atleast_1d(lam_m)[0]))
    beta = math.radians(float(np.atleast_1d(beta_m)[0]))
    W = lam - dpsi - math.radians(Om)
    A = math.atan2(
        math.sin(W) * math.cos(beta) * math.cos(I)
        - math.sin(beta) * math.sin(I),
        math.cos(W) * math.cos(beta))
    l_opt = (math.degrees(A) - F) % 360.0
    if l_opt > 180:
        l_opt -= 360.0
    b_opt = math.degrees(math.asin(
        -math.sin(W) * math.cos(beta) * math.sin(I)
        - math.sin(beta) * math.cos(I)))

    # axis position angle (optical part: rho=sigma=0)
    V = math.radians(Om) + dpsi
    X = math.sin(I) * math.sin(V)
    Y = math.sin(I) * math.cos(V) * math.cos(eps) - math.cos(I) * math.sin(eps)
    omega = math.atan2(X, Y)
    P_axis = math.degrees(math.asin(
        math.hypot(X, Y) * math.cos(a_m - omega)
        / math.cos(math.radians(b_opt))))

    return MoonView(
        **bv.__dict__,
        age_days=age, phase_key=key, phase_name_ja=ja, phase_name_en=en,
        bright_limb_pa_deg=chi,
        libration_lon_deg=l_opt, libration_lat_deg=b_opt,
        axis_pa_deg=P_axis % 360.0 if P_axis >= 0 else P_axis,
        horizontal_parallax_deg=hp, semidiameter_arcsec=sd,
        distance_geocentric_km=dist_geo_km,
        distance_topocentric_km=dist_topo_km)


def moon_age_days(eph: Ephemeris, time: Time) -> float:
    """Exact age: days since the preceding new moon (root-found)."""
    from .phenomena import previous_moon_phase
    t_new = previous_moon_phase(eph, time, 0)
    return time - t_new


# ---------------------------------------------------------------------------
# Sun rotation axis / Carrington coordinates (Meeus ch.29)
# ---------------------------------------------------------------------------
@dataclass
class SunAxis:
    p_deg: float      # position angle of rotation axis (+ = east)
    b0_deg: float     # heliographic latitude of disk center
    l0_deg: float     # Carrington longitude of disk center
    carrington_rotation: int


def sun_axis(eph: Ephemeris, time: Time) -> SunAxis:
    """P, B0, L0 (Meeus ch.29).  Verified vs Meeus example 29.a."""
    jde = time.jd_tdb
    theta = (jde - 2398220.0) * 360.0 / 25.38
    inc = math.radians(7.25)
    k = 73.6667 + 1.3958333 * (jde - 2396758.0) / 36525.0

    geo = observe_body(eph, "sun", time, site=None, refraction=False)
    lam_app, _ = geo.ecliptic(apparent=True)
    lam = math.radians(float(np.atleast_1d(lam_app)[0]))
    dpsi, deps = erfa.nut06a(*time.tt)
    eps = erfa.obl06(*time.tt) + deps

    kr = math.radians(k)
    x = math.atan(-math.cos(lam) * math.tan(eps))
    y = math.atan(-math.cos(lam - kr) * math.tan(inc))
    P = math.degrees(x + y)
    B0 = math.degrees(math.asin(math.sin(lam - kr) * math.sin(inc)))
    eta = math.degrees(math.atan2(-math.sin(lam - kr) * math.cos(inc),
                                  -math.cos(lam - kr)))
    L0 = (eta - theta) % 360.0
    crn = int((jde - 2398167.329) / 27.2753) + 1  # Carrington rotation no.
    return SunAxis(p_deg=P, b0_deg=B0, l0_deg=L0, carrington_rotation=crn)
