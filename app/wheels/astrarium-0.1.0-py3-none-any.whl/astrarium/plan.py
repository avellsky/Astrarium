"""Observation planning (spec: 観測計画モード).

Given a site and a local calendar date, :class:`NightPlan` derives the
usable night (astronomical dusk -> dawn via :mod:`astrarium.riseset`),
tracks targets through the night (altitude, airmass, moon separation),
summarizes observability and produces a simple greedy observing order.

Formulas & sources
------------------
- Airmass: Kasten & Young (1989) interpolation formula
  (frames.airmass_kasten_young).
- Twilight boundaries: geometric solar altitude -18 deg / -12 deg
  (Explanatory Supplement; riseset.twilight_times).
- Moonlight penalty: qualitative index inspired by Krisciunas &
  Schaefer (1991, PASP 103, 1033) — their full model predicts sky
  brightness in mag/arcsec^2 from the scattering function
  f(rho) ~ Rayleigh (1 + cos^2 rho) + Mie terms; here only the
  monotonic shape is retained (see :func:`sky_brightness_penalty`).
- Zenith limiting magnitudes per Bortle class: Bortle (2001),
  Sky & Telescope, Feb. 2001 (approximate values).

The scheduling heuristic in :meth:`NightPlan.optimize_order` is a greedy
nearest-culmination rule, *not* an optimal (TSP-like) scheduler; it is a
planning aid only.
"""
from __future__ import annotations

import datetime as _dt
import json
import os
from dataclasses import dataclass

import numpy as np

from .bodies import observe_planet
from .ephemeris import Ephemeris
from .frames import (airmass_kasten_young, angular_separation_deg,
                     observe_body, observe_star)
from .observer import Site
from .riseset import dark_windows as _dark_windows
from .riseset import twilight_times
from .timescale import Time, linspace


# ---------------------------------------------------------------------------
@dataclass
class PlanTarget:
    """A target for night planning.

    kind='fixed' uses ra_deg/dec_deg (ICRS).  Any other value is taken
    as a solar-system body name for the ephemeris ('mars', 'moon', ...),
    in which case ra_deg/dec_deg are ignored.
    """
    name: str
    ra_deg: float
    dec_deg: float
    kind: str = "fixed"
    vmag: float | None = None
    note: str = ""


# ---------------------------------------------------------------------------
class NightPlan:
    """Planning context for one night at a site.

    The night is defined as astronomical dusk (sun altitude falling
    through -18 deg) on `date_local` to astronomical dawn (rising
    through -18 deg) on the following morning.  At high latitudes in
    summer there may be no astronomical night; the plan then falls back
    to nautical twilight (-12 deg) and finally to local midnight +/- 4 h,
    recording the degradation in `self.warning` (spec §6: 白夜 -> なし).
    """

    def __init__(self, eph: Ephemeris, site: Site,
                 date_local: _dt.date, tz: str | None = None):
        self.eph = eph
        self.site = site
        self.date_local = date_local
        self.tz = tz or site.tz
        self.warning: str | None = None

        # search window: local noon of date_local -> local noon next day
        noon = _dt.datetime(date_local.year, date_local.month,
                            date_local.day, 12, 0, 0)
        t0 = Time.from_local(noon, self.tz)
        t1 = t0 + 1.0
        tw = twilight_times(eph, site, t0, t1)

        dusk, dawn = self._pick(tw, "astronomical")
        if dusk is None or dawn is None:
            dusk, dawn = self._pick(tw, "nautical")
            if dusk is not None and dawn is not None:
                self.warning = ("no astronomical night at this "
                                "latitude/date; using nautical twilight "
                                "(sun < -12 deg)")
        if dusk is None or dawn is None:
            # polar-summer fallback: local midnight +/- 4 h
            mid = Time.from_local(
                _dt.datetime.combine(date_local + _dt.timedelta(days=1),
                                     _dt.time(0, 0)), self.tz)
            dusk, dawn = mid - (4.0 / 24.0), mid + (4.0 / 24.0)
            self.warning = ("no astronomical/nautical night (midnight "
                            "sun); using local midnight +/- 4 h window")

        self.t_dusk: Time = dusk
        self.t_dawn: Time = dawn
        #: moonless astronomical-dark intervals within the night
        self.dark_windows = _dark_windows(eph, site, self.t_dusk,
                                          self.t_dawn)

    @staticmethod
    def _pick(tw: dict, kind: str):
        """First <kind>_dusk and the first <kind>_dawn after it."""
        dusks = tw.get(f"{kind}_dusk", [])
        dawns = tw.get(f"{kind}_dawn", [])
        if not dusks:
            return None, None
        dusk = dusks[0]
        for d in dawns:
            if d.jd_tt > dusk.jd_tt:
                return dusk, d
        return dusk, None

    # -----------------------------------------------------------------
    def track(self, target: PlanTarget, n: int = 49) -> dict:
        """Sample a target's track through the night.

        Returns dict with 'times' (list[Time]), 'alt', 'az', 'airmass'
        (Kasten & Young 1989), 'moon_sep' [deg], 'best_time' (Time of
        maximum altitude), 'max_alt' [deg], 'hours_above_30' [h].
        Fixed targets use one vectorized observe_star call; ephemeris
        bodies loop over the (<= n) samples.
        """
        times = linspace(self.t_dusk, self.t_dawn, n)
        tt2 = np.atleast_1d(times.tt2)
        time_list = [Time(times.tt1, float(x)) for x in tt2]

        if target.kind == "fixed":
            p = observe_star(target.ra_deg, target.dec_deg, times,
                             self.site)
            alt = np.atleast_1d(np.asarray(p.alt, dtype=float))
            az = np.atleast_1d(np.asarray(p.az, dtype=float))
            ra = np.atleast_1d(np.asarray(p.ra_apparent, dtype=float))
            dec = np.atleast_1d(np.asarray(p.dec_apparent, dtype=float))
        else:
            alt = np.empty(n)
            az = np.empty(n)
            ra = np.empty(n)
            dec = np.empty(n)
            for i, t in enumerate(time_list):
                bv = observe_planet(self.eph, target.kind, t, self.site)
                alt[i] = float(np.atleast_1d(bv.position.alt)[0])
                az[i] = float(np.atleast_1d(bv.position.az)[0])
                ra[i] = float(np.atleast_1d(bv.position.ra_apparent)[0])
                dec[i] = float(np.atleast_1d(bv.position.dec_apparent)[0])

        moon = observe_body(self.eph, "moon", times, self.site,
                            refraction=False)
        moon_sep = np.atleast_1d(angular_separation_deg(
            ra, dec, np.asarray(moon.ra_apparent, dtype=float),
            np.asarray(moon.dec_apparent, dtype=float)))

        airmass = airmass_kasten_young(alt)
        ibest = int(np.argmax(alt))
        span_h = (self.t_dawn - self.t_dusk) * 24.0
        hours_above_30 = float(np.count_nonzero(alt > 30.0)) / n * span_h

        return {
            "times": time_list,
            "alt": alt, "az": az, "airmass": airmass,
            "moon_sep": moon_sep,
            "best_time": time_list[ibest],
            "max_alt": float(alt[ibest]),
            "hours_above_30": hours_above_30,
            # bookkeeping used by summarize()
            "_best_index": ibest, "_n": n,
        }

    # -----------------------------------------------------------------
    def summarize(self, targets: list[PlanTarget]) -> list[dict]:
        """One observability row per target (spec: 観測計画モード一覧).

        'observable' means max altitude > 30 deg and more than half an
        hour spent above 30 deg (a common practical airmass < 2 rule).
        'transit_within_night' is True when the altitude maximum falls
        strictly inside the night (i.e. the target culminates between
        dusk and dawn rather than peaking at a boundary).
        """
        rows = []
        for tgt in targets:
            tr = self.track(tgt)
            ib, n = tr["_best_index"], tr["_n"]
            rows.append({
                "name": tgt.name,
                "max_alt": tr["max_alt"],
                "best_time": tr["best_time"].iso_local(self.tz),
                "hours_above_30": tr["hours_above_30"],
                "min_moon_sep": float(np.min(tr["moon_sep"])),
                "transit_within_night": 0 < ib < n - 1,
                "observable": bool(tr["max_alt"] > 30.0
                                   and tr["hours_above_30"] > 0.5),
            })
        return rows

    # -----------------------------------------------------------------
    def optimize_order(self, targets: list[PlanTarget],
                       start: Time | None = None,
                       end: Time | None = None) -> list[PlanTarget]:
        """Greedy observing order (heuristic, NOT TSP-optimal).

        Each target is best observed near its culmination ('best_time'
        = altitude maximum within the night).  Starting the clock at
        `start` (default dusk), repeatedly pick the not-yet-scheduled
        target whose best_time is nearest the current clock, then
        advance the clock by an assumed 30 minutes per observation.
        This greedy nearest-culmination rule is a documented heuristic:
        it produces a sensible, roughly chronological schedule but makes
        no optimality claim (slew times, priorities and exposure lengths
        are ignored).
        """
        clock = (start or self.t_dusk).jd_tt
        end_jd = (end or self.t_dawn).jd_tt
        remaining = list(targets)
        best_jd = {id(t): self.track(t)["best_time"].jd_tt
                   for t in remaining}
        order: list[PlanTarget] = []
        while remaining:
            pick = min(remaining, key=lambda t: abs(best_jd[id(t)] - clock))
            order.append(pick)
            remaining.remove(pick)
            clock = min(clock + 30.0 / 1440.0, end_jd)
        return order


# ---------------------------------------------------------------------------
def sky_brightness_penalty(moon_alt_deg: float, moon_illum: float,
                           sep_deg: float) -> float:
    """Qualitative moonlight-interference index, 0 (dark) .. 5 (worst).

    Simplified from Krisciunas & Schaefer (1991, PASP 103, 1033), whose
    scattering function combines a Rayleigh term ~(1 + cos^2 rho) and a
    forward-scattering Mie term decreasing with the moon-target
    separation rho.  This helper keeps only the monotonic behaviour
    needed for planning:

    - 0 when the moon is below the horizon;
    - otherwise ``5 * illum * (1.2 + cos(sep)) / 2.2`` clipped to [0, 5]:
      increasing in illuminated fraction, decreasing with separation
      (cos is monotonically decreasing on [0, 180] deg).

    It is a qualitative planning aid, *not* a sky-brightness model in
    mag/arcsec^2 — use the full K&S model for photometric work.
    """
    if moon_alt_deg <= 0.0:
        return 0.0
    illum = float(np.clip(moon_illum, 0.0, 1.0))
    scatter = 1.2 + np.cos(np.deg2rad(np.clip(sep_deg, 0.0, 180.0)))
    return float(np.clip(5.0 * illum * scatter / 2.2, 0.0, 5.0))


#: Approximate zenith V limiting magnitude per Bortle class
#: (Bortle 2001, Sky & Telescope Feb. 2001 — indicative values only;
#: individual observers vary by several tenths of a magnitude).
_BORTLE_LIMITING_MAG = {1: 21.9, 2: 21.7, 3: 21.4, 4: 20.9, 5: 20.3,
                        6: 19.5, 7: 18.8, 8: 18.0, 9: 17.5}


def bortle_limiting_mag(bortle: int) -> float:
    """Zenith V limiting magnitude for a Bortle class 1..9.

    Source: Bortle (2001), "Introducing the Bortle Dark-Sky Scale",
    Sky & Telescope, Feb. 2001 (approximate table values).
    """
    return _BORTLE_LIMITING_MAG[int(bortle)]


# ---------------------------------------------------------------------------
class ObservationLog:
    """Human-readable JSON observation log (spec: 観測ログ, §12).

    Storage is a single JSON list file (UTF-8, indented, ensure_ascii
    off) so it stays hand-editable.  Each entry gets an auto-increment
    ``id`` and a ``created_at`` UTC timestamp.
    """

    def __init__(self, path: str):
        self.path = str(path)
        if not os.path.exists(self.path):
            self._save([])

    # -- persistence ---------------------------------------------------
    def _load(self) -> list[dict]:
        with open(self.path, encoding="utf-8") as f:
            return json.load(f)

    def _save(self, entries: list[dict]):
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(entries, f, ensure_ascii=False, indent=1)

    # -- API -------------------------------------------------------------
    def add(self, target: str, time_utc_iso: str, equipment: str = "",
            notes: str = "", site_id: str = "") -> dict:
        """Append one entry; returns the persisted record."""
        entries = self._load()
        entry = {
            "id": (max((e["id"] for e in entries), default=0) + 1),
            "target": target,
            "time_utc": time_utc_iso,
            "equipment": equipment,
            "notes": notes,
            "site_id": site_id,
            "created_at": _dt.datetime.now(_dt.timezone.utc)
            .strftime("%Y-%m-%dT%H:%M:%SZ"),
        }
        entries.append(entry)
        self._save(entries)
        return entry

    def search(self, text: str | None = None, target: str | None = None,
               since_iso: str | None = None) -> list[dict]:
        """Filter entries: free text (any field), exact-ish target
        (case-insensitive substring), and/or time_utc >= since_iso
        (ISO-8601 strings compare lexicographically)."""
        out = []
        for e in self._load():
            if target is not None and \
                    target.casefold() not in e["target"].casefold():
                continue
            if since_iso is not None and e["time_utc"] < since_iso:
                continue
            if text is not None:
                hay = " ".join(str(e.get(k, "")) for k in
                               ("target", "equipment", "notes",
                                "site_id")).casefold()
                if text.casefold() not in hay:
                    continue
            out.append(e)
        return out

    def all(self) -> list[dict]:
        return self._load()


# ---------------------------------------------------------------------------
# polar-alignment aid (spec §10: 極軸合わせ支援)
# ---------------------------------------------------------------------------
POLARIS = {"name": "Polaris", "ra_deg": 37.95456067, "dec_deg": 89.26410897,
           "pmra_mas_yr": 44.48, "pmdec_mas_yr": -11.85,
           "parallax_mas": 7.54}   # HIP 11767, ICRS J2000


def polaris_hour_angle(eph, time, site):
    """Polar-scope aid: Polaris' local hour angle & position in the field.

    Returns a dict with
    - ``ha_hours``: apparent local hour angle of Polaris (0..24 h;
      0 = upper culmination — Polaris directly ABOVE the pole),
    - ``clock_position``: the usual polar-scope clock face (12 = up,
      6 = down) for an *inverting* polar scope, i.e. the value engraved
      on typical reticles: clock = (ha_hours + 6) mod 12 ... documented
      below,
    - ``separation_arcmin``: current angular distance from the true pole
      (changes slowly with precession; ~38' in 2026),
    - ``az``/``alt``: observed direction (refraction on).

    Reticle convention: most polar scopes show an inverted field, so
    Polaris at upper culmination (HA=0) appears at the *6 o'clock*
    position.  clock_position follows that convention:
    clock = ((ha_hours * 15 + 180) deg) mapped to 12-hour dial.
    """
    import numpy as np
    from .frames import observe_star, angular_separation_deg, \
        icrs_to_of_date
    sp = observe_star(POLARIS["ra_deg"], POLARIS["dec_deg"], time, site,
                      refraction=True,
                      pmra_mas_yr=POLARIS["pmra_mas_yr"],
                      pmdec_mas_yr=POLARIS["pmdec_mas_yr"],
                      parallax_mas=POLARIS["parallax_mas"])
    ha = float(np.atleast_1d(sp.hour_angle_h)[0]) % 24.0
    # separation from the true (of-date) celestial pole
    sep = 90.0 - float(np.atleast_1d(sp.dec_apparent)[0])
    clock = ((ha * 15.0 + 180.0) % 360.0) / 30.0   # 12-hour dial
    return {"ha_hours": ha, "clock_position": clock,
            "separation_arcmin": sep * 60.0,
            "az": float(np.atleast_1d(sp.az)[0]),
            "alt": float(np.atleast_1d(sp.alt)[0])}
