"""Two-body orbit propagation for asteroids, comets & moons (spec §2).

Method: universal-variable Kepler solution propagated from the
perihelion state vector (Danby 1992 §6.9; Stumpff functions), giving a
single well-conditioned code path for elliptic, near-parabolic,
parabolic and hyperbolic orbits (e ≥ 0 arbitrary).

Element sets accepted:
- MPC/JPL style: epoch, e, q (or a), i, Ω, ω, tp (or M at epoch), all
  angles in ecliptic & mean equinox J2000.
- JPL Horizons osculating elements JSON (scripts/fetch_horizons.py).
- MPC one-line asteroid orbit format (fixed columns).

Accuracy: pure two-body — no planetary perturbations or non-gravitational
forces.  Against JPL Horizons (full n-body), errors grow with time from
the osculating epoch; typically ≲1" within weeks and a few arcsec over
months for main-belt asteroids (verified in tests/test_orbits.py).
Refresh elements from MPC/JPL for critical predictions (spec §11
"予報帯評価に足る精度" is met near the element epoch).

Magnitudes:
- Asteroids: H-G system (Bowell et al. 1989).
- Comets:    m1 = M1 + 5 log10 Δ + K1 log10 r  (= H + 5logΔ + 2.5n·log r,
             spec §2; K1 = 2.5 n).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import erfa
import numpy as np

from .constants import AU_KM, C_AU_PER_DAY
from .ephemeris import Ephemeris
from .observer import Site
from .timescale import Time

GAUSSIAN_K = 0.01720209895
MU_SUN = GAUSSIAN_K ** 2          # au^3/day^2

# mean ecliptic J2000 -> ICRS rotation (transpose of erfa.ecm06 at J2000)
_ECL2ICRS = erfa.ecm06(2451545.0, 0.0).T


# ---------------------------------------------------------------------------
def _stumpff(z):
    """Stumpff C(z), S(z) with series near zero."""
    z = np.asarray(z, dtype=float)
    C = np.empty_like(z)
    S = np.empty_like(z)
    small = np.abs(z) < 1e-8
    zp = z > 1e-8
    zn = z < -1e-8
    if np.any(zp):
        sz = np.sqrt(z[zp])
        C[zp] = (1 - np.cos(sz)) / z[zp]
        S[zp] = (sz - np.sin(sz)) / sz**3
    if np.any(zn):
        sz = np.sqrt(-z[zn])
        C[zn] = (np.cosh(sz) - 1) / (-z[zn])
        S[zn] = (np.sinh(sz) - sz) / sz**3
    if np.any(small):
        zz = z[small]
        C[small] = 0.5 - zz / 24.0 + zz * zz / 720.0
        S[small] = 1.0 / 6.0 - zz / 120.0 + zz * zz / 5040.0
    return C, S


@dataclass
class Elements:
    """Keplerian elements, ecliptic & mean equinox J2000 (heliocentric or
    planetocentric depending on `mu`)."""
    q_au: float                 # perihelion distance
    e: float
    incl_deg: float
    node_deg: float             # Ω
    argp_deg: float             # ω
    tp_jd_tdb: float            # perihelion passage time
    mu: float = MU_SUN          # GM [au^3/day^2]
    name: str = ""
    # magnitudes: asteroids H/G, comets M1/K1
    H: float | None = None
    G: float = 0.15
    M1: float | None = None
    K1: float | None = None
    kind: str = "asteroid"      # 'asteroid' | 'comet' | 'moon'
    epoch_jd_tdb: float | None = None

    # ---- constructors ----
    @classmethod
    def from_mpc(cls, *, epoch_jd_tt, a_au=None, q_au=None, e=0.0,
                 incl_deg=0.0, node_deg=0.0, argp_deg=0.0,
                 M_deg=None, tp_jd_tt=None, H=None, G=0.15,
                 M1=None, K1=None, name="", kind="asteroid"):
        """From MPC-style elements (angles deg, epoch TT≈TDB)."""
        if q_au is None:
            if a_au is None or e >= 1.0:
                raise ValueError("need q for parabolic/hyperbolic")
            q_au = a_au * (1.0 - e)
        if tp_jd_tt is None:
            if M_deg is None:
                raise ValueError("need tp or M")
            if e >= 1.0:
                raise ValueError("M given for e>=1 unsupported; provide tp")
            a = q_au / (1.0 - e)
            n = math.sqrt(MU_SUN / a**3)          # rad/day
            m = math.radians(M_deg % 360.0)
            if m > math.pi:
                m -= 2 * math.pi
            tp_jd_tt = epoch_jd_tt - m / n
        return cls(q_au=q_au, e=e, incl_deg=incl_deg, node_deg=node_deg,
                   argp_deg=argp_deg, tp_jd_tdb=tp_jd_tt, name=name,
                   H=H, G=G, M1=M1, K1=K1, kind=kind,
                   epoch_jd_tdb=epoch_jd_tt)

    @classmethod
    def from_horizons_json(cls, d: dict, name="", kind="asteroid",
                           center_mu=None, H=None, G=0.15,
                           M1=None, K1=None):
        """From scripts/fetch_horizons.py element dicts (KM-S units).

        mu is derived self-consistently from n²a³ unless given.
        """
        a_au = d["a_km"] / AU_KM
        n_rad_day = math.radians(d["n_deg_s"]) * 86400.0
        if center_mu is None:
            center_mu = n_rad_day**2 * abs(a_au)**3
        return cls(q_au=d["qr_km"] / AU_KM, e=d["ec"],
                   incl_deg=d["in_deg"], node_deg=d["om_deg"],
                   argp_deg=d["w_deg"], tp_jd_tdb=d["tp_jd_tdb"],
                   mu=center_mu, name=name, kind=kind, H=H, G=G,
                   M1=M1, K1=K1, epoch_jd_tdb=d["epoch_jd_tdb"])

    @classmethod
    def from_mpc_1line(cls, line: str):
        """Parse the MPC one-line orbit format (MPCORB.DAT row)."""
        def f(a, b):
            return float(line[a:b])
        H = None
        try:
            H = float(line[8:13])
        except ValueError:
            pass
        G = 0.15
        try:
            G = float(line[14:19])
        except ValueError:
            pass
        epoch = _unpack_mpc_epoch(line[20:25])
        M = f(26, 35)
        argp = f(37, 46)
        node = f(48, 57)
        incl = f(59, 68)
        e = f(70, 79)
        n = f(80, 91)
        a = f(92, 103)
        name = line[166:194].strip() if len(line) > 166 else line[0:7].strip()
        return cls.from_mpc(epoch_jd_tt=epoch, a_au=a, e=e, incl_deg=incl,
                            node_deg=node, argp_deg=argp, M_deg=M,
                            H=H, G=G, name=name)

    # ---- geometry ----
    def _perifocal_axes(self):
        i = math.radians(self.incl_deg)
        om = math.radians(self.node_deg)
        w = math.radians(self.argp_deg)
        co, so = math.cos(om), math.sin(om)
        ci, si = math.cos(i), math.sin(i)
        cw, sw = math.cos(w), math.sin(w)
        # P: unit vector to perihelion; Q: 90° ahead in orbit plane
        P = np.array([co * cw - so * sw * ci,
                      so * cw + co * sw * ci,
                      sw * si])
        Q = np.array([-co * sw - so * cw * ci,
                      -so * sw + co * cw * ci,
                      cw * si])
        return P, Q

    def state_ecliptic(self, jd_tdb):
        """Heliocentric (or planetocentric) position [au] & velocity
        [au/day] in ecliptic J2000, via universal variables from the
        perihelion state (vr=0 there; robust for all e)."""
        jd = np.atleast_1d(np.asarray(jd_tdb, dtype=float))
        q, e, mu = self.q_au, self.e, self.mu
        alpha = (1.0 - e) / q                   # 1/a (0 for parabola)
        sqmu = math.sqrt(mu)
        dt = jd - self.tp_jd_tdb

        # solve sqrt(mu)*dt = (1 - q*alpha) chi^3 S(alpha chi^2) + q chi
        chi = np.where(
            np.abs(alpha) > 1e-12,
            sqmu * dt * np.abs(alpha),          # elliptic/hyperbolic guess
            np.cbrt(3.0 * sqmu * np.abs(dt))
            * np.sign(dt))                      # parabolic guess
        chi = np.asarray(chi, dtype=float)
        for _ in range(60):
            z = alpha * chi * chi
            C, S = _stumpff(z)
            F = (1.0 - q * alpha) * chi**3 * S + q * chi - sqmu * dt
            dF = (1.0 - q * alpha) * chi * chi * C + q
            step = F / dF
            chi -= step
            if np.all(np.abs(step) < 1e-14 * np.maximum(1.0, np.abs(chi))):
                break

        z = alpha * chi * chi
        C, S = _stumpff(z)
        # Lagrange f, g from the perihelion state (r0 = q, vr0 = 0)
        f = 1.0 - chi * chi * C / q
        g = dt - chi**3 * S / sqmu
        r = q + (1.0 - q * alpha) * chi * chi * C   # |r| (vr0 = 0)
        fdot = -sqmu / (r * q) * chi * (1.0 - z * S)
        gdot = 1.0 - chi * chi * C / r

        P, Q = self._perifocal_axes()
        vp = math.sqrt(mu * (1.0 + e) / q)      # perihelion speed
        r0 = q * P
        v0 = vp * Q
        pos = (f[..., None] * r0 + g[..., None] * v0)
        vel = (fdot[..., None] * r0 + gdot[..., None] * v0)
        return pos, vel

    def state_icrs(self, jd_tdb):
        p, v = self.state_ecliptic(jd_tdb)
        return p @ _ECL2ICRS.T, v @ _ECL2ICRS.T

    # ---- magnitudes ----
    def apparent_magnitude(self, r_au, delta_au, phase_angle_deg):
        if self.kind == "comet" and self.M1 is not None:
            k1 = self.K1 if self.K1 is not None else 10.0
            return (self.M1 + 5.0 * np.log10(delta_au)
                    + k1 * np.log10(r_au))
        if self.H is not None:
            a = np.deg2rad(np.asarray(phase_angle_deg, dtype=float))
            ta2 = np.tan(a / 2.0)
            phi1 = np.exp(-3.33 * ta2**0.63)
            phi2 = np.exp(-1.87 * ta2**1.22)
            with np.errstate(divide="ignore"):
                psi = np.where(
                    a < np.deg2rad(120.0),
                    -2.5 * np.log10((1 - self.G) * phi1 + self.G * phi2),
                    np.nan)
            return self.H + 5.0 * np.log10(r_au * delta_au) + psi
        return np.nan


def _unpack_mpc_epoch(packed: str) -> float:
    """MPC packed epoch (e.g. 'K261L') -> JD TT (0h TT of that date)."""
    cent = {"I": 1800, "J": 1900, "K": 2000}[packed[0]]
    year = cent + int(packed[1:3])

    def ch(c):
        return int(c) if c.isdigit() else ord(c) - ord("A") + 10
    month = ch(packed[3])
    day = ch(packed[4])
    d1, d2 = erfa.cal2jd(year, month, day)
    return d1 + d2 + 0.5


# ---------------------------------------------------------------------------
# apparent places of small bodies (same chain as frames.observe_body)
# ---------------------------------------------------------------------------
def observe_elements(eph: Ephemeris, el: Elements, time: Time,
                     site: Site | None = None, refraction: bool = True):
    """Topocentric apparent place + magnitude for an object defined by
    heliocentric elements.  Returns a bodies.BodyView."""
    from .bodies import BodyView
    from .frames import _add_observed, _unit, observer_bary_pv
    d1, d2 = time.tdb
    po, vo, rc2i = observer_bary_pv(eph, time, site)

    def body_bary(tau):
        jd = d1 + (d2 - tau)
        ph, _ = el.state_icrs(jd)                    # heliocentric ICRS
        ps, _ = eph.pv_bary("sun", d1, d2 - tau)
        return ps + ph

    tau = 0.0
    for _ in range(4):
        pb = body_bary(tau)
        dvec = pb - po
        dist = np.linalg.norm(dvec, axis=-1)
        tau = dist / C_AU_PER_DAY
    delta = dist
    u = dvec / delta[..., None]

    ps_now, _ = eph.pv_bary("sun", d1, d2)
    helio = pb - (eph.pv_bary("sun", d1, d2 - tau)[0])
    r_sun = np.linalg.norm(helio, axis=-1)

    # aberration + GCRS->CIRS (deflection negligible for small bodies
    # except sun-grazers; skipped, documented)
    v_c = vo / C_AU_PER_DAY
    bm1 = np.sqrt(1.0 - np.sum(v_c * v_c, axis=-1))
    em = np.linalg.norm(po - ps_now, axis=-1)
    u2 = erfa.ab(u, v_c, em, bm1)
    p_cirs = np.einsum("...ij,...j->...i", rc2i, u2)
    ri, di = erfa.c2s(p_cirs)
    eo = erfa.eo06a(*time.tt)

    from .frames import SkyPosition
    ra_icrs, dec_icrs = erfa.c2s(u)
    pos = SkyPosition(
        ra_icrs=np.rad2deg(ra_icrs % (2 * np.pi)),
        dec_icrs=np.rad2deg(dec_icrs),
        ra_apparent=np.rad2deg((ri - eo) % (2 * np.pi)),
        dec_apparent=np.rad2deg(di),
        ra_cirs=np.rad2deg(ri % (2 * np.pi)), dec_cirs=np.rad2deg(di),
        distance_au=delta, light_time_min=tau * 1440.0,
        time=time, site=site)
    if site is not None:
        _add_observed(pos, ri, di, time, site, refraction)

    # phase angle at the body (helio points sun->body, so body->sun = -helio)
    obs_from_body = po - pb
    phase = np.rad2deg(np.arccos(np.clip(
        np.sum(-helio * obs_from_body, axis=-1)
        / (r_sun * np.linalg.norm(obs_from_body, axis=-1)), -1, 1)))

    obs_to_sun = ps_now - po
    elong = np.rad2deg(np.arccos(np.clip(
        np.sum(obs_to_sun * dvec, axis=-1)
        / (em * delta), -1, 1)))

    mag = el.apparent_magnitude(r_sun, delta, phase)
    k = (1.0 + np.cos(np.deg2rad(phase))) / 2.0
    # Evening or morning object: east of the Sun in ecliptic longitude
    # sets after it, west of it rises before.  Both directions are
    # rotated into the ecliptic frame of date and compared there, the
    # same test the planets use — this used to be reported as "?".
    rm = erfa.ecm06(*time.tt)
    to_ecl = lambda v: np.einsum("ij,...j->...i", rm, v)   # noqa: E731
    b_ecl, s_ecl = to_ecl(dvec), to_ecl(obs_to_sun)
    lam_b = np.arctan2(b_ecl[..., 1], b_ecl[..., 0])
    lam_s = np.arctan2(s_ecl[..., 1], s_ecl[..., 0])
    dlam = np.rad2deg(lam_b - lam_s) % 360.0
    side = np.where(dlam < 180.0, "E", "W")
    return BodyView(body=el.name or "smallbody", position=pos,
                    r_sun_au=r_sun, delta_au=delta,
                    phase_angle_deg=phase, elongation_deg=elong,
                    elongation_side=side,
                    illuminated_fraction=k, magnitude=mag,
                    diameter_arcsec=0.0)
