"""SVG star chart generation (print / export; the GUI is separate).

Projection (all-sky): azimuthal equidistant centered on the zenith,
r ∝ 90° − altitude, north up and EAST ON THE LEFT — the sky convention
of a planisphere held overhead.  ``mirror=True`` flips east/west for
finder-chart / photographic use.  The horizon view is a simple
rectangular az/alt projection of an azimuth window.

Rendering is fully vectorized: star, line-endpoint, DSO and ecliptic
positions each come from a single observe_star call, so an all-sky
chart at V<=6.5 renders well under a second.

Star data credit: Yale BSC5 (Hoffleit & Warren 1991); constellation
lines derived from Stellarium (GPL-2.0+) — see catalog.py.
"""
from __future__ import annotations

from dataclasses import dataclass
from xml.sax.saxutils import escape

import numpy as np

from .bodies import PLANETS, observe_planet
from .catalog import DSOCatalog, StarCatalog
from .ephemeris import Ephemeris
from .frames import ecliptic_to_icrs, observe_star
from .observer import Site
from .timescale import Time

# ---------------------------------------------------------------------------
BODY_NAMES = {
    "sun": ("太陽", "Sun"), "moon": ("月", "Moon"),
    "mercury": ("水星", "Mercury"), "venus": ("金星", "Venus"),
    "mars": ("火星", "Mars"), "jupiter": ("木星", "Jupiter"),
    "saturn": ("土星", "Saturn"), "uranus": ("天王星", "Uranus"),
    "neptune": ("海王星", "Neptune"),
}
_CARDINAL = {"ja": {"N": "北", "E": "東", "S": "南", "W": "西"},
             "en": {"N": "N", "E": "E", "S": "S", "W": "W"}}
_WINDS8 = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
_WINDS8_JA = ["北", "北東", "東", "南東", "南", "南西", "西", "北西"]


@dataclass
class ChartOptions:
    """Element toggles and styling for the SVG charts."""
    vmag_limit: float = 5.5
    show_constellation_lines: bool = True
    show_constellation_names: bool = True
    show_star_names: bool = True          # labels only for vmag <= 1.5
    show_planets: bool = True
    show_moon: bool = True
    show_dso: bool = False
    show_grid: bool = True                # alt 30/60 circles + N/E/S/W
    show_ecliptic: bool = True
    mirror: bool = False                  # flip east/west (finder use)
    night_vision: bool = False            # red-on-black
    monochrome: bool = False              # black-on-white for print
    lang: str = "ja"
    size_px: int = 800
    min_alt: float = 0.0


def _palette(opts: ChartOptions, dark_sky: bool) -> dict:
    if opts.night_vision:
        return {"bg": "#000000", "frame": "#900000", "grid": "#500000",
                "line": "#700000", "text": "#c00000", "star": "#b00000",
                "ecliptic": "#900000", "body": "#d00000", "dso": "#800000"}
    if opts.monochrome:
        return {"bg": "#ffffff", "frame": "#000000", "grid": "#aaaaaa",
                "line": "#888888", "text": "#333333", "star": "#000000",
                "ecliptic": "#666666", "body": "#000000", "dso": "#777777"}
    return {"bg": "#000510" if dark_sky else "#16264d",
            "frame": "#5a6a8a", "grid": "#3a4a66", "line": "#33507a",
            "text": "#9fb0d0", "star": None,  # None -> B-V color ramp
            "ecliptic": "#b98a3c", "body": "#ffd27f", "dso": "#6fa8a0"}


def _star_color(bv, pal) -> str:
    """Simple 4-step blue-white-yellow-orange B-V ramp."""
    if pal["star"] is not None:
        return pal["star"]
    if bv is None:
        return "#f0f2f8"
    if bv < 0.0:
        return "#a3b8ff"
    if bv < 0.6:
        return "#f0f2f8"
    if bv < 1.2:
        return "#ffe2a8"
    return "#ff9c60"


def _star_radius(vmag, scale=1.0) -> float:
    return float(np.clip(0.6 * (6.8 - vmag), 0.4, 6.0)) * scale


def _f(x) -> str:
    return f"{float(x):.1f}"


def _text(x, y, s, fill, size, anchor="middle", extra="") -> str:
    return (f'<text x="{_f(x)}" y="{_f(y)}" fill="{fill}" '
            f'font-size="{_f(size)}" font-family="sans-serif" '
            f'text-anchor="{anchor}"{extra}>{escape(s)}</text>')


def _sun_alt(eph: Ephemeris, time: Time, site: Site) -> float:
    return float(np.atleast_1d(
        observe_planet(eph, "sun", time, site, refraction=False).alt)[0])


def _bodies_to_draw(opts: ChartOptions):
    bodies = []
    if opts.show_planets:
        bodies += ["sun"] + PLANETS
    if opts.show_moon:
        bodies.append("moon")
    return bodies


def _body_marker(bv_body, x, y, pal, opts, fs) -> list[str]:
    name = BODY_NAMES[bv_body.body][0 if opts.lang == "ja" else 1]
    r = 7.0 if bv_body.body in ("sun", "moon") else 3.5
    r *= opts.size_px / 800.0
    out = [f'<circle cx="{_f(x)}" cy="{_f(y)}" r="{_f(r)}" '
           f'fill="{pal["body"]}" stroke="{pal["frame"]}" '
           f'stroke-width="0.8" data-name="{escape(name, {chr(34): "&quot;"})}"/>',
           _text(x, y - r - 3, name, pal["text"], fs)]
    return out


# ---------------------------------------------------------------------------
def render_allsky_svg(eph: Ephemeris, time: Time, site: Site,
                      catalog: StarCatalog, dso: DSOCatalog | None,
                      opts: ChartOptions) -> str:
    """Complete all-sky SVG chart as an XML document string."""
    size = opts.size_px
    cx = cy = size / 2.0
    margin = size * 0.045
    R = size / 2.0 - margin
    scale = size / 800.0
    fs = 11.0 * scale                       # base font size
    ew = -1.0 if not opts.mirror else 1.0   # east-left unless mirrored

    def project(az_deg, alt_deg):
        az = np.deg2rad(np.asarray(az_deg, dtype=float))
        alt = np.asarray(alt_deg, dtype=float)
        r = R * (90.0 - alt) / (90.0 - opts.min_alt)
        return cx + ew * r * np.sin(az), cy - r * np.cos(az)

    sun_alt = _sun_alt(eph, time, site)
    pal = _palette(opts, dark_sky=sun_alt <= -18.0)

    title = ("全天星図 " if opts.lang == "ja" else "All-sky chart ") + \
        time.iso_utc(0) + " UTC — " + site.name(opts.lang)
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" '
        f'viewBox="0 0 {size} {size}" width="{size}" height="{size}">',
        f"<title>{escape(title)}</title>",
        f'<defs><clipPath id="sky">'
        f'<circle cx="{_f(cx)}" cy="{_f(cy)}" r="{_f(R)}"/>'
        f"</clipPath></defs>",
        f'<rect x="0" y="0" width="{size}" height="{size}" '
        f'fill="{pal["bg"]}"/>',
    ]

    # ---- grid ----
    if opts.show_grid:
        for alt in (30.0, 60.0):
            if alt <= opts.min_alt:
                continue
            r = R * (90.0 - alt) / (90.0 - opts.min_alt)
            parts.append(f'<circle cx="{_f(cx)}" cy="{_f(cy)}" r="{_f(r)}" '
                         f'fill="none" stroke="{pal["grid"]}" '
                         f'stroke-width="0.5" stroke-dasharray="3 3"/>')
        card = _CARDINAL["ja" if opts.lang == "ja" else "en"]
        o = margin * 0.5
        parts.append(_text(cx, cy - R - o + fs / 2, card["N"],
                           pal["text"], fs))
        parts.append(_text(cx, cy + R + o + fs / 2, card["S"],
                           pal["text"], fs))
        ex = cx + ew * (R + o)
        parts.append(_text(ex, cy + fs / 3, card["E"], pal["text"], fs))
        parts.append(_text(cx - ew * (R + o), cy + fs / 3, card["W"],
                           pal["text"], fs))

    parts.append('<g clip-path="url(#sky)">')

    # ---- constellation lines (vectorized over the 2x676 endpoints) ----
    if opts.show_constellation_lines:
        segs = catalog.constellation_lines()
        arr = np.array([(s[1], s[2], s[3], s[4]) for s in segs], dtype=float)
        ras = np.concatenate([arr[:, 0], arr[:, 2]])
        decs = np.concatenate([arr[:, 1], arr[:, 3]])
        p = observe_star(ras, decs, time, site=site, refraction=False)
        n = len(segs)
        a1, a2 = p.alt[:n], p.alt[n:]
        x, y = project(p.az, p.alt)
        for i in range(n):
            if a1[i] > -2.0 and a2[i] > -2.0:
                parts.append(
                    f'<line x1="{_f(x[i])}" y1="{_f(y[i])}" '
                    f'x2="{_f(x[i + n])}" y2="{_f(y[i + n])}" '
                    f'stroke="{pal["line"]}" stroke-width="0.6"/>')

    # ---- ecliptic (36 samples, geocentric lat 0) ----
    if opts.show_ecliptic:
        lon = np.arange(0.0, 360.0, 10.0)
        ra_e, dec_e = ecliptic_to_icrs(lon, np.zeros_like(lon), time)
        p = observe_star(ra_e, dec_e, time, site=site, refraction=False)
        x, y = project(p.az, p.alt)
        m = len(lon)
        for i in range(m):
            j = (i + 1) % m
            if p.alt[i] > opts.min_alt - 5 and p.alt[j] > opts.min_alt - 5:
                parts.append(
                    f'<line x1="{_f(x[i])}" y1="{_f(y[i])}" '
                    f'x2="{_f(x[j])}" y2="{_f(y[j])}" '
                    f'stroke="{pal["ecliptic"]}" stroke-width="0.7" '
                    f'stroke-dasharray="5 4"/>')

    # ---- stars (one vectorized apparent-place call) ----
    stars = catalog.apparent_stars(time, site, opts.vmag_limit,
                                   refraction=False)
    labels = []
    for s in stars:
        if s["alt"] < opts.min_alt:
            continue
        x, y = project(s["az"], s["alt"])
        r = _star_radius(s["vmag"], scale)
        attr = ""
        if s["name"]:
            attr = f' data-name="{escape(s["name"], {chr(34): "&quot;"})}"'
        parts.append(f'<circle cx="{_f(x)}" cy="{_f(y)}" r="{_f(r)}" '
                     f'fill="{_star_color(s["bv"], pal)}"{attr}/>')
        if opts.show_star_names and s["name"] and s["vmag"] <= 1.5:
            labels.append(_text(x + r + 2, y - r - 2, s["name"],
                                pal["text"], fs * 0.9, anchor="start"))
    parts.extend(labels)

    # ---- constellation names ----
    if opts.show_constellation_names:
        cons = catalog.constellations()
        ra = np.array([c["ra_deg"] for c in cons])
        dec = np.array([c["dec_deg"] for c in cons])
        p = observe_star(ra, dec, time, site=site, refraction=False)
        x, y = project(p.az, p.alt)
        for i, c in enumerate(cons):
            if p.alt[i] > max(opts.min_alt, 5.0):
                name = c["name_ja"] if opts.lang == "ja" else c["name_latin"]
                parts.append(_text(x[i], y[i], name or c["abbr"],
                                   pal["text"], fs, extra=' opacity="0.8"'))

    # ---- deep-sky objects ----
    if opts.show_dso and dso is not None:
        for o in dso.visible(time, site, min_alt_deg=max(opts.min_alt, 0.0),
                             vmag_limit=10.0):
            x, y = project(o["az"], o["alt"])
            parts.append(f'<circle cx="{_f(x)}" cy="{_f(y)}" '
                         f'r="{_f(3.0 * scale)}" fill="none" '
                         f'stroke="{pal["dso"]}" stroke-width="0.8"/>')
            parts.append(_text(x + 4, y - 4, o["id"], pal["dso"],
                               fs * 0.8, anchor="start"))

    # ---- sun, moon, planets ----
    for body in _bodies_to_draw(opts):
        bv = observe_planet(eph, body, time, site, refraction=False)
        alt = float(np.atleast_1d(bv.alt)[0])
        az = float(np.atleast_1d(bv.az)[0])
        if alt >= opts.min_alt:
            x, y = project(az, alt)
            parts.extend(_body_marker(bv, x, y, pal, opts, fs))

    parts.append("</g>")
    parts.append(f'<circle cx="{_f(cx)}" cy="{_f(cy)}" r="{_f(R)}" '
                 f'fill="none" stroke="{pal["frame"]}" stroke-width="1.2"/>')
    parts.append("</svg>")
    return "".join(parts)


# ---------------------------------------------------------------------------
def render_horizon_svg(eph: Ephemeris, time: Time, site: Site,
                       catalog: StarCatalog, dso: DSOCatalog | None,
                       opts: ChartOptions, az_center_deg: float,
                       alt_max: float = 70.0, fov_az: float = 120.0) -> str:
    """Partial-sky rectangular az/alt view of an azimuth window.

    Natural view (as seen facing az_center); ``mirror=True`` flips
    left/right.  Same element toggles as the all-sky chart.
    """
    W = opts.size_px
    margin = W * 0.05
    sc = (W - 2 * margin) / fov_az          # px per degree
    alt0 = min(opts.min_alt, 0.0)
    H = 2 * margin + (alt_max - alt0) * sc
    cx = W / 2.0
    scale = W / 800.0
    fs = 11.0 * scale
    ew = 1.0 if not opts.mirror else -1.0

    def wrap(az):
        return (np.asarray(az, dtype=float) - az_center_deg + 180.0) \
            % 360.0 - 180.0

    def project(az_deg, alt_deg):
        d = wrap(az_deg)
        x = cx + ew * d * sc
        y = margin + (alt_max - np.asarray(alt_deg, dtype=float)) * sc
        return x, y, np.abs(d) <= fov_az / 2.0

    sun_alt = _sun_alt(eph, time, site)
    pal = _palette(opts, dark_sky=sun_alt <= -18.0)

    title = ("星空(方位図) " if opts.lang == "ja" else "Horizon view ") + \
        time.iso_utc(0) + " UTC — " + site.name(opts.lang)
    x0, y0 = margin, margin
    win_w, win_h = W - 2 * margin, (alt_max - alt0) * sc
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" '
        f'viewBox="0 0 {W} {H:.0f}" width="{W}" height="{H:.0f}">',
        f"<title>{escape(title)}</title>",
        f'<defs><clipPath id="win"><rect x="{_f(x0)}" y="{_f(y0)}" '
        f'width="{_f(win_w)}" height="{_f(win_h)}"/></clipPath></defs>',
        f'<rect x="0" y="0" width="{W}" height="{H:.0f}" '
        f'fill="{pal["bg"]}"/>',
    ]

    # ---- grid: alt lines + az ticks with compass labels ----
    if opts.show_grid:
        for alt in (0.0, 30.0, 60.0):
            if not alt0 <= alt <= alt_max:
                continue
            y = margin + (alt_max - alt) * sc
            parts.append(f'<line x1="{_f(x0)}" y1="{_f(y)}" '
                         f'x2="{_f(x0 + win_w)}" y2="{_f(y)}" '
                         f'stroke="{pal["grid"]}" stroke-width="0.5" '
                         f'stroke-dasharray="3 3"/>')
        winds = _WINDS8_JA if opts.lang == "ja" else _WINDS8
        for k in range(8):
            azk = k * 45.0
            x, _, inside = project(azk, 0.0)
            if inside:
                parts.append(_text(float(x), margin + win_h + fs + 2,
                                   winds[k], pal["text"], fs))

    parts.append('<g clip-path="url(#win)">')

    # ---- constellation lines ----
    if opts.show_constellation_lines:
        segs = catalog.constellation_lines()
        arr = np.array([(s[1], s[2], s[3], s[4]) for s in segs], dtype=float)
        ras = np.concatenate([arr[:, 0], arr[:, 2]])
        decs = np.concatenate([arr[:, 1], arr[:, 3]])
        p = observe_star(ras, decs, time, site=site, refraction=False)
        x, y, ins = project(p.az, p.alt)
        n = len(segs)
        for i in range(n):
            j = i + n
            if (p.alt[i] > -2 and p.alt[j] > -2 and (ins[i] or ins[j])
                    and abs(wrap(p.az[i]) - wrap(p.az[j])) < 180.0):
                parts.append(
                    f'<line x1="{_f(x[i])}" y1="{_f(y[i])}" '
                    f'x2="{_f(x[j])}" y2="{_f(y[j])}" '
                    f'stroke="{pal["line"]}" stroke-width="0.6"/>')

    # ---- ecliptic ----
    if opts.show_ecliptic:
        lon = np.arange(0.0, 360.0, 10.0)
        ra_e, dec_e = ecliptic_to_icrs(lon, np.zeros_like(lon), time)
        p = observe_star(ra_e, dec_e, time, site=site, refraction=False)
        x, y, ins = project(p.az, p.alt)
        m = len(lon)
        for i in range(m):
            j = (i + 1) % m
            if ((ins[i] or ins[j])
                    and p.alt[i] > alt0 - 10 and p.alt[j] > alt0 - 10
                    and abs(wrap(p.az[i]) - wrap(p.az[j])) < 180.0):
                parts.append(
                    f'<line x1="{_f(x[i])}" y1="{_f(y[i])}" '
                    f'x2="{_f(x[j])}" y2="{_f(y[j])}" '
                    f'stroke="{pal["ecliptic"]}" stroke-width="0.7" '
                    f'stroke-dasharray="5 4"/>')

    # ---- stars ----
    stars = catalog.apparent_stars(time, site, opts.vmag_limit,
                                   refraction=False)
    labels = []
    for s in stars:
        if not alt0 <= s["alt"] <= alt_max + 2:
            continue
        d = float(wrap(s["az"]))
        if abs(d) > fov_az / 2.0 + 2:
            continue
        x = cx + ew * d * sc
        y = margin + (alt_max - s["alt"]) * sc
        r = _star_radius(s["vmag"], scale)
        attr = ""
        if s["name"]:
            attr = f' data-name="{escape(s["name"], {chr(34): "&quot;"})}"'
        parts.append(f'<circle cx="{_f(x)}" cy="{_f(y)}" r="{_f(r)}" '
                     f'fill="{_star_color(s["bv"], pal)}"{attr}/>')
        if opts.show_star_names and s["name"] and s["vmag"] <= 1.5:
            labels.append(_text(x + r + 2, y - r - 2, s["name"],
                                pal["text"], fs * 0.9, anchor="start"))
    parts.extend(labels)

    # ---- constellation names ----
    if opts.show_constellation_names:
        cons = catalog.constellations()
        ra = np.array([c["ra_deg"] for c in cons])
        dec = np.array([c["dec_deg"] for c in cons])
        p = observe_star(ra, dec, time, site=site, refraction=False)
        x, y, ins = project(p.az, p.alt)
        for i, c in enumerate(cons):
            if ins[i] and alt0 <= p.alt[i] <= alt_max:
                name = c["name_ja"] if opts.lang == "ja" else c["name_latin"]
                parts.append(_text(float(x[i]), float(y[i]),
                                   name or c["abbr"], pal["text"], fs,
                                   extra=' opacity="0.8"'))

    # ---- deep-sky objects ----
    if opts.show_dso and dso is not None:
        for o in dso.visible(time, site, min_alt_deg=max(alt0, 0.0),
                             vmag_limit=10.0):
            x, y, ins = project(o["az"], o["alt"])
            if ins and o["alt"] <= alt_max:
                parts.append(f'<circle cx="{_f(x)}" cy="{_f(y)}" '
                             f'r="{_f(3.0 * scale)}" fill="none" '
                             f'stroke="{pal["dso"]}" stroke-width="0.8"/>')
                parts.append(_text(float(x) + 4, float(y) - 4, o["id"],
                                   pal["dso"], fs * 0.8, anchor="start"))

    # ---- sun, moon, planets ----
    for body in _bodies_to_draw(opts):
        bv = observe_planet(eph, body, time, site, refraction=False)
        alt = float(np.atleast_1d(bv.alt)[0])
        az = float(np.atleast_1d(bv.az)[0])
        x, y, ins = project(az, alt)
        if ins and alt0 <= alt <= alt_max:
            parts.extend(_body_marker(bv, float(x), float(y), pal, opts, fs))

    parts.append("</g>")
    parts.append(f'<rect x="{_f(x0)}" y="{_f(y0)}" width="{_f(win_w)}" '
                 f'height="{_f(win_h)}" fill="none" '
                 f'stroke="{pal["frame"]}" stroke-width="1.2"/>')
    parts.append("</svg>")
    return "".join(parts)
