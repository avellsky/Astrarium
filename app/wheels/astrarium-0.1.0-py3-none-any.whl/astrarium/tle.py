"""Earth satellites from two-line elements (ISS・人工衛星, spec §2 ext.).

Contents
--------
* :func:`parse_tle` — NORAD/Celestrak two-line (and three-line) element
  sets into :class:`TLE` records.
* :class:`Satellite` — a TLE plus its SGP4 propagator.  The SGP4
  implementation follows Hoots & Roehrich, *Spacetrack Report #3* with
  the corrections of Vallado et al., *Revisiting Spacetrack Report #3*
  (AIAA 2006-6753), in the WGS-72 constants the model is defined in.  It
  is vectorised over time: one call propagates a whole array of epochs.
* :func:`observe_satellites` — topocentric azimuth/altitude, slant
  range, illumination state and an estimated visual magnitude.
* :func:`next_passes` — visible-pass search for one satellite.
* :class:`TLERegistry` — download (Celestrak) and offline cache of
  element sets under ``data/tle/``.

Scope and accuracy
------------------
Only the **near-Earth** half of the model is implemented (orbital period
< 225 min): that covers the ISS, the CSS, Hubble, Starlink and every
other low-orbit target a visual observer cares about.  Deep-space
objects (SDP4 — geostationary, Molniya, GNSS) are parsed and flagged
``deep_space`` but not propagated; the registry skips them.

Positions are good to ~1 km near the element epoch, degrading by roughly
1-3 km/day of element age — i.e. seconds of timing error for a pass.
Elements more than a few days old should be refreshed.  Frames: SGP4
produces TEME, which is rotated to the Earth-fixed pseudo-Earth-fixed
frame by GMST(IAU 1982) — the rotation SGP4/TEME is defined against —
and polar motion (< 0.5 ″) is neglected.

The visual magnitude is an *estimate* from a standard-magnitude and
diffuse-sphere phase law; treat it as ±1 mag.
"""
from __future__ import annotations

import json
import math
import os
import subprocess
import time as _time
from dataclasses import dataclass, field

import erfa
import numpy as np

from .constants import AU_KM
from .observer import Site
from .paths import data_path
from .timescale import Time

_DATA = data_path("tle")

# --- WGS-72: the geopotential SGP4 is *defined* in (not WGS-84) --------
XKMPER = 6378.135                       # equatorial radius [km]
MU = 398600.8                           # [km^3/s^2]
XKE = 60.0 / math.sqrt(XKMPER ** 3 / MU)
J2 = 0.001082616
J3 = -0.00000253881
J4 = -0.00000165597
J3OJ2 = J3 / J2
X2O3 = 2.0 / 3.0
VKMPERSEC = XKMPER * XKE / 60.0         # canonical speed -> km/s
TWOPI = 2.0 * math.pi
DEG = math.pi / 180.0
R_SUN_KM = 695700.0

# Standard magnitudes (visual mag at 1000 km range, 90° phase angle) of
# the naked-eye regulars.  Everything else falls back to STD_MAG_DEFAULT,
# which is a rough average for the "visual" Celestrak group.
STD_MAG = {
    25544: -1.8,      # ISS (ZARYA)
    48274: -0.8,      # CSS (TIANHE)
    20580: 1.5,       # Hubble Space Telescope
    39084: 2.0,       # Landsat 8
    27386: 2.5,       # Envisat
}
STD_MAG_DEFAULT = 4.0


# ---------------------------------------------------------------------------
# element parsing
# ---------------------------------------------------------------------------
def _tle_float(s: str) -> float:
    """TLE 'assumed decimal point + exponent' field, e.g. ' 12345-3'."""
    s = s.strip()
    if not s:
        return 0.0
    sign = -1.0 if s[0] == "-" else 1.0
    s = s.lstrip("+-")
    if "-" in s or "+" in s:
        for i, ch in enumerate(s):
            if ch in "+-" and i > 0:
                return sign * float("0." + s[:i]) * 10.0 ** int(s[i:])
    return sign * float("0." + s)


def _checksum_ok(line: str) -> bool:
    total = 0
    for ch in line[:68]:
        if ch.isdigit():
            total += int(ch)
        elif ch == "-":
            total += 1
    try:
        return total % 10 == int(line[68])
    except (IndexError, ValueError):
        return False


@dataclass
class TLE:
    """One NORAD element set (angles in radians, mean motion rad/min)."""
    name: str
    satnum: int
    intl_desig: str
    epoch_jd_utc: float
    ndot: float                 # d(n)/dt / 2   [rev/day^2] as given
    nddot: float                # d2(n)/dt2 / 6 [rev/day^3] as given
    bstar: float
    inclo: float
    nodeo: float
    ecco: float
    argpo: float
    mo: float
    no_kozai: float             # [rad/min]
    revnum: int = 0
    line1: str = ""
    line2: str = ""

    @property
    def period_min(self) -> float:
        return TWOPI / self.no_kozai

    @property
    def deep_space(self) -> bool:
        return self.period_min >= 225.0

    @classmethod
    def from_lines(cls, line1: str, line2: str, name: str = "") -> "TLE":
        if not (line1.startswith("1 ") and line2.startswith("2 ")):
            raise ValueError("not a two-line element set")
        yy = int(line1[18:20])
        year = 2000 + yy if yy < 57 else 1900 + yy
        doy = float(line1[20:32])
        d0, d1 = erfa.cal2jd(year, 1, 1)
        epoch = (d0 + d1) + doy - 1.0          # day-of-year 1.0 = Jan 1 0h
        return cls(
            name=(name or f"NORAD {int(line1[2:7])}").strip(),
            satnum=int(line1[2:7]),
            intl_desig=line1[9:17].strip(),
            epoch_jd_utc=epoch,
            ndot=float(line1[33:43]),
            nddot=_tle_float(line1[44:52]),
            bstar=_tle_float(line1[53:61]),
            inclo=float(line2[8:16]) * DEG,
            nodeo=float(line2[17:25]) * DEG,
            ecco=float("0." + line2[26:33].strip()),
            argpo=float(line2[34:42]) * DEG,
            mo=float(line2[43:51]) * DEG,
            no_kozai=float(line2[52:63]) * TWOPI / 1440.0,
            revnum=int(line2[63:68] or 0),
            line1=line1.rstrip(), line2=line2.rstrip())


def parse_tle(text: str, verify_checksum: bool = False) -> list[TLE]:
    """Parse a 2-line or 3-line (name + elements) TLE stream."""
    out, pending_name = [], ""
    lines = [ln.rstrip() for ln in text.splitlines()]
    i = 0
    while i < len(lines):
        ln = lines[i]
        if ln.startswith("1 ") and i + 1 < len(lines) and \
                lines[i + 1].startswith("2 "):
            l1, l2 = ln, lines[i + 1]
            if not verify_checksum or (_checksum_ok(l1) and
                                       _checksum_ok(l2)):
                try:
                    out.append(TLE.from_lines(l1, l2, pending_name))
                except (ValueError, IndexError):
                    pass
            pending_name = ""
            i += 2
            continue
        pending_name = ln.strip().lstrip("0 ") if ln.strip() else ""
        i += 1
    return out


# ---------------------------------------------------------------------------
# SGP4 (near-Earth)
# ---------------------------------------------------------------------------
class Sgp4Error(ValueError):
    """The propagator left its domain (decayed / deep-space / e >= 1)."""


class Satellite:
    """A TLE with its initialised SGP4 propagator.

    ``propagate(tsince_min)`` accepts a scalar or an array of minutes
    since the element epoch and returns ``(r_teme, v_teme)`` in km and
    km/s with shape ``(..., 3)``.
    """

    def __init__(self, tle: TLE):
        self.tle = tle
        self.name = tle.name
        self.satnum = tle.satnum
        if tle.deep_space:
            raise Sgp4Error(
                f"{tle.name}: period {tle.period_min:.0f} min needs SDP4 "
                "(deep-space terms are not implemented)")
        self._init()

    # -- initialisation (sgp4init / initl) ------------------------------
    def _init(self):
        t = self.tle
        ecco, inclo, argpo, mo = t.ecco, t.inclo, t.argpo, t.mo
        self.bstar = t.bstar

        cosio = math.cos(inclo)
        sinio = math.sin(inclo)
        cosio2 = cosio * cosio
        omeosq = 1.0 - ecco * ecco
        if omeosq <= 0.0:
            raise Sgp4Error(f"{t.name}: eccentricity >= 1")
        rteosq = math.sqrt(omeosq)

        # Kozai -> Brouwer mean motion
        ak = (XKE / t.no_kozai) ** X2O3
        d1 = 0.75 * J2 * (3.0 * cosio2 - 1.0) / (rteosq * omeosq)
        dl = d1 / (ak * ak)
        adel = ak * (1.0 - dl * dl / 3.0 -
                     dl * (1.0 / 3.0 + 134.0 * dl * dl / 81.0))
        dl = d1 / (adel * adel)
        no = t.no_kozai / (1.0 + dl)
        ao = (XKE / no) ** X2O3
        self.no = no

        po = ao * omeosq
        con42 = 1.0 - 5.0 * cosio2
        con41 = -con42 - cosio2 - cosio2          # = 3 cos^2 i - 1
        posq = po * po
        rp = ao * (1.0 - ecco)
        if rp < 1.0:
            raise Sgp4Error(f"{t.name}: perigee inside the Earth (decayed)")

        # drag / atmospheric terms
        self.isimp = rp < (220.0 / XKMPER + 1.0)
        sfour = 78.0 / XKMPER + 1.0
        qzms24 = ((120.0 - 78.0) / XKMPER) ** 4
        perige = (rp - 1.0) * XKMPER
        if perige < 156.0:
            sfour = perige - 78.0
            if perige < 98.0:
                sfour = 20.0
            qzms24 = ((120.0 - sfour) / XKMPER) ** 4
            sfour = sfour / XKMPER + 1.0

        pinvsq = 1.0 / posq
        tsi = 1.0 / (ao - sfour)
        eta = ao * ecco * tsi
        etasq = eta * eta
        eeta = ecco * eta
        psisq = abs(1.0 - etasq)
        coef = qzms24 * tsi ** 4
        coef1 = coef / psisq ** 3.5

        cc2 = coef1 * no * (
            ao * (1.0 + 1.5 * etasq + eeta * (4.0 + etasq)) +
            0.375 * J2 * tsi / psisq * con41 *
            (8.0 + 3.0 * etasq * (8.0 + etasq)))
        self.cc1 = self.bstar * cc2
        cc3 = 0.0
        if ecco > 1.0e-4:
            cc3 = -2.0 * coef * tsi * J3OJ2 * no * sinio / ecco
        self.x1mth2 = 1.0 - cosio2
        self.cc4 = 2.0 * no * coef1 * ao * omeosq * (
            eta * (2.0 + 0.5 * etasq) + ecco * (0.5 + 2.0 * etasq) -
            J2 * tsi / (ao * psisq) *
            (-3.0 * con41 * (1.0 - 2.0 * eeta +
                             etasq * (1.5 - 0.5 * eeta)) +
             0.75 * self.x1mth2 * (2.0 * etasq - eeta * (1.0 + etasq)) *
             math.cos(2.0 * argpo)))
        self.cc5 = 2.0 * coef1 * ao * omeosq * (
            1.0 + 2.75 * (etasq + eeta) + eeta * etasq)

        cosio4 = cosio2 * cosio2
        temp1 = 1.5 * J2 * pinvsq * no
        temp2 = 0.5 * temp1 * J2 * pinvsq
        temp3 = -0.46875 * J4 * pinvsq * pinvsq * no
        self.mdot = (no + 0.5 * temp1 * rteosq * con41 +
                     0.0625 * temp2 * rteosq *
                     (13.0 - 78.0 * cosio2 + 137.0 * cosio4))
        self.argpdot = (-0.5 * temp1 * con42 +
                        0.0625 * temp2 *
                        (7.0 - 114.0 * cosio2 + 395.0 * cosio4) +
                        temp3 * (3.0 - 36.0 * cosio2 + 49.0 * cosio4))
        xhdot1 = -temp1 * cosio
        self.nodedot = xhdot1 + (
            0.5 * temp2 * (4.0 - 19.0 * cosio2) +
            2.0 * temp3 * (3.0 - 7.0 * cosio2)) * cosio

        self.omgcof = self.bstar * cc3 * math.cos(argpo)
        self.xmcof = 0.0
        if ecco > 1.0e-4:
            self.xmcof = -X2O3 * coef * self.bstar / eeta
        self.nodecf = 3.5 * omeosq * xhdot1 * self.cc1
        self.t2cof = 1.5 * self.cc1
        if abs(cosio + 1.0) > 1.5e-12:
            self.xlcof = (-0.25 * J3OJ2 * sinio *
                          (3.0 + 5.0 * cosio) / (1.0 + cosio))
        else:
            self.xlcof = (-0.25 * J3OJ2 * sinio *
                          (3.0 + 5.0 * cosio) / 1.5e-12)
        self.aycof = -0.5 * J3OJ2 * sinio
        self.delmo = (1.0 + eta * math.cos(mo)) ** 3
        self.sinmao = math.sin(mo)
        self.x7thm1 = 7.0 * cosio2 - 1.0
        self.eta = eta
        self.con41 = con41
        self.cosio = cosio
        self.sinio = sinio

        self.d2 = self.d3 = self.d4 = 0.0
        self.t3cof = self.t4cof = self.t5cof = 0.0
        if not self.isimp:
            cc1sq = self.cc1 * self.cc1
            self.d2 = 4.0 * ao * tsi * cc1sq
            temp = self.d2 * tsi * self.cc1 / 3.0
            self.d3 = (17.0 * ao + sfour) * temp
            self.d4 = 0.5 * temp * ao * tsi * \
                (221.0 * ao + 31.0 * sfour) * self.cc1
            self.t3cof = self.d2 + 2.0 * cc1sq
            self.t4cof = 0.25 * (3.0 * self.d3 +
                                 self.cc1 * (12.0 * self.d2 + 10.0 * cc1sq))
            self.t5cof = 0.2 * (
                3.0 * self.d4 + 12.0 * self.cc1 * self.d3 +
                6.0 * self.d2 * self.d2 +
                15.0 * cc1sq * (2.0 * self.d2 + cc1sq))

    # -- propagation (sgp4) ---------------------------------------------
    def propagate(self, tsince_min):
        """TEME position [km] and velocity [km/s], shape (..., 3)."""
        t = np.atleast_1d(np.asarray(tsince_min, dtype=float))
        e = self.tle
        xmdf = e.mo + self.mdot * t
        argpdf = e.argpo + self.argpdot * t
        nodedf = e.nodeo + self.nodedot * t
        argpm, mm = argpdf, xmdf
        t2 = t * t
        nodem = nodedf + self.nodecf * t2
        tempa = 1.0 - self.cc1 * t
        tempe = self.bstar * self.cc4 * t
        templ = self.t2cof * t2

        if not self.isimp:
            delomg = self.omgcof * t
            delm = self.xmcof * ((1.0 + self.eta * np.cos(xmdf)) ** 3 -
                                 self.delmo)
            temp = delomg + delm
            mm = xmdf + temp
            argpm = argpdf - temp
            t3 = t2 * t
            t4 = t3 * t
            tempa = tempa - self.d2 * t2 - self.d3 * t3 - self.d4 * t4
            tempe = tempe + self.bstar * self.cc5 * (np.sin(mm) -
                                                     self.sinmao)
            templ = templ + self.t3cof * t3 + \
                t4 * (self.t4cof + t * self.t5cof)

        am = (XKE / self.no) ** X2O3 * tempa * tempa
        with np.errstate(invalid="ignore"):
            nm = XKE / am ** 1.5
        em = e.ecco - tempe
        bad = ~np.isfinite(am) | (am <= 0.0) | (em >= 1.0) | (em < -0.001)
        em = np.where(em < 1.0e-6, 1.0e-6, em)

        mm = mm + self.no * templ
        xlm = mm + argpm + nodem
        nodem = np.mod(nodem, TWOPI)
        argpm = np.mod(argpm, TWOPI)
        mm = np.mod(np.mod(xlm, TWOPI) - argpm - nodem, TWOPI)

        # --- long-period periodics
        axnl = em * np.cos(argpm)
        temp = 1.0 / (am * (1.0 - em * em))
        aynl = em * np.sin(argpm) + temp * self.aycof
        xl = mm + argpm + nodem + temp * self.xlcof * axnl

        # --- Kepler's equation for (E + omega)
        u = np.mod(xl - nodem, TWOPI)
        eo1 = u.copy()
        for _ in range(12):
            sineo1, coseo1 = np.sin(eo1), np.cos(eo1)
            denom = 1.0 - coseo1 * axnl - sineo1 * aynl
            denom = np.where(np.abs(denom) < 1e-12, 1e-12, denom)
            d = (u - aynl * coseo1 + axnl * sineo1 - eo1) / denom
            d = np.clip(d, -0.95, 0.95)
            eo1 = eo1 + d
            if np.all(np.abs(d) < 1.0e-12):
                break
        sineo1, coseo1 = np.sin(eo1), np.cos(eo1)

        # --- short-period periodics
        ecose = axnl * coseo1 + aynl * sineo1
        esine = axnl * sineo1 - aynl * coseo1
        el2 = axnl * axnl + aynl * aynl
        pl = am * (1.0 - el2)
        bad = bad | (pl < 0.0)
        pl = np.where(pl <= 0.0, np.nan, pl)
        rl = am * (1.0 - ecose)
        rdotl = np.sqrt(am) * esine / rl
        rvdotl = np.sqrt(pl) / rl
        betal = np.sqrt(1.0 - el2)
        temp = esine / (1.0 + betal)
        sinu = am / rl * (sineo1 - aynl - axnl * temp)
        cosu = am / rl * (coseo1 - axnl + aynl * temp)
        su = np.arctan2(sinu, cosu)
        sin2u = 2.0 * cosu * sinu
        cos2u = 1.0 - 2.0 * sinu * sinu
        temp = 1.0 / pl
        temp1 = 0.5 * J2 * temp
        temp2 = temp1 * temp

        mrt = rl * (1.0 - 1.5 * temp2 * betal * self.con41) + \
            0.5 * temp1 * self.x1mth2 * cos2u
        su = su - 0.25 * temp2 * self.x7thm1 * sin2u
        xnode = nodem + 1.5 * temp2 * self.cosio * sin2u
        xinc = e.inclo + 1.5 * temp2 * self.cosio * self.sinio * cos2u
        mvt = rdotl - nm * temp1 * self.x1mth2 * sin2u / XKE
        rvdot = rvdotl + nm * temp1 * \
            (self.x1mth2 * cos2u + 1.5 * self.con41) / XKE
        bad = bad | (mrt < 1.0)

        # --- orientation vectors
        sinsu, cossu = np.sin(su), np.cos(su)
        snod, cnod = np.sin(xnode), np.cos(xnode)
        sini, cosi = np.sin(xinc), np.cos(xinc)
        xmx = -snod * cosi
        xmy = cnod * cosi
        ux = xmx * sinsu + cnod * cossu
        uy = xmy * sinsu + snod * cossu
        uz = sini * sinsu
        vx = xmx * cossu - cnod * sinsu
        vy = xmy * cossu - snod * sinsu
        vz = sini * cossu

        uvec = np.stack([ux, uy, uz], axis=-1)
        vvec = np.stack([vx, vy, vz], axis=-1)
        r = mrt[..., None] * uvec * XKMPER
        v = (mvt[..., None] * uvec + rvdot[..., None] * vvec) * VKMPERSEC
        if np.any(bad):
            r = np.where(bad[..., None], np.nan, r)
            v = np.where(bad[..., None], np.nan, v)
        return r, v

    def teme_at(self, t: Time):
        """TEME state at Time ``t`` (scalar or array)."""
        tsince = (np.atleast_1d(t.jd_utc) - self.tle.epoch_jd_utc) * 1440.0
        return self.propagate(tsince)

    def element_age_days(self, t: Time) -> float:
        return float(np.mean(np.atleast_1d(t.jd_utc)) -
                     self.tle.epoch_jd_utc)


# ---------------------------------------------------------------------------
# frames & observation
# ---------------------------------------------------------------------------
def _rot3(v, theta):
    """Rotate coordinates about +z by ``theta`` (frame rotation)."""
    c, s = np.cos(theta), np.sin(theta)
    x = c * v[..., 0] + s * v[..., 1]
    y = -s * v[..., 0] + c * v[..., 1]
    return np.stack([x, y, v[..., 2]], axis=-1)


def teme_to_pef(r_teme, t: Time):
    """TEME -> pseudo-Earth-fixed via GMST (IAU 1982), the rotation the
    TEME frame is defined against.  Polar motion (< 0.5 ″) is ignored."""
    gmst = np.atleast_1d(erfa.gmst82(*t.ut1))
    return _rot3(r_teme, gmst if r_teme.ndim > 1 else gmst[0])


def sun_pef_km(eph, t: Time):
    """Geocentric Sun position [km] in the same Earth-fixed frame."""
    p_sun, _ = eph.pv_bary("sun", *t.tdb)
    p_earth, _ = eph.pv_bary("earth", *t.tdb)
    v_icrs = (np.asarray(p_sun) - np.asarray(p_earth)) * AU_KM
    rbpn = np.asarray(erfa.pnm06a(*t.tt))            # ICRS -> true of date
    v_tod = np.einsum("...ij,...j->...i", rbpn, v_icrs)
    gast = np.atleast_1d(erfa.gst06a(*t.ut1, *t.tt))
    return _rot3(v_tod, gast if v_tod.ndim > 1 else gast[0])


def _enu(d, site: Site):
    """Earth-fixed vector -> (az, alt) [deg] and range [km] at a site."""
    sl, cl = math.sin(site.lat_rad), math.cos(site.lat_rad)
    so, co = math.sin(site.lon_rad), math.cos(site.lon_rad)
    x, y, z = d[..., 0], d[..., 1], d[..., 2]
    east = -so * x + co * y
    north = -sl * co * x - sl * so * y + cl * z
    up = cl * co * x + cl * so * y + sl * z
    rng = np.sqrt(x * x + y * y + z * z)
    alt = np.degrees(np.arctan2(up, np.hypot(east, north)))
    az = np.degrees(np.arctan2(east, north)) % 360.0
    return az, alt, rng


def is_sunlit(r_pef, sun_pef):
    """True where the satellite is outside the Earth's umbral cone.

    Exact geometric cone: at a distance ``d`` down the anti-sunward axis
    the umbra has radius ``R_e - d·(R_sun - R_e)/|r_sun|``.
    """
    dsun = np.linalg.norm(sun_pef, axis=-1)
    shat = sun_pef / dsun[..., None]
    along = -np.sum(r_pef * shat, axis=-1)           # anti-sunward depth
    rnorm2 = np.sum(r_pef * r_pef, axis=-1)
    perp = np.sqrt(np.maximum(rnorm2 - along * along, 0.0))
    r_umbra = XKMPER - along * (R_SUN_KM - XKMPER) / dsun
    return ~((along > 0.0) & (perp < r_umbra))


def estimate_magnitude(satnum, r_pef, obs_pef, sun_pef, rng_km):
    """Diffuse-sphere phase law about a standard magnitude (±1 mag)."""
    to_sun = sun_pef - r_pef
    to_obs = obs_pef - r_pef
    cs = np.sum(to_sun * to_obs, axis=-1) / (
        np.linalg.norm(to_sun, axis=-1) * np.linalg.norm(to_obs, axis=-1))
    phase = np.arccos(np.clip(cs, -1.0, 1.0))
    f = ((math.pi - phase) * np.cos(phase) + np.sin(phase)) / math.pi
    f = np.maximum(f, 1.0e-4)
    m0 = STD_MAG.get(int(satnum), STD_MAG_DEFAULT)
    return m0 - 15.75 + 2.5 * np.log10(rng_km * rng_km / f)


def observe_satellites(eph, sats, t: Time, site: Site,
                       min_alt_deg=0.0, sunlit_only=False):
    """Topocentric state of every satellite in ``sats`` at one instant.

    Returns a list of dicts sorted by decreasing altitude; only entries
    above ``min_alt_deg`` (and, with ``sunlit_only``, illuminated) are
    included.
    """
    obs = np.asarray(site.geocentric_xyz_km(), dtype=float)
    sun = np.atleast_2d(sun_pef_km(eph, t))[0]
    out = []
    for s in sats:
        try:
            r_teme, v_teme = s.teme_at(t)
        except Sgp4Error:
            continue
        r = teme_to_pef(r_teme, t)[0]
        if not np.all(np.isfinite(r)):
            continue
        az, alt, rng = _enu(r - obs, site)
        az, alt, rng = float(az), float(alt), float(rng)
        if alt < min_alt_deg:
            continue
        lit = bool(is_sunlit(r, sun))
        if sunlit_only and not lit:
            continue
        mag = float(estimate_magnitude(s.satnum, r, obs, sun, rng))
        out.append({
            "name": s.name, "norad": s.satnum, "az": az, "alt": alt,
            "range_km": rng, "sunlit": lit,
            "mag": None if not lit else round(mag, 1),
            "height_km": float(np.linalg.norm(r)) - XKMPER,
            "elements_age_days": round(s.element_age_days(t), 2),
        })
    out.sort(key=lambda r: -r["alt"])
    return out


def track_all(eph, sats, t0: Time, step_s: float, n: int, site: Site,
              min_alt_deg=0.0, sunlit_only=False, max_mag=None,
              limit=120):
    """Alt/az tracks of many satellites over one time window.

    The Sun is evaluated once for the whole window (not per satellite),
    so the cost is one vectorised SGP4 call per object.  Satellites that
    stay below ``min_alt_deg`` for the entire window are dropped, which
    is what makes the payload small enough to stream to the browser.
    """
    dt = np.arange(n, dtype=float) * (step_s / 86400.0)
    t = Time(t0.tt1, t0.tt2 + dt)
    sun = sun_pef_km(eph, t)
    obs = np.asarray(site.geocentric_xyz_km(), dtype=float)
    obs_hat = obs / np.linalg.norm(obs)
    gmst = np.atleast_1d(erfa.gmst82(*t.ut1))

    # Cheap horizon cull, one SGP4 sample at the centre of the window.
    # A satellite at geocentric radius R is above the horizon only inside
    # a cap of acos(Re/R) around its sub-satellite point, which drifts by
    # 360°/period.  Whole constellations (Starlink: >10 000 objects) are
    # rejected this way at 1/n of the cost of the full track.
    half_s = 0.5 * step_s * (n - 1)
    t_mid = Time(t0.tt1, t0.tt2 + half_s / 86400.0)
    gmst_mid = np.atleast_1d(erfa.gmst82(*t_mid.ut1))
    # UTC of the samples, resolved ONCE: Time.jd_utc runs two ERFA calls,
    # which would otherwise dominate the loop over a large constellation
    jd_utc = np.atleast_1d(t.jd_utc)
    jd_utc_mid = np.atleast_1d(t_mid.jd_utc)

    def in_reach(s):
        try:
            rt = s.propagate((jd_utc_mid - s.tle.epoch_jd_utc) * 1440.0)[0]
        except Sgp4Error:
            return False
        r = _rot3(rt, gmst_mid)[0]
        rn = float(np.linalg.norm(r))
        if not np.isfinite(rn) or rn <= XKMPER:
            return False
        cap = math.degrees(math.acos(min(1.0, XKMPER / rn)))
        drift = 360.0 / s.tle.period_min * (half_s / 60.0)
        cosang = float(np.dot(r / rn, obs_hat))
        ang = math.degrees(math.acos(max(-1.0, min(1.0, cosang))))
        return ang <= cap + drift + 2.0

    out = []
    for s in sats:
        if not in_reach(s):
            continue
        try:
            r_teme, _ = s.propagate((jd_utc - s.tle.epoch_jd_utc) * 1440.0)
        except Sgp4Error:
            continue
        r = _rot3(r_teme, gmst)
        if not np.all(np.isfinite(r)):
            continue
        az, alt, rng = _enu(r - obs, site)
        if float(np.nanmax(alt)) < min_alt_deg:
            continue
        lit = is_sunlit(r, sun)
        if sunlit_only and not bool(lit.any()):
            continue
        mag = estimate_magnitude(s.satnum, r, obs, sun, rng)
        vis = alt >= min_alt_deg
        if max_mag is not None and \
                float(np.nanmin(np.where(vis & lit, mag, np.inf))) > max_mag:
            continue
        k = int(np.argmax(np.where(vis, alt, -90.0)))     # best sample
        out.append({
            "name": s.name, "norad": s.satnum,
            "az": [round(float(a), 2) for a in az],
            "alt": [round(float(a), 2) for a in alt],
            "lit": [bool(x) for x in np.atleast_1d(lit)],
            "mag": [None if not bool(l) or not np.isfinite(m)
                    else round(float(m), 1)
                    for m, l in zip(np.atleast_1d(mag), np.atleast_1d(lit))],
            "range_km": round(float(rng[k])),
            "height_km": round(float(np.linalg.norm(r[k])) - XKMPER),
            "elements_age_days": round(s.element_age_days(t0), 2),
        })
    out.sort(key=lambda r: -max(r["alt"]))
    return out[:limit]


def satellite_track(eph, sat: Satellite, t0: Time, step_s: float, n: int,
                    site: Site):
    """``n`` samples of (az, alt, sunlit) from ``t0`` at ``step_s``.

    One vectorised SGP4 call per satellite — this is what the web API
    streams so the browser can interpolate between server solutions
    instead of polling every frame.
    """
    dt = np.arange(n, dtype=float) * (step_s / 86400.0)
    t = Time(t0.tt1, t0.tt2 + dt)
    r_teme, _ = sat.teme_at(t)
    r = teme_to_pef(r_teme, t)
    obs = np.asarray(site.geocentric_xyz_km(), dtype=float)
    az, alt, rng = _enu(r - obs, site)
    sun = sun_pef_km(eph, t)
    lit = is_sunlit(r, sun)
    mag = estimate_magnitude(sat.satnum, r, obs, sun, rng)
    return az, alt, rng, lit, mag


# ---------------------------------------------------------------------------
# pass prediction
# ---------------------------------------------------------------------------
def _sun_alt(eph, t: Time, site: Site):
    sun = sun_pef_km(eph, t)
    obs = np.asarray(site.geocentric_xyz_km(), dtype=float)
    return _enu(sun - obs, site)[1]


def next_passes(eph, sat: Satellite, site: Site, t0: Time, days=3.0,
                min_alt_deg=10.0, step_s=20.0, dark_only=True,
                sunlit_only=True, max_passes=20):
    """Upcoming passes of one satellite above ``min_alt_deg``.

    ``dark_only`` keeps only passes culminating while the Sun is below
    −6° (civil twilight); ``sunlit_only`` keeps only those where the
    satellite is out of the Earth's shadow at culmination — together,
    the passes that are actually *visible*.
    """
    n = int(days * 86400.0 / step_s) + 1
    az, alt, rng, lit, mag = satellite_track(eph, sat, t0, step_s, n, site)
    above = np.nan_to_num(alt, nan=-90.0) > min_alt_deg
    if not above.any():
        return []
    edges = np.diff(above.astype(np.int8))
    starts = list(np.flatnonzero(edges == 1) + 1)
    ends = list(np.flatnonzero(edges == -1) + 1)
    if above[0]:
        starts.insert(0, 0)
    if above[-1]:
        ends.append(len(above) - 1)

    obs = np.asarray(site.geocentric_xyz_km(), dtype=float)

    def at(i):
        return Time(t0.tt1, t0.tt2 + i * step_s / 86400.0)

    def alt_at(i):
        """Altitude alone — no ephemeris call, one SGP4 evaluation."""
        ti = at(i)
        r = teme_to_pef(sat.teme_at(ti)[0], ti)
        return float(_enu(r - obs, site)[1][0])

    def refine(i_lo, i_hi):
        """Bisect the alt = min_alt crossing between two samples
        (~step_s/2^14 ≈ ms precision, one SGP4 call per iteration)."""
        lo, hi = float(i_lo), float(i_hi)
        lo_above = alt_at(lo) > min_alt_deg
        for _ in range(14):
            mid = 0.5 * (lo + hi)
            if (alt_at(mid) > min_alt_deg) == lo_above:
                lo = mid
            else:
                hi = mid
        return 0.5 * (lo + hi)

    out = []
    for i0, i1 in zip(starts, ends):
        if len(out) >= max_passes:
            break
        k = i0 + int(np.argmax(alt[i0:i1 + 1]))
        if sunlit_only and not bool(lit[k]):
            continue
        # culmination: parabolic vertex through the three coarse samples
        kf = float(k)
        if 0 < k < n - 1:
            a0_, a1_, a2_ = alt[k - 1], alt[k], alt[k + 1]
            den = a0_ - 2.0 * a1_ + a2_
            if den < -1e-9:
                kf = k + 0.5 * (a0_ - a2_) / den
        t_max = at(kf)
        s_alt = float(np.atleast_1d(_sun_alt(eph, t_max, site))[0])
        if dark_only and s_alt > -6.0:
            continue
        # `starts`/`ends` index the first sample inside / outside the
        # pass, so each crossing is bracketed by (index-1, index)
        i_rise = float(i0) if (i0 == 0 and above[0]) else refine(i0 - 1, i0)
        i_set = float(i1) if above[i1] else refine(i1 - 1, i1)
        m_az, m_alt, _r, m_lit, m_mag = satellite_track(
            eph, sat, t_max, 1.0, 1, site)
        out.append({
            "rise": at(i_rise), "max": t_max, "set": at(i_set),
            "max_alt": round(float(m_alt[0]), 1),
            "rise_az": round(float(az[int(round(i_rise))]), 1),
            "max_az": round(float(m_az[0]), 1),
            "set_az": round(float(az[int(round(i_set))]), 1),
            "duration_s": round((i_set - i_rise) * step_s),
            "mag": round(float(m_mag[0]), 1) if bool(m_lit[0]) else None,
            "sun_alt": round(s_alt, 1),
            "sunlit": bool(m_lit[0]),
        })
    return out


# ---------------------------------------------------------------------------
# element registry (Celestrak download + offline cache)
# ---------------------------------------------------------------------------
CELESTRAK = ("https://celestrak.org/NORAD/elements/gp.php?"
             "GROUP={group}&FORMAT=tle")

GROUPS = [
    ("stations", "宇宙ステーション (ISS・天宮)",
     "Space stations (ISS, Tiangong)"),
    ("visual", "肉眼で見える衛星 (Brightest)", "Brightest (visual)"),
    ("science", "科学衛星", "Science"),
    ("starlink", "Starlink", "Starlink"),
    ("weather", "気象衛星", "Weather"),
]
GROUP_KEYS = [g[0] for g in GROUPS]


def _download(url: str, timeout=90) -> str:
    """System curl — anaconda's libcurl is broken on some hosts and the
    stdlib opener trips on Celestrak's TLS front end (same approach as
    mpc.py)."""
    r = subprocess.run(["/usr/bin/curl", "-sSL", "--max-time",
                        str(timeout), url], capture_output=True, text=True)
    if r.returncode != 0 or not r.stdout.strip():
        raise ConnectionError(f"TLE download failed: {url}: "
                              f"{r.stderr[:200]}")
    if "<html" in r.stdout[:200].lower():
        raise ConnectionError(f"TLE download returned HTML: {url}")
    return r.stdout


class TLERegistry:
    """Element sets on disk under ``data/tle/`` (offline after first
    fetch, spec §10).  ``<group>.txt`` holds the raw TLE stream and
    ``index.json`` records when each group was retrieved."""

    def __init__(self, path: str | None = None):
        self.path = path or _DATA
        os.makedirs(self.path, exist_ok=True)
        self._cache: dict[str, list[Satellite]] = {}

    # -- disk -----------------------------------------------------------
    def _file(self, group: str) -> str:
        safe = "".join(c for c in group if c.isalnum() or c in "-_")
        return os.path.join(self.path, f"{safe}.txt")

    def _index_path(self) -> str:
        return os.path.join(self.path, "index.json")

    def index(self) -> dict:
        p = self._index_path()
        if os.path.exists(p):
            try:
                with open(p, encoding="utf-8") as f:
                    return json.load(f)
            except (ValueError, OSError):
                pass
        return {}

    def _write_index(self, group: str, count: int, skipped: int):
        idx = self.index()
        idx[group] = {"fetched": _time.strftime("%Y-%m-%dT%H:%M:%SZ",
                                                _time.gmtime()),
                      "count": count, "deep_space_skipped": skipped,
                      "source": CELESTRAK.format(group=group)}
        with open(self._index_path(), "w", encoding="utf-8") as f:
            json.dump(idx, f, ensure_ascii=False, indent=1)

    # -- api ------------------------------------------------------------
    def update(self, group: str, timeout=90) -> dict:
        """Download one Celestrak group and cache it."""
        return self.import_text(
            group, _download(CELESTRAK.format(group=group), timeout=timeout))

    def import_text(self, group: str, text: str) -> dict:
        """Cache element-set text that somebody else fetched.

        The WebAssembly build has no subprocess and no sockets, so it
        cannot run the download itself — the page fetches the group
        (Celestrak serves it with a permissive CORS header) and hands
        the text here.  The parsing, validation and indexing are the
        same either way, so a downloaded and an imported group are
        indistinguishable afterwards.
        """
        if group not in GROUP_KEYS:
            raise ValueError(f"unknown group {group!r}")
        tles = parse_tle(text)
        if not tles:
            raise ValueError(f"no elements parsed for group {group!r}")
        with open(self._file(group), "w", encoding="utf-8") as f:
            f.write(text)
        self._cache.pop(group, None)
        sats = self.load(group)
        skipped = len(tles) - len(sats)
        self._write_index(group, len(sats), skipped)
        return {"group": group, "count": len(sats),
                "deep_space_skipped": skipped}

    def load(self, group: str) -> list[Satellite]:
        """Satellites of one cached group ([] when never downloaded)."""
        if group in self._cache:
            return self._cache[group]
        p = self._file(group)
        if not os.path.exists(p):
            return []
        with open(p, encoding="utf-8") as f:
            tles = parse_tle(f.read())
        sats = []
        for e in tles:
            try:
                sats.append(Satellite(e))
            except Sgp4Error:
                continue                     # deep-space / decayed
        self._cache[group] = sats
        return sats

    def satellites(self, groups=None) -> list[Satellite]:
        """Union of the given (or all cached) groups, deduplicated by
        NORAD number — ``stations`` and ``visual`` overlap on the ISS."""
        groups = groups or [g for g in GROUP_KEYS
                            if os.path.exists(self._file(g))]
        seen, out = set(), []
        for g in groups:
            for s in self.load(g):
                if s.satnum in seen:
                    continue
                seen.add(s.satnum)
                out.append(s)
        return out

    def find(self, query: str, groups=None) -> list[Satellite]:
        q = query.strip().lower()
        return [s for s in self.satellites(groups)
                if q in s.name.lower() or q == str(s.satnum)]
