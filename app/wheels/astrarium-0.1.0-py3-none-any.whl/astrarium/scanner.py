"""Event scanner (spec §10): every event in a period, one sorted list.

Aggregates: moon phases, lunar apsides, seasons, planetary conjunctions/
oppositions/greatest elongations/stations, meteor-shower maxima, solar &
lunar eclipses, and (optionally) exoplanet transits & variable-star
extrema for user-registered targets.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .ephemeris import Ephemeris
from .meteors import MeteorCalendar
from .observer import Site
from .phenomena import (find_conjunctions_oppositions,
                        find_greatest_elongations, find_moon_apsides,
                        find_moon_phases, find_seasons, find_stations)
from .timescale import Time

PLANETS_ALL = ["mercury", "venus", "mars", "jupiter", "saturn",
               "uranus", "neptune"]


@dataclass
class ScanResult:
    kind: str          # category id, i18n key: event.<kind>
    body: str
    time: Time
    value: float | None = None
    detail: dict = field(default_factory=dict)


def scan_events(eph: Ephemeris, t0: Time, t1: Time,
                site: Site | None = None,
                categories: set[str] | None = None,
                planets=None) -> list[ScanResult]:
    """Scan [t0, t1] for all requested event categories.

    categories ⊆ {'moon','seasons','planets','meteors','eclipses'};
    None = all.  Site affects meteor local circumstances and eclipse
    local visibility annotation only (event times are geocentric).
    """
    cats = categories or {"moon", "seasons", "planets", "meteors",
                          "eclipses"}
    out: list[ScanResult] = []

    if "moon" in cats:
        for p in find_moon_phases(eph, t0, t1):
            out.append(ScanResult(p.kind, "moon", p.time))
        for p in find_moon_apsides(eph, t0, t1):
            out.append(ScanResult(p.kind, "moon", p.time, value=p.value))

    if "seasons" in cats:
        for p in find_seasons(eph, t0, t1):
            out.append(ScanResult(p.kind, "sun", p.time))

    if "planets" in cats:
        for body in (planets or PLANETS_ALL):
            for p in find_conjunctions_oppositions(eph, body, t0, t1):
                out.append(ScanResult(p.kind, body, p.time, value=p.value))
            for p in find_stations(eph, body, t0, t1):
                out.append(ScanResult(p.kind, body, p.time))
            if body in ("mercury", "venus"):
                for p in find_greatest_elongations(eph, body, t0, t1):
                    out.append(ScanResult(p.kind, body, p.time,
                                          value=p.value))

    if "meteors" in cats:
        cal = MeteorCalendar()
        for ev in cal.peaks_between(eph, t0, t1, site):
            out.append(ScanResult(
                "meteor_shower_maximum", ev.iau_code, ev.peak,
                value=ev.zhr,
                detail={"name_ja": ev.name_ja, "name_en": ev.name_en,
                        # radiant + shower parameters: the chart animates
                        # the shower from these
                        "radiant_ra": ev.radiant_ra_deg,
                        "radiant_dec": ev.radiant_dec_deg,
                        "vinf": ev.vinf_km_s, "r": ev.r, "zhr": ev.zhr,
                        "parent_ja": ev.parent_ja,
                        "parent_en": ev.parent_en,
                        "radiant_alt": ev.radiant_alt_at_peak,
                        "moon_illum": ev.moon_illum,
                        "moon_condition": ev.moon_condition,
                        "radiant_alt": ev.radiant_alt_at_peak}))

    if "eclipses" in cats:
        from .eclipses import find_lunar_eclipses, find_solar_eclipses
        for e in find_solar_eclipses(eph, t0, t1):
            out.append(ScanResult("solar_eclipse", "sun", e.t_max,
                                  value=e.magnitude,
                                  detail={"kind": e.kind,
                                          "gamma": e.gamma}))
        for e in find_lunar_eclipses(eph, t0, t1):
            out.append(ScanResult("lunar_eclipse", "moon", e.t_max,
                                  value=e.umbral_magnitude,
                                  detail={"kind": e.kind}))

    out.sort(key=lambda r: r.time.jd_tt)
    return out
