"""Internationalization (spec §8): external JSON resources, instant
switching, locale-following date/number formats.

Adding a third language = dropping data/i18n/<code>.json with the same
keys; no code change required.
"""
from __future__ import annotations

import datetime
import json
import os

from .paths import data_path
_DATA = data_path("i18n")


class I18n:
    def __init__(self, lang="ja", data_dir: str | None = None):
        self.dir = data_dir or _DATA
        self._cache: dict[str, dict] = {}
        self.lang = lang

    def available(self) -> list[str]:
        return sorted(f[:-5] for f in os.listdir(self.dir)
                      if f.endswith(".json"))

    def _table(self, lang) -> dict:
        if lang not in self._cache:
            with open(os.path.join(self.dir, f"{lang}.json"),
                      encoding="utf-8") as f:
                self._cache[lang] = json.load(f)
        return self._cache[lang]

    def t(self, key: str, lang: str | None = None, **fmt) -> str:
        """Translate `key`; falls back to English, then to the key."""
        lang = lang or self.lang
        s = self._table(lang).get(key)
        if s is None and lang != "en":
            s = self._table("en").get(key)
        if s is None:
            return key
        return s.format(**fmt) if fmt else s

    def fmt_date(self, dt: datetime.datetime, lang: str | None = None) -> str:
        return dt.strftime(self.t("ui.date_format", lang))

    def fmt_datetime(self, dt: datetime.datetime,
                     lang: str | None = None) -> str:
        return dt.strftime(self.t("ui.datetime_format", lang))

    def event_name(self, kind: str, subkind: str | None = None,
                   lang: str | None = None) -> str:
        if subkind:
            s = self._table(lang or self.lang).get(
                f"event.{kind}.{subkind}")
            if s:
                return s
        return self.t(f"event.{kind}", lang)
