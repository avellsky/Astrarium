"""JPL DE ephemeris abstraction layer.

Reads SPK kernels via `jplephem` (Rhodes, MIT).  DE421 is bundled
(data/de421.bsp, NASA/JPL, public domain); any DE (DE430/DE440/DE441)
can be substituted by passing its path or setting ASTRARIUM_EPHEMERIS —
the segment chain is resolved generically from the kernel's pair table
(spec §11: DE-series abstraction layer).

Positions are returned in au (ICRF/BCRS axes), velocities in au/day,
with TDB Julian dates as the independent variable.
"""
from __future__ import annotations

import functools
import os

import numpy as np
from jplephem.spk import SPK

from .constants import AU_KM, NAIF

from .paths import data_dir
_DATA_DIR = data_dir()

_ALIASES = {
    # name -> preferred NAIF chain targets, first available wins
    "sun": (10,), "moon": (301,), "earth": (399,), "emb": (3,),
    "mercury": (199, 1), "venus": (299, 2), "mars": (499, 4),
    "jupiter": (599, 5), "saturn": (699, 6), "uranus": (799, 7),
    "neptune": (899, 8), "pluto": (999, 9), "ssb": (0,),
}


class Ephemeris:
    """Barycentric state vectors from a JPL SPK kernel."""

    def __init__(self, path: str | None = None):
        if path is None:
            path = os.environ.get(
                "ASTRARIUM_EPHEMERIS",
                os.path.join(_DATA_DIR, "de421.bsp"))
        if not os.path.exists(path):
            raise FileNotFoundError(
                f"Ephemeris kernel not found: {path}\n"
                "Download DE421 (17 MB):\n"
                "  curl -o data/de421.bsp "
                "https://ssd.jpl.nasa.gov/ftp/eph/planets/bsp/de421.bsp")
        self.path = path
        self.kernel = SPK.open(path)
        self._pairs = {(seg.center, seg.target): seg
                       for seg in self.kernel.segments}
        # precompute chains from SSB (0) for each reachable code
        self._chains: dict[int, list] = {0: []}
        changed = True
        while changed:
            changed = False
            for (c, t), seg in self._pairs.items():
                if c in self._chains and t not in self._chains:
                    self._chains[t] = self._chains[c] + [seg]
                    changed = True

    def naif_code(self, body) -> int:
        if isinstance(body, int):
            return body
        name = str(body).lower()
        for code in _ALIASES.get(name, ()):
            if code in self._chains:
                return code
        if name in NAIF and NAIF[name] in self._chains:
            return NAIF[name]
        raise KeyError(f"body {body!r} not in kernel {self.path}")

    def pv_bary(self, body, jd_tdb1, jd_tdb2=0.0):
        """Barycentric position [au] and velocity [au/day] (ICRF axes).

        jd may be scalar or ndarray; returns arrays shaped (..., 3).
        """
        code = self.naif_code(body)
        b = np.broadcast(np.asarray(jd_tdb1, dtype=float),
                         np.asarray(jd_tdb2, dtype=float))
        jd1 = np.broadcast_to(np.asarray(jd_tdb1, dtype=float), b.shape)
        jd2 = np.broadcast_to(np.asarray(jd_tdb2, dtype=float), b.shape)
        p = np.zeros(b.shape + (3,))
        v = np.zeros(b.shape + (3,))
        for seg in self._chains[code]:
            pp, vv = seg.compute_and_differentiate(jd1.ravel(), jd2.ravel())
            p += np.moveaxis(np.asarray(pp), 0, -1).reshape(b.shape + (3,))
            v += np.moveaxis(np.asarray(vv), 0, -1).reshape(b.shape + (3,))
        return p / AU_KM, v / AU_KM

    @property
    def coverage_jd(self):
        """(start, end) TDB JD common to all segments."""
        s = max(seg.start_jd for seg in self.kernel.segments)
        e = min(seg.end_jd for seg in self.kernel.segments)
        return s, e


@functools.lru_cache(maxsize=2)
def get_ephemeris(path: str | None = None) -> Ephemeris:
    return Ephemeris(path)
