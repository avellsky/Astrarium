"""Time scales and conversions.

Supported scales (spec §4): UTC / UT1 / TAI / TT / TDB / GPS, JD / MJD,
local civil time via IANA time zones (JST etc.), mean & apparent sidereal
time (GMST/GAST/LMST/LAST), BJD_TDB & HJD (see `lighttime.py`).

Algorithms / sources
--------------------
- Leap seconds: ERFA `dat` (IAU SOFA table; current through the 2017-01-01
  leap second — none has been announced since, valid as of 2026).  See
  `leap_second_status()` for how that assumption is checked, and the note
  on ERFA's "dubious year" warning below.
- TT-TDB: ERFA `dtdb` (Fairhead & Bretagnon 1990 series, ~10 ns accuracy
  at the geocenter — far inside the 10 ms requirement).
- UT1: UT1-UTC from IERS finals2000A.all (bundled; measured + ~1 yr
  prediction).  Outside the IERS range, ΔT from the Espenak & Meeus (2006)
  polynomial fit (NASA Eclipse Web Site) is used and UT1-UTC is derived as
  (TT-UTC) - ΔT; accuracy then degrades to seconds-level (documented).
- GMST/GAST: ERFA `gmst06` / `gst06a` (IAU 2006/2000A).
- GPS: TAI - 19 s exactly.

ERFA "dubious year" warnings
----------------------------
Every UTC routine in ERFA raises a "dubious year" warning for dates more
than five years after the release of the ERFA/SOFA build in use, because
past that horizon its compiled leap-second table cannot be authoritative.
The horizon is a property of the *build*, not of the data: pyerfa 2.0.1.5
warns from 2029 onwards no matter how current the table is, and the
warning cannot be cleared by extending the table (the cut-off is a
compiled-in constant).

This package routinely and deliberately works decades ahead — the event
scanner covers ten years, eclipse and transit predictions more — so the
warning fires on ordinary use while telling the user nothing they can act
on.  It is therefore filtered here, and *only* for that message: every
other ERFA warning (unacceptable date, unphysical arguments, ...) still
propagates.

The assumption it stands on is checked instead of being taken on trust —
`leap_second_status()` reports the tabulated ΔAT and scans the bundled
IERS series for a UT1-UTC discontinuity that the table does not know
about, which is what an unannounced leap second would look like.

All Time objects are immutable and internally store TT as a two-part
Julian date (erfa convention) for full numerical precision.
"""
from __future__ import annotations

import datetime as _dt
import functools
import os
import warnings
import zoneinfo
from dataclasses import dataclass

import erfa
import numpy as np

from .constants import (DAYS_PER_JULIAN_CENTURY, JD_J2000, SECONDS_PER_DAY,
                        TT_MINUS_TAI_S)

from .paths import data_dir
_DATA_DIR = data_dir()

# See "ERFA dubious year warnings" in the module docstring: this is the
# one ERFA message that says nothing actionable about our inputs, and it
# is unavoidable for the future dates this package is built to handle.
warnings.filterwarnings(
    "ignore", message=r'.*"dubious year.*', category=erfa.ErfaWarning)


def leap_second_status(eop: "EOP | None" = None) -> dict:
    """Audit the leap-second assumption the warning filter rests on.

    Returns the last tabulated leap second and the current ΔAT, plus any
    UT1-UTC discontinuity in the bundled IERS series that occurs *after*
    that entry.  A real leap second shows up there as a jump of very
    nearly one second, so an entry in ``unknown_jumps`` means the ERFA
    build is out of date and the times it produces would be one second
    wrong from that day on.
    """
    table = erfa.leap_seconds.get()
    last = table[-1]
    now = _dt.datetime.now(_dt.timezone.utc)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", erfa.ErfaWarning)
        dat_now = float(erfa.dat(now.year, now.month, now.day, 0.0))
    eop = eop or EOP.bundled()
    jumps = []
    if eop is not None and len(eop.mjd) > 2:
        # MJD of the day after the last tabulated leap second
        d0, d1 = erfa.cal2jd(int(last["year"]), int(last["month"]), 1)
        mjd_last = (d0 - 2400000.5) + d1
        d = np.diff(np.asarray(eop.dut1, dtype=float))
        m = np.asarray(eop.mjd, dtype=float)[1:]
        for k in np.flatnonzero((np.abs(d) > 0.5) & (m > mjd_last + 1)):
            jumps.append({"mjd": float(m[k]), "step_s": float(d[k])})
    tai_utc = float(last[table.dtype.names[-1]])
    return {"last_leap": {"year": int(last["year"]),
                          "month": int(last["month"]),
                          "delta_at_s": tai_utc},
            "delta_at_now_s": dat_now,
            "eop_last_mjd": (float(np.max(eop.mjd))
                             if eop is not None and len(eop.mjd) else None),
            "unknown_jumps": jumps,
            "ok": not jumps and dat_now == tai_utc}


# ----------------------------------------------------------------------
# Earth orientation (UT1-UTC, polar motion)
# ----------------------------------------------------------------------
class EOP:
    """Earth-orientation parameters from IERS finals2000A.all.

    Provides UT1-UTC [s] and polar motion xp, yp [arcsec] by MJD (UTC),
    linearly interpolated.  Outside the table the Espenak-Meeus ΔT
    polynomial fallback is applied by `Time`.
    """

    def __init__(self, mjd, dut1, xp, yp):
        self.mjd = np.asarray(mjd)
        self.dut1 = np.asarray(dut1)
        self.xp = np.asarray(xp)
        self.yp = np.asarray(yp)

    @classmethod
    def from_finals(cls, path: str) -> "EOP":
        """Parse IERS finals2000A.all (fixed-width format).

        Uses Bulletin A values (columns: flag 'I'/'P').  Rows without
        UT1-UTC are skipped (far-future prediction tail).
        """
        mjd, dut1, xp, yp = [], [], [], []
        with open(path) as f:
            for line in f:
                if len(line) < 68:
                    continue
                try:
                    m = float(line[7:15])
                    x = line[18:27].strip()
                    y = line[37:46].strip()
                    d = line[58:68].strip()
                    if not d:
                        continue
                    mjd.append(m)
                    xp.append(float(x) if x else 0.0)
                    yp.append(float(y) if y else 0.0)
                    dut1.append(float(d))
                except ValueError:
                    continue
        return cls(mjd, dut1, xp, yp)

    @classmethod
    @functools.lru_cache(maxsize=1)
    def bundled(cls) -> "EOP":
        path = os.path.join(_DATA_DIR, "finals2000A.all")
        if os.path.exists(path):
            return cls.from_finals(path)
        # empty table -> polynomial fallback everywhere
        return cls([], [], [], [])

    def interp(self, mjd_utc):
        """Return (dut1 [s], xp [arcsec], yp [arcsec], inside_table)."""
        if len(self.mjd) == 0:
            z = np.zeros_like(np.asarray(mjd_utc, dtype=float))
            return z, z, z, np.zeros(np.shape(mjd_utc), dtype=bool)
        m = np.asarray(mjd_utc, dtype=float)
        inside = (m >= self.mjd[0]) & (m <= self.mjd[-1])
        dut1 = np.interp(m, self.mjd, self.dut1)
        xp = np.interp(m, self.mjd, self.xp)
        yp = np.interp(m, self.mjd, self.yp)
        return dut1, xp, yp, inside

    def extrapolate_delta_t(self, mjd_utc, tt_minus_utc_s):
        """ΔT beyond the table end: linear trend of the last year of data.

        Explicit future-extrapolation model (spec §4): the excess length
        of day is taken from a least-squares fit to the final 365 days of
        UT1-UTC and continued linearly.  Documented accuracy: ~±1 s over
        a decade (Earth-rotation variability dominates).  Note: leap
        seconds are unknown for the future, so ΔT (not UT1-UTC) is the
        quantity extrapolated against a constant TT-UTC.
        """
        m = np.asarray(mjd_utc, dtype=float)
        sel = self.mjd >= self.mjd[-1] - 365.0
        x = self.mjd[sel] - self.mjd[-1]
        y = self.dut1[sel]
        slope, icpt = np.polyfit(x, y, 1)
        dut1_ext = icpt + slope * (m - self.mjd[-1])
        return tt_minus_utc_s - dut1_ext


def delta_t_espenak_meeus(year):
    """ΔT = TT - UT1 [s] polynomial fit, Espenak & Meeus (2006).

    Valid -1999..+3000; used only outside the IERS table.
    Reference: NASA Eclipse Web Site, "Polynomial Expressions for Delta T".
    """
    y = np.asarray(year, dtype=float)
    dt = np.empty_like(y)

    def _seg(mask, f):
        if np.any(mask):
            dt[mask] = f(y[mask])

    _seg(y < -500, lambda y: -20 + 32 * ((y - 1820) / 100) ** 2)
    _seg((y >= -500) & (y < 500), lambda y: (
        10583.6 - 1014.41 * (u := y / 100) + 33.78311 * u**2 - 5.952053 * u**3
        - 0.1798452 * u**4 + 0.022174192 * u**5 + 0.0090316521 * u**6))
    _seg((y >= 500) & (y < 1600), lambda y: (
        1574.2 - 556.01 * (u := (y - 1000) / 100) + 71.23472 * u**2
        + 0.319781 * u**3 - 0.8503463 * u**4 - 0.005050998 * u**5
        + 0.0083572073 * u**6))
    _seg((y >= 1600) & (y < 1700), lambda y: (
        120 - 0.9808 * (t := y - 1600) - 0.01532 * t**2 + t**3 / 7129))
    _seg((y >= 1700) & (y < 1800), lambda y: (
        8.83 + 0.1603 * (t := y - 1700) - 0.0059285 * t**2
        + 0.00013336 * t**3 - t**4 / 1174000))
    _seg((y >= 1800) & (y < 1860), lambda y: (
        13.72 - 0.332447 * (t := y - 1800) + 0.0068612 * t**2
        + 0.0041116 * t**3 - 0.00037436 * t**4 + 0.0000121272 * t**5
        - 0.0000001699 * t**6 + 0.000000000875 * t**7))
    _seg((y >= 1860) & (y < 1900), lambda y: (
        7.62 + 0.5737 * (t := y - 1860) - 0.251754 * t**2 + 0.01680668 * t**3
        - 0.0004473624 * t**4 + t**5 / 233174))
    _seg((y >= 1900) & (y < 1920), lambda y: (
        -2.79 + 1.494119 * (t := y - 1900) - 0.0598939 * t**2
        + 0.0061966 * t**3 - 0.000197 * t**4))
    _seg((y >= 1920) & (y < 1941), lambda y: (
        21.20 + 0.84493 * (t := y - 1920) - 0.076100 * t**2 + 0.0020936 * t**3))
    _seg((y >= 1941) & (y < 1961), lambda y: (
        29.07 + 0.407 * (t := y - 1950) - t**2 / 233 + t**3 / 2547))
    _seg((y >= 1961) & (y < 1986), lambda y: (
        45.45 + 1.067 * (t := y - 1975) - t**2 / 260 - t**3 / 718))
    _seg((y >= 1986) & (y < 2005), lambda y: (
        63.86 + 0.3345 * (t := y - 2000) - 0.060374 * t**2 + 0.0017275 * t**3
        + 0.000651814 * t**4 + 0.00002373599 * t**5))
    _seg((y >= 2005) & (y < 2050), lambda y: (
        62.92 + 0.32217 * (t := y - 2000) + 0.005589 * t**2))
    _seg((y >= 2050) & (y < 2150), lambda y: (
        -20 + 32 * ((y - 1820) / 100) ** 2 - 0.5628 * (2150 - y)))
    _seg(y >= 2150, lambda y: -20 + 32 * ((y - 1820) / 100) ** 2)
    return dt if dt.shape else float(dt)


# ----------------------------------------------------------------------
# Time
# ----------------------------------------------------------------------
@dataclass(frozen=True)
class Time:
    """An instant, stored as two-part TT Julian date (broadcastable arrays)."""
    tt1: object   # float or ndarray
    tt2: object

    # ---- constructors -------------------------------------------------
    @classmethod
    def from_tt_jd(cls, jd1, jd2=0.0):
        return cls(jd1, jd2)

    @classmethod
    def from_tai_jd(cls, jd1, jd2=0.0):
        return cls(*erfa.taitt(jd1, jd2))

    @classmethod
    def from_tdb_jd(cls, jd1, jd2=0.0):
        # TDB -> TT: iterate once with dtdb (difference varies < 2 ms)
        d = erfa.dtdb(jd1, jd2, 0.0, 0.0, 0.0, 0.0)
        return cls(*erfa.tdbtt(jd1, jd2, d))

    @classmethod
    def from_utc_jd(cls, jd1, jd2=0.0):
        tai1, tai2 = erfa.utctai(jd1, jd2)
        return cls(*erfa.taitt(tai1, tai2))

    @classmethod
    def from_ut1_jd(cls, jd1, jd2=0.0, eop: EOP | None = None):
        # UT1 -> TT via ΔT (iterated once; ΔT varies slowly)
        approx = cls.from_utc_jd(jd1, jd2)   # coarse for ΔT lookup
        dt = approx.delta_t
        return cls(*erfa.ut1tt(jd1, jd2, dt))

    @classmethod
    def from_utc(cls, when) -> "Time":
        """From ISO string ('2026-07-18T12:00:00' or with 'Z') or datetime.

        Naive datetimes are interpreted as UTC; aware datetimes are
        converted.  Leap-second times (23:59:60) accepted via erfa.dtf2d.
        """
        if isinstance(when, str):
            s = when.replace("Z", "").replace("z", "")
            d, t = (s.split("T") + ["00:00:00"])[:2] if "T" in s else (s, "00:00:00")
            y, mo, dd = [int(x) for x in d.split("-")]
            parts = t.split(":") + ["0", "0"]
            h, mi = int(parts[0]), int(parts[1])
            sec = float(parts[2])
            jd1, jd2 = erfa.dtf2d("UTC", y, mo, dd, h, mi, sec)
            return cls.from_utc_jd(jd1, jd2)
        if isinstance(when, _dt.datetime):
            if when.tzinfo is not None:
                when = when.astimezone(_dt.timezone.utc)
            jd1, jd2 = erfa.dtf2d("UTC", when.year, when.month, when.day,
                                  when.hour, when.minute,
                                  when.second + when.microsecond / 1e6)
            return cls.from_utc_jd(jd1, jd2)
        raise TypeError(f"unsupported type {type(when)}")

    @classmethod
    def from_local(cls, when: _dt.datetime, tz: str) -> "Time":
        """From a naive local civil time in IANA zone `tz` (e.g. Asia/Tokyo)."""
        z = zoneinfo.ZoneInfo(tz)
        return cls.from_utc(when.replace(tzinfo=z))

    @classmethod
    def now(cls) -> "Time":
        return cls.from_utc(_dt.datetime.now(_dt.timezone.utc))

    @classmethod
    def from_jd(cls, jd, scale="utc"):
        f = {"utc": cls.from_utc_jd, "tt": cls.from_tt_jd,
             "tdb": cls.from_tdb_jd, "tai": cls.from_tai_jd,
             "ut1": cls.from_ut1_jd}[scale.lower()]
        return f(jd, 0.0)

    # ---- scale conversions --------------------------------------------
    @property
    def tt(self):
        return self.tt1, self.tt2

    @property
    def tai(self):
        return erfa.tttai(self.tt1, self.tt2)

    @property
    def utc(self):
        tai1, tai2 = self.tai
        return erfa.taiutc(tai1, tai2)

    @property
    def tdb(self):
        d = erfa.dtdb(self.tt1, self.tt2, 0.0, 0.0, 0.0, 0.0)
        return erfa.tttdb(self.tt1, self.tt2, d)

    @property
    def ut1(self):
        return erfa.ttut1(self.tt1, self.tt2, self.delta_t)

    # ---- scalar JD accessors ------------------------------------------
    @property
    def jd_tt(self):
        return self.tt1 + self.tt2

    @property
    def jd_utc(self):
        u1, u2 = self.utc
        return u1 + u2

    @property
    def jd_tdb(self):
        d1, d2 = self.tdb
        return d1 + d2

    @property
    def jd_ut1(self):
        u1, u2 = self.ut1
        return u1 + u2

    @property
    def mjd_utc(self):
        u1, u2 = self.utc
        return (u1 - 2400000.5) + u2

    @property
    def gps(self):
        """Two-part JD in the GPS timescale (GPS = TAI - 19 s exactly)."""
        a1, a2 = self.tai
        return a1, a2 - 19.0 / SECONDS_PER_DAY

    # ---- earth orientation --------------------------------------------
    @property
    def _eop(self):
        d, xp, yp, inside = EOP.bundled().interp(self.mjd_utc)
        return d, xp, yp, inside

    @property
    def dut1(self):
        """UT1-UTC [s].

        IERS finals2000A inside the table; beyond its end, a linear
        extrapolation of the last year's trend; before its start (pre
        1973), the Espenak-Meeus ΔT polynomial (fitted to historical
        measurements).
        """
        d, _, _, inside = self._eop
        if np.all(inside):
            return d
        u1, u2 = self.utc
        tt_minus_utc = (self.tt1 - u1 + self.tt2 - u2) * SECONDS_PER_DAY
        eop = EOP.bundled()
        mjd = self.mjd_utc
        if len(eop.mjd):
            future = np.asarray(mjd) > eop.mjd[-1]
            dt_fb = np.where(
                future,
                eop.extrapolate_delta_t(mjd, tt_minus_utc),
                delta_t_espenak_meeus(self.decimal_year))
        else:
            dt_fb = delta_t_espenak_meeus(self.decimal_year)
        fb = tt_minus_utc - dt_fb
        return np.where(inside, d, fb) if np.ndim(d) else (d if inside else float(fb))

    @property
    def polar_motion(self):
        """(xp, yp) [arcsec]; zeros outside the IERS table."""
        _, xp, yp, inside = self._eop
        return np.where(inside, xp, 0.0), np.where(inside, yp, 0.0)

    @property
    def delta_t(self):
        """ΔT = TT - UT1 [s] (source logic documented under `dut1`)."""
        u1, u2 = self.utc
        tt_minus_utc = (self.tt1 - u1 + self.tt2 - u2) * SECONDS_PER_DAY
        return tt_minus_utc - self.dut1

    @property
    def decimal_year(self):
        return 2000.0 + (self.jd_tt - JD_J2000) / 365.25

    # ---- sidereal time -------------------------------------------------
    def gmst(self):
        """Greenwich mean sidereal time [rad], IAU 2006."""
        u1, u2 = self.ut1
        return erfa.gmst06(u1, u2, self.tt1, self.tt2)

    def gast(self):
        """Greenwich apparent sidereal time [rad], IAU 2006/2000A."""
        u1, u2 = self.ut1
        return erfa.gst06a(u1, u2, self.tt1, self.tt2)

    def lst(self, lon_deg, apparent=True):
        """Local (mean|apparent) sidereal time [hours] at east longitude."""
        theta = self.gast() if apparent else self.gmst()
        h = (theta + np.deg2rad(lon_deg)) * 12.0 / np.pi
        return h % 24.0

    # ---- formatting -----------------------------------------------------
    def _dtf(self, ndp):
        """Scalar civil-date breakdown (y, mo, d, h, mi, s, frac)."""
        u1, u2 = self.utc
        y, mo, d, hmsf = erfa.d2dtf("UTC", ndp, u1, u2)
        h, mi, s, f = (int(v) for v in np.asarray(hmsf).item())
        return int(y), int(mo), int(d), h, mi, s, f

    def datetime_utc(self) -> _dt.datetime:
        y, mo, d, h, mi, s, us = self._dtf(6)
        return _dt.datetime(y, mo, d, h, mi, min(s, 59), us,
                            tzinfo=_dt.timezone.utc)

    def datetime_local(self, tz: str) -> _dt.datetime:
        return self.datetime_utc().astimezone(zoneinfo.ZoneInfo(tz))

    def iso_utc(self, ndp=1) -> str:
        y, mo, d, h, mi, s, f = self._dtf(ndp)
        frac = f".{f:0{ndp}d}" if ndp > 0 else ""
        return f"{y:04d}-{mo:02d}-{d:02d}T{h:02d}:{mi:02d}:{s:02d}{frac}"

    def iso_local(self, tz: str) -> str:
        return self.datetime_local(tz).strftime("%Y-%m-%d %H:%M:%S %Z")

    # ---- arithmetic ------------------------------------------------------
    def __add__(self, days):
        return Time(self.tt1, self.tt2 + days)

    def __sub__(self, other):
        if isinstance(other, Time):
            return (self.tt1 - other.tt1) + (self.tt2 - other.tt2)
        return Time(self.tt1, self.tt2 - other)

    def __repr__(self):
        try:
            return f"<Time {self.iso_utc()} UTC>"
        except Exception:
            return f"<Time array jd_tt~{np.mean(self.jd_tt):.5f}>"


def linspace(t0: Time, t1: Time, n: int) -> Time:
    """n Time samples spanning [t0, t1] (TT-uniform)."""
    span = (t1.tt1 - t0.tt1) + (t1.tt2 - t0.tt2)
    return Time(t0.tt1, t0.tt2 + np.linspace(0.0, span, n))
