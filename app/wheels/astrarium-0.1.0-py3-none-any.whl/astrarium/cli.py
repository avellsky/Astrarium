"""Command-line interface.

    python -m astrarium.cli tonight --site jp-tokyo
    python -m astrarium.cli riseset --site jp-tokyo --body moon
    python -m astrarium.cli scan --site jp-tokyo --days 30 --ics out.ics
    python -m astrarium.cli chart --site jp-tokyo --out chart.svg
    python -m astrarium.cli ephem --body mars --days 10 --step 1
    python -m astrarium.cli meteors --site jp-tokyo --days 60
    python -m astrarium.cli transits --site jp-tokyo --days 14
    python -m astrarium.cli varstars --site jp-tokyo --days 7
    python -m astrarium.cli sites --search 岡山
    python -m astrarium.cli eclipse --site jp-tokyo --date 2035-09-02
"""
from __future__ import annotations

import argparse
import datetime
import sys

import numpy as np

from .ephemeris import Ephemeris
from .i18n import I18n
from .observer import SiteDB
from .timescale import Time


def _site(args, db):
    if args.lat is not None and args.lon is not None:
        from .observer import Site
        return Site(lat_deg=args.lat, lon_deg=args.lon,
                    elev_m=args.elev or 0.0, tz=args.tz or "UTC")
    return db.get(args.site or "jp-tokyo")


def _t0(args, site):
    if args.date:
        d = datetime.datetime.strptime(args.date, "%Y-%m-%d")
        return Time.from_local(d, site.tz)
    return Time.now()


def cmd_tonight(args):
    from .bodies import PLANETS, moon_info, observe_planet
    from .riseset import dark_windows, rise_set, twilight_times
    db = SiteDB()
    site = _site(args, db)
    eph = Ephemeris()
    i18n = I18n(args.lang)
    t = _t0(args, site)
    # normalize to local noon -> next noon
    local = t.datetime_local(site.tz).replace(hour=12, minute=0, second=0,
                                              microsecond=0)
    t0 = Time.from_local(local.replace(tzinfo=None), site.tz)
    t1 = t0 + 1.0

    def L(x):
        return x.iso_local(site.tz)[11:19]

    print(f"== {i18n.t('ui.tonight')} — {site.name(args.lang)} "
          f"({site.lat_deg:.4f}, {site.lon_deg:.4f}) "
          f"{local.strftime('%Y-%m-%d')} ==")
    sun = rise_set(eph, "sun", site, t0, t1)
    for e in sun.events:
        key = {"rise": "ui.sunrise", "set": "ui.sunset",
               "transit": "ui.transit"}[e.kind]
        print(f"  {i18n.t(key):<12} {L(e.time)}")
    tw = twilight_times(eph, site, t0, t1)
    for k in ("astronomical_dusk", "astronomical_dawn"):
        v = tw[k]
        label = i18n.t("twilight.astronomical") + " " + (
            i18n.t("ui.dusk") if "dusk" in k else i18n.t("ui.dawn"))
        print(f"  {label:<12} {L(v[0]) if v else i18n.t('ui.none')}")
    moon = rise_set(eph, "moon", site, t0, t1)
    for e in moon.events:
        key = {"rise": "ui.moonrise", "set": "ui.moonset",
               "transit": "ui.transit"}[e.kind]
        print(f"  {i18n.t(key):<12} {L(e.time)}")
    mi = moon_info(eph, t0 + 0.5)
    print(f"  {i18n.t('ui.moon_age')} {mi.age_days:.1f}  "
          f"{i18n.t('ui.illumination')} "
          f"{float(mi.illuminated_fraction) * 100:.0f}%  "
          f"({i18n.t('phase.' + mi.phase_key)})")
    for a, b in dark_windows(eph, site, t0, t1):
        print(f"  {i18n.t('ui.dark_time')}: {L(a)} - {L(b)}")
    print(f"  -- {i18n.t('ui.planets')} ({i18n.t('ui.now')}) --")
    tn = Time.now()
    for b in PLANETS:
        v = observe_planet(eph, b, tn, site)
        alt = float(np.atleast_1d(v.alt)[0])
        if alt > 0:
            print(f"  {i18n.t('body.' + b):<8} alt {alt:5.1f}°  az "
                  f"{float(np.atleast_1d(v.az)[0]):5.1f}°  "
                  f"{float(v.magnitude):+.1f} mag")


def cmd_riseset(args):
    from .riseset import rise_set
    db = SiteDB()
    site = _site(args, db)
    eph = Ephemeris()
    t = _t0(args, site)
    local = t.datetime_local(site.tz).replace(hour=0, minute=0, second=0,
                                              microsecond=0)
    t0 = Time.from_local(local.replace(tzinfo=None), site.tz)
    arc = rise_set(eph, args.body, site, t0, t0 + 1.0)
    for e in arc.events:
        print(f"{args.body} {e.kind:<8} {e.time.iso_local(site.tz)}"
              + (f"  az={e.az:.1f}" if e.az is not None else ""))
    if arc.always_up:
        print(f"{args.body}: always up (白夜)")
    if arc.always_down:
        print(f"{args.body}: always down (極夜)")


def cmd_scan(args):
    from .scanner import scan_events
    db = SiteDB()
    site = _site(args, db)
    eph = Ephemeris()
    i18n = I18n(args.lang)
    t0 = _t0(args, site)
    t1 = t0 + (args.days or 30)
    results = scan_events(eph, t0, t1, site)
    for r in results:
        name = i18n.event_name(r.kind, r.detail.get("kind"))
        body = i18n.t("body." + r.body) if ("body." + r.body) else r.body
        extra = ""
        if r.value is not None:
            extra = f"  ({r.value:.2f})"
        print(f"{r.time.iso_local(site.tz)}  {body:<6} {name}{extra}")
    if args.ics:
        from .export import to_ics
        to_ics(results, path=args.ics, lang=args.lang)
        print(f"-> {args.ics}")


def cmd_chart(args):
    from .catalog import DSOCatalog, StarCatalog
    from .chart import ChartOptions, render_allsky_svg
    db = SiteDB()
    site = _site(args, db)
    eph = Ephemeris()
    t = _t0(args, site) if args.date else Time.now()
    opts = ChartOptions(lang=args.lang, night_vision=args.night_vision,
                        mirror=args.mirror, monochrome=args.mono,
                        vmag_limit=args.mag_limit)
    svg = render_allsky_svg(eph, t, site, StarCatalog(), DSOCatalog(), opts)
    out = args.out or "chart.svg"
    with open(out, "w", encoding="utf-8") as f:
        f.write(svg)
    print(f"-> {out}")


def cmd_ephem(args):
    from .export import ephemeris_table, to_csv
    db = SiteDB()
    site = _site(args, db)
    eph = Ephemeris()
    t0 = _t0(args, site)
    rows = ephemeris_table(eph, args.body, t0, t0 + (args.days or 10),
                           args.step or 1.0, site=site)
    if args.csv:
        to_csv(rows, path=args.csv)
        print(f"-> {args.csv}")
    else:
        for r in rows:
            print("  ".join(f"{k}={v}" for k, v in r.items()))


def cmd_meteors(args):
    from .meteors import MeteorCalendar
    db = SiteDB()
    site = _site(args, db)
    eph = Ephemeris()
    i18n = I18n(args.lang)
    t0 = _t0(args, site)
    cal = MeteorCalendar()
    for ev in cal.peaks_between(eph, t0, t0 + (args.days or 90), site):
        name = ev.name_ja if args.lang == "ja" else ev.name_en
        print(f"{ev.peak.iso_local(site.tz)}  {name:<24} ZHR~{ev.zhr:.0f} "
              f"radiant_alt={ev.radiant_alt_at_peak:.0f}° "
              f"moon={ev.moon_condition}")


def cmd_transits(args):
    from .exoplanets import ExoplanetCatalog
    db = SiteDB()
    site = _site(args, db)
    eph = Ephemeris()
    t0 = _t0(args, site)
    for ev in ExoplanetCatalog().transits(eph, t0, t0 + (args.days or 14),
                                          site):
        if args.all or ev.observable:
            print(f"{ev.t_center.iso_local(site.tz)}  "
                  f"{ev.planet['name']:<14} "
                  f"BJD_TDB={ev.bjd_tdb_center:.5f} "
                  f"alt={ev.host_alt_center:.0f}° "
                  f"sun_alt={ev.sun_alt_center:.0f}°")


def cmd_varstars(args):
    from .varstars import VariableStarCatalog
    db = SiteDB()
    site = _site(args, db)
    eph = Ephemeris()
    t0 = _t0(args, site)
    for ev in VariableStarCatalog().events(eph, t0, t0 + (args.days or 7),
                                           site):
        nm = ev.star.get("name_ja") if args.lang == "ja" else None
        print(f"{ev.time.iso_local(site.tz)}  "
              f"{nm or ev.star['name']:<12} {ev.kind}  "
              f"alt={ev.alt_deg:.0f}°")


def cmd_mpc(args):
    from .mpc import SmallBodyRegistry
    reg = SmallBodyRegistry()
    if args.update:
        print("fetching MPC comets + SBDB bright asteroids ...")
        reg.update(limit=args.limit)
        print("fetched:", reg.fetched,
              f"({len(reg.comets)} comets, {len(reg.asteroids)} asteroids)")
    if args.search:
        for row in reg.search(args.search)[:40]:
            print(f"{row['id']:<14} {row['name']:<40} "
                  f"q={row['q_au']:.3f} e={row['e']:.3f}")
    elif not args.update:
        print(f"cached: {len(reg.comets)} comets, "
              f"{len(reg.asteroids)} asteroids; fetched {reg.fetched}")


def cmd_sites(args):
    db = SiteDB()
    for s in (db.search(args.search) if args.search else db.sites):
        code = f" [{s.mpc_code}]" if s.mpc_code else ""
        print(f"{s.id:<22} {s.name_ja}/{s.name_en}{code}  "
              f"({s.lat_deg:+.4f}, {s.lon_deg:+.4f}, {s.elev_m:.0f} m, "
              f"{s.tz})")


def cmd_eclipse(args):
    from .eclipses import (find_lunar_eclipses, find_solar_eclipses,
                           local_solar_eclipse)
    db = SiteDB()
    site = _site(args, db)
    eph = Ephemeris()
    t0 = _t0(args, site) - 2.0
    t1 = t0 + (args.days or 400)
    for e in find_solar_eclipses(eph, t0, t1):
        print(f"SOLAR  {e.t_max.iso_utc(0)} UT  {e.kind}  γ={e.gamma:+.4f}")
        loc = local_solar_eclipse(eph, site, e.t_max)
        if loc.max and loc.magnitude > 0:
            print(f"   at {site.name()}: {loc.kind} mag={loc.magnitude:.3f}"
                  f" max={loc.max.iso_local(site.tz)}"
                  + (f" C1={loc.c1.iso_local(site.tz)[11:19]}" if loc.c1 else "")
                  + (f" C4={loc.c4.iso_local(site.tz)[11:19]}" if loc.c4 else ""))
        else:
            print(f"   at {site.name()}: not visible")
    for e in find_lunar_eclipses(eph, t0, t1):
        print(f"LUNAR  {e.t_max.iso_utc(0)} UT  {e.kind}  "
              f"umbral_mag={e.umbral_magnitude:.3f}")
        for c in ("p1", "u1", "u2", "u3", "u4", "p4"):
            v = getattr(e, c)
            if v:
                print(f"   {c.upper()}  {v.iso_local(site.tz)}")


def main(argv=None):
    # ERFA emits "dubious year" warnings for dates far outside the
    # leap-second table; they are informational for interactive use and
    # intentionally NOT suppressed in library/test contexts.
    import warnings

    import erfa
    warnings.simplefilter("ignore", erfa.ErfaWarning)

    ap = argparse.ArgumentParser(prog="astrarium")
    ap.add_argument("--lang", default="ja", choices=["ja", "en"])
    sub = ap.add_subparsers(dest="cmd", required=True)

    def common(p):
        p.add_argument("--site", default="jp-tokyo")
        p.add_argument("--lat", type=float)
        p.add_argument("--lon", type=float)
        p.add_argument("--elev", type=float)
        p.add_argument("--tz")
        p.add_argument("--date")
        p.add_argument("--days", type=float)

    for name, fn in [("tonight", cmd_tonight), ("riseset", cmd_riseset),
                     ("scan", cmd_scan), ("chart", cmd_chart),
                     ("ephem", cmd_ephem), ("meteors", cmd_meteors),
                     ("transits", cmd_transits), ("varstars", cmd_varstars),
                     ("eclipse", cmd_eclipse)]:
        p = sub.add_parser(name)
        common(p)
        p.set_defaults(fn=fn)
        if name == "riseset":
            p.add_argument("--body", default="sun")
        if name == "scan":
            p.add_argument("--ics")
        if name == "ephem":
            p.add_argument("--body", default="mars")
            p.add_argument("--step", type=float, default=1.0)
            p.add_argument("--csv")
        if name == "chart":
            p.add_argument("--out")
            p.add_argument("--night-vision", action="store_true")
            p.add_argument("--mirror", action="store_true")
            p.add_argument("--mono", action="store_true")
            p.add_argument("--mag-limit", type=float, default=5.5)
        if name == "transits":
            p.add_argument("--all", action="store_true")

    p = sub.add_parser("sites")
    p.add_argument("--search")
    p.set_defaults(fn=cmd_sites)

    p = sub.add_parser("mpc")
    p.add_argument("--update", action="store_true",
                   help="fetch latest comets (MPC) & bright asteroids "
                        "(JPL SBDB) into data/mpc/")
    p.add_argument("--limit", type=int, default=1000)
    p.add_argument("--search", default="")
    p.set_defaults(fn=cmd_mpc)

    args = ap.parse_args(argv)
    args.fn(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
