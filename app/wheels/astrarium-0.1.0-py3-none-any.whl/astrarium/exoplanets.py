"""Exoplanet transit predictions (spec §2).

Ephemeris: T_c(n) = T0 + n·P in BJD_TDB (literature convention), then
converted to UTC/JST with the full Romer-delay inversion
(lighttime.time_from_bjd_tdb; verified < 1 ms vs astropy).  Host-star
visibility (altitude, twilight state, moon separation) is evaluated for
the observing site.
"""
from __future__ import annotations

import json
import math
import os
from dataclasses import dataclass

import numpy as np

from .ephemeris import Ephemeris
from .frames import angular_separation_deg, observe_body, observe_star
from .lighttime import time_from_bjd_tdb
from .observer import Site
from .timescale import Time

from .paths import data_path
_DATA = data_path("exoplanets_sample.json")


@dataclass
class TransitEvent:
    planet: dict
    n_epoch: int
    t_center: Time            # UTC-convertible Time (from BJD_TDB)
    t_ingress: Time
    t_egress: Time
    bjd_tdb_center: float
    # visibility (None if no site)
    host_alt_center: float | None = None
    sun_alt_center: float | None = None
    moon_sep_deg: float | None = None
    observable: bool | None = None


class ExoplanetCatalog:
    def __init__(self, path: str | None = None):
        with open(path or _DATA, encoding="utf-8") as f:
            self.planets = json.load(f)["planets"]

    def add(self, planet: dict):
        """Register a user planet: needs name, host_ra_deg, host_dec_deg,
        t0_bjd_tdb, period_days, duration_hours."""
        self.planets.append(planet)

    def transits(self, eph: Ephemeris, t0: Time, t1: Time,
                 site: Site | None = None, planet_names=None,
                 min_alt=20.0, max_sun_alt=-12.0) -> list[TransitEvent]:
        out = []
        for pl in self.planets:
            if planet_names and pl["name"] not in planet_names:
                continue
            P = pl["period_days"]
            dur = pl.get("duration_hours", 2.0) / 24.0
            ra, dec = pl["host_ra_deg"], pl["host_dec_deg"]
            # BJD bounds of the window (Romer inside ±8 min of jd_tdb)
            b0 = t0.jd_tdb - 0.01
            b1 = t1.jd_tdb + 0.01
            n0 = math.ceil((b0 - pl["t0_bjd_tdb"]) / P)
            n1 = math.floor((b1 - pl["t0_bjd_tdb"]) / P)
            for n in range(n0, n1 + 1):
                bjd_c = pl["t0_bjd_tdb"] + n * P
                tc = time_from_bjd_tdb(eph, bjd_c, ra, dec, site)
                if not (t0.jd_tt <= tc.jd_tt <= t1.jd_tt):
                    continue
                ev = TransitEvent(
                    planet=pl, n_epoch=n, t_center=tc,
                    t_ingress=tc - dur / 2, t_egress=tc + dur / 2,
                    bjd_tdb_center=bjd_c)
                if site is not None:
                    sp = observe_star(ra, dec, tc, site, refraction=False)
                    sun = observe_body(eph, "sun", tc, site,
                                       refraction=False)
                    moon = observe_body(eph, "moon", tc, site,
                                        refraction=False)
                    ev.host_alt_center = float(np.atleast_1d(sp.alt)[0])
                    ev.sun_alt_center = float(np.atleast_1d(sun.alt)[0])
                    ev.moon_sep_deg = float(np.atleast_1d(
                        angular_separation_deg(
                            sp.ra_apparent, sp.dec_apparent,
                            moon.ra_apparent, moon.dec_apparent))[0])
                    ev.observable = (ev.host_alt_center > min_alt
                                     and ev.sun_alt_center < max_sun_alt)
                out.append(ev)
        out.sort(key=lambda e: e.t_center.jd_tt)
        return out
