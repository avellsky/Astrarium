"""Planetary & lunar phenomena by direct root-finding on DE geometry.

Events (spec §2): conjunctions (inferior/superior), oppositions,
greatest elongations, stations (direct/retrograde), moon phases,
lunar perigee/apogee, equinoxes/solstices.

Method: every event is a root or extremum of a smooth function of time
(apparent geocentric ecliptic longitude differences, elongation angle,
distance, dλ/dt).  Coarse scan + bisection (riseset.find_crossings) to
<1 s.  No truncated series: accuracy inherited from the DE kernel.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .bodies import observe_planet
from .ephemeris import Ephemeris
from .frames import observe_body
from .riseset import find_crossings, _bisect
from .timescale import Time

INNER = ("mercury", "venus")


@dataclass
class Phenomenon:
    kind: str          # e.g. 'opposition', 'inferior_conjunction', ...
    body: str
    time: Time
    value: float = 0.0   # elongation [deg], distance [km], etc.
    note: str = ""


# ---------------------------------------------------------------------------
def _lambda_diff(eph, body, t0):
    """Apparent geocentric ecliptic longitude(body) - longitude(sun),
    wrapped to (-180, 180], as a vectorized function of day-offset."""
    def f(off):
        t = Time(t0.tt1, t0.tt2 + np.asarray(off))
        pb = observe_body(eph, body, t, site=None, refraction=False)
        ps = observe_body(eph, "sun", t, site=None, refraction=False)
        lb, _ = pb.ecliptic(apparent=True)
        ls, _ = ps.ecliptic(apparent=True)
        return (np.asarray(lb) - np.asarray(ls) + 180.0) % 360.0 - 180.0
    return f


def _elongation(eph, body, t0):
    def f(off):
        t = Time(t0.tt1, t0.tt2 + np.asarray(off))
        bv = observe_planet(eph, body, t, site=None, refraction=False)
        return np.atleast_1d(bv.elongation_deg)
    return f


def find_conjunctions_oppositions(eph: Ephemeris, body: str,
                                  t0: Time, t1: Time) -> list[Phenomenon]:
    """Conjunctions (Δλ=0) and oppositions (Δλ=180) with the Sun."""
    f = _lambda_diff(eph, body, t0)
    out = []
    for r, d in find_crossings(f, t0, t1, step_min=720.0):
        t = t0 + r
        bv = observe_planet(eph, body, t, site=None, refraction=False)
        dist = float(np.atleast_1d(bv.delta_au)[0])
        sun_d = float(np.atleast_1d(bv.r_sun_au)[0])
        if body in INNER:
            kind = ("inferior_conjunction" if dist < 1.0
                    else "superior_conjunction")
        else:
            kind = "conjunction"
        out.append(Phenomenon(kind, body, t, value=dist))
    # oppositions: root of wrapped (Δλ - 180)
    def g(off):
        return (f(off) - 180.0 + 180.0) % 360.0 - 180.0
    if body not in INNER:
        for r, d in find_crossings(g, t0, t1, step_min=720.0):
            t = t0 + r
            bv = observe_planet(eph, body, t, site=None, refraction=False)
            out.append(Phenomenon("opposition", body, t,
                                  value=float(np.atleast_1d(bv.magnitude)[0])))
    return sorted(out, key=lambda p: p.time.jd_tt)


def find_greatest_elongations(eph: Ephemeris, body: str,
                              t0: Time, t1: Time) -> list[Phenomenon]:
    """Greatest elongations of Mercury/Venus: extrema of elongation."""
    assert body in INNER
    f = _elongation(eph, body, t0)
    span = t1 - t0
    n = max(int(span / 0.5) + 1, 16)     # 12 h grid
    x = np.linspace(0.0, span, n)
    y = f(x)
    out = []
    dy = np.diff(y)
    for i in np.nonzero((dy[:-1] > 0) & (dy[1:] <= 0))[0]:
        # maximum bracketed in [x[i], x[i+2]] -> golden-section refine
        a, b = x[i], x[i + 2]
        for _ in range(50):
            m1 = a + 0.381966 * (b - a)
            m2 = b - 0.381966 * (b - a)
            if float(f(np.array([m1]))[0]) < float(f(np.array([m2]))[0]):
                a = m1
            else:
                b = m2
            if (b - a) < 1.0 / 86400.0:
                break
        t = t0 + 0.5 * (a + b)
        bv = observe_planet(eph, body, t, site=None, refraction=False)
        side = str(np.atleast_1d(bv.elongation_side)[0])
        out.append(Phenomenon(
            f"greatest_elongation_{'east' if side == 'E' else 'west'}",
            body, t, value=float(np.atleast_1d(bv.elongation_deg)[0])))
    return out


def find_stations(eph: Ephemeris, body: str, t0: Time, t1: Time,
                  ) -> list[Phenomenon]:
    """Stationary points: dλ/dt = 0 (apparent geocentric longitude)."""
    lam = _lambda_of(eph, body, t0)

    h = 0.02  # days, central difference
    def dlam(off):
        off = np.asarray(off)
        l1 = lam(off + h)
        l0 = lam(off - h)
        return ((l1 - l0 + 180.0) % 360.0 - 180.0) / (2 * h)

    out = []
    for r, d in find_crossings(dlam, t0, t1, step_min=1440.0):
        t = t0 + r
        out.append(Phenomenon(
            "station_retrograde" if d < 0 else "station_direct",
            body, t))
    return out


def _lambda_of(eph, body, t0):
    def f(off):
        t = Time(t0.tt1, t0.tt2 + np.asarray(off))
        p = observe_body(eph, body, t, site=None, refraction=False)
        l, _ = p.ecliptic(apparent=True)
        return np.asarray(l)
    return f


# ---------------------------------------------------------------------------
# Moon phases
# ---------------------------------------------------------------------------
PHASE_ANGLES = {0: ("new_moon", 0.0), 1: ("first_quarter", 90.0),
                2: ("full_moon", 180.0), 3: ("last_quarter", 270.0)}


def find_moon_phases(eph: Ephemeris, t0: Time, t1: Time) -> list[Phenomenon]:
    """朔弦望: Δλ(moon-sun) crossing 0/90/180/270 (apparent, geocentric)."""
    out = []
    for q, (name, ang) in PHASE_ANGLES.items():
        def f(off, ang=ang):
            t = Time(t0.tt1, t0.tt2 + np.asarray(off))
            pm = observe_body(eph, "moon", t, site=None, refraction=False)
            ps = observe_body(eph, "sun", t, site=None, refraction=False)
            lm, _ = pm.ecliptic(apparent=True)
            ls, _ = ps.ecliptic(apparent=True)
            return (np.asarray(lm) - np.asarray(ls) - ang + 180.0) \
                % 360.0 - 180.0
        for r, d in find_crossings(f, t0, t1, step_min=360.0):
            if d > 0:
                out.append(Phenomenon(name, "moon", t0 + r))
    return sorted(out, key=lambda p: p.time.jd_tt)


def previous_moon_phase(eph: Ephemeris, time: Time, quarter: int) -> Time:
    """Most recent phase (0=new,1=fq,2=full,3=lq) before `time`."""
    t0 = time - 31.0
    events = [p for p in find_moon_phases(eph, t0, time)
              if p.kind == PHASE_ANGLES[quarter][0]]
    return events[-1].time


def find_moon_apsides(eph: Ephemeris, t0: Time, t1: Time) -> list[Phenomenon]:
    """Lunar perigee/apogee: extrema of geocentric distance (d/dt = 0)."""
    def dist(off):
        t = Time(t0.tt1, t0.tt2 + np.asarray(off))
        p = observe_body(eph, "moon", t, site=None, refraction=False)
        return np.asarray(p.distance_au)

    h = 0.02
    def ddot(off):
        off = np.asarray(off)
        return dist(off + h) - dist(off - h)

    out = []
    from .constants import AU_KM
    for r, d in find_crossings(ddot, t0, t1, step_min=720.0):
        t = t0 + r
        km = float(np.atleast_1d(dist(np.array([r])))[0]) * AU_KM
        out.append(Phenomenon("moon_perigee" if d > 0 else "moon_apogee",
                              "moon", t, value=km))
    return out


# ---------------------------------------------------------------------------
def find_seasons(eph: Ephemeris, t0: Time, t1: Time) -> list[Phenomenon]:
    """Equinoxes/solstices: apparent sun longitude = 0/90/180/270."""
    names = {0: "march_equinox", 90: "june_solstice",
             180: "september_equinox", 270: "december_solstice"}
    lam = _lambda_of(eph, "sun", t0)
    out = []
    for ang, name in names.items():
        def f(off, ang=ang):
            return (lam(off) - ang + 180.0) % 360.0 - 180.0
        for r, d in find_crossings(f, t0, t1, step_min=1440.0):
            if d > 0:
                out.append(Phenomenon(name, "sun", t0 + r))
    return sorted(out, key=lambda p: p.time.jd_tt)
