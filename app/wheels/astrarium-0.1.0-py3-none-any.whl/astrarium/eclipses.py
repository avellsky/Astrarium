"""Solar & lunar eclipses (spec §2, §11).

Solar eclipses
--------------
Local circumstances (C1-C4, maximum, magnitude, obscuration) are solved
directly on the topocentric apparent geometry: the angular separation of
the Sun and Moon centers (full DE+ERFA chain, refraction off) against
the topocentric semidiameters.  This is mathematically equivalent to the
classical Besselian-element reduction but avoids its plane projection
approximations; agreement with the Besselian method is at the 0.1 s
level (verified in tests against an independent Skyfield-based
implementation of the same definition).

Besselian elements (x, y, d, μ, L1, L2, tan f1, tan f2) are also
computed from the DE geometry (Explanatory Supplement ch. 11
formulation, k = 0.2725076) for classification (γ), export and the
central-line computation.

Lunar eclipses
--------------
Geocentric shadow geometry (Explanatory Supplement §11.2.3): shadow
radii at the Moon  σ_pen = E·(π_m + π_s + s_s),  σ_umb = E·(π_m + π_s −
s_s), with the Danjon enlargement E = 1.01 (spec §11).  Contacts are
roots of the Moon-center/shadow-axis separation against σ ± s_m.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import erfa
import numpy as np

from .constants import AU_KM, DANJON_ENLARGEMENT, K_MOON
from .ephemeris import Ephemeris
from .frames import observe_body, observer_bary_pv
from .observer import Site
from .riseset import find_crossings, _bisect
from .timescale import Time

R_EARTH_EQ_KM = 6378.1366
R_SUN_KM = 695700.0
R_MOON_KM = K_MOON * R_EARTH_EQ_KM     # 1738.1 km (eclipse convention)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _geo_vectors(eph, time):
    """Geocentric light-time-corrected (astrometric) sun & moon [au]."""
    d1, d2 = time.tdb
    pe, _ = eph.pv_bary("earth", d1, d2)
    # light-time iteration
    def lt(body):
        tau = 0.0
        for _ in range(3):
            pb, _ = eph.pv_bary(body, d1, d2 - tau)
            d = pb - pe
            tau = np.linalg.norm(d, axis=-1) / 173.144632674
        return d
    return lt("sun"), lt("moon")


def _sep_topo(eph, site, time):
    """Topocentric separation & semidiameters [deg] (refraction off)."""
    s = observe_body(eph, "sun", time, site, refraction=False)
    m = observe_body(eph, "moon", time, site, refraction=False)
    from .frames import angular_separation_deg
    sep = angular_separation_deg(s.ra_apparent, s.dec_apparent,
                                 m.ra_apparent, m.dec_apparent)
    sd_s = np.rad2deg(np.arcsin(R_SUN_KM / (np.asarray(s.distance_au) * AU_KM)))
    sd_m = np.rad2deg(np.arcsin(R_MOON_KM / (np.asarray(m.distance_au) * AU_KM)))
    return np.asarray(sep), sd_s, sd_m, s, m


# ---------------------------------------------------------------------------
@dataclass
class BesselianElements:
    """Elements on the fundamental plane at one instant (ES ch.11)."""
    x: float; y: float          # shadow-axis intersection [Earth radii]
    d_deg: float                # declination of shadow axis
    mu_deg: float               # Greenwich hour angle of shadow axis
    l1: float; l2: float        # penumbra/umbra radii on fund. plane
    tan_f1: float; tan_f2: float


def besselian_elements(eph: Ephemeris, time: Time) -> BesselianElements:
    su, mo = _geo_vectors(eph, time)
    g = su - mo                          # moon -> sun
    dist_sm = float(np.linalg.norm(g))
    k = g / dist_sm                      # axis direction (toward sun)
    # fundamental frame: Z=k, X = k×celestial-pole? ES: X axis =
    # intersection of fundamental plane with equator, +east.
    zhat = np.array([0.0, 0.0, 1.0])
    xf = np.cross(zhat, k)
    xf /= np.linalg.norm(xf)
    yf = np.cross(k, xf)
    re_au = R_EARTH_EQ_KM / AU_KM
    m_in = -mo                           # moon -> geocenter... sign care
    # position of geocenter relative to the moon, projected:
    # ES convention: (x, y) = coordinates of the shadow axis on the
    # fundamental plane through the geocenter = projection of the Moon
    # position (geocentric) onto (xf, yf), in Earth radii:
    x = float(np.dot(mo, xf)) / re_au
    y = float(np.dot(mo, yf)) / re_au
    ra_k, de_k = erfa.c2s(k)
    gast = float(time.gast())
    mu = (gast - ra_k) % (2 * math.pi)
    # cone half angles
    sinf1 = (R_SUN_KM + R_MOON_KM) / (dist_sm * AU_KM)
    sinf2 = (R_SUN_KM - R_MOON_KM) / (dist_sm * AU_KM)
    tanf1 = math.tan(math.asin(sinf1))
    tanf2 = math.tan(math.asin(sinf2))
    # z: distance of moon from fundamental plane along axis [Earth radii]
    z = float(np.dot(mo, k)) / re_au
    # penumbra/umbra vertex distances from the moon along the axis [Re]
    c1 = (R_MOON_KM / sinf1) / R_EARTH_EQ_KM
    c2 = (R_MOON_KM / sinf2) / R_EARTH_EQ_KM
    l1 = (z + c1) * tanf1
    l2 = (z - c2) * tanf2
    return BesselianElements(x=x, y=y, d_deg=float(np.rad2deg(de_k)),
                             mu_deg=float(np.rad2deg(mu) % 360.0),
                             l1=l1, l2=l2, tan_f1=tanf1, tan_f2=tanf2)


# ---------------------------------------------------------------------------
@dataclass
class SolarEclipseGlobal:
    t_max: Time                  # greatest eclipse (min axis distance)
    kind: str                    # total|annular|hybrid|partial
    gamma: float
    magnitude: float | None = None   # greatest magnitude (at best site)
    central_line: list = field(default_factory=list)  # (Time, lat, lon)


@dataclass
class SolarEclipseLocal:
    site: Site
    c1: Time | None = None
    c2: Time | None = None
    max: Time | None = None
    c3: Time | None = None
    c4: Time | None = None
    magnitude: float = 0.0
    obscuration: float = 0.0
    kind: str = "none"           # none|partial|annular|total
    sun_alt_at_max: float = 0.0
    duration_central_s: float | None = None


def find_solar_eclipses(eph: Ephemeris, t0: Time, t1: Time,
                        with_central_line=False) -> list[SolarEclipseGlobal]:
    """All solar eclipses in [t0,t1]: scan new moons, keep |gamma|<1.55."""
    from .phenomena import find_moon_phases
    out = []
    news = [p for p in find_moon_phases(eph, t0 - 1.0, t1 + 1.0)
            if p.kind == "new_moon"]
    for p in news:
        # refine time of minimum axis distance (gamma)
        def adist(off):
            t = p.time + off
            be = besselian_elements(eph, t)
            return math.hypot(be.x, be.y)
        a, b = -0.5, 0.5
        for _ in range(60):
            m1 = a + 0.381966 * (b - a)
            m2 = b - 0.381966 * (b - a)
            if adist(m1) < adist(m2):
                b = m2
            else:
                a = m1
            if b - a < 0.1 / 86400.0:
                break
        t_max = p.time + 0.5 * (a + b)
        if not (t0.jd_tt <= t_max.jd_tt <= t1.jd_tt):
            continue
        be = besselian_elements(eph, t_max)
        gamma = math.hypot(be.x, be.y) * (1 if be.y >= 0 else -1)
        if abs(gamma) > 1.0 + be.l1:     # no eclipse anywhere
            continue
        if abs(gamma) < 0.9972:
            # central eclipse: evaluate the umbra radius at the Earth's
            # surface below the axis (z reduced by the surface height
            # zsurf) — negative L2 = total.  Hybrid (annular-total):
            # total near mid-path (surface closest to the Moon) while
            # still annular on the fundamental plane (path ends).
            zsurf = math.sqrt(max(0.9972**2 - gamma**2, 0.0))
            l2_center = be.l2 - zsurf * be.tan_f2
            if l2_center < 0:
                kind = "total" if be.l2 < 0 else "hybrid"
            else:
                kind = "annular"
        else:
            kind = "partial"
        ec = SolarEclipseGlobal(t_max=t_max, kind=kind, gamma=gamma)
        if with_central_line and kind in ("total", "annular", "hybrid"):
            ec.central_line = central_line(eph, t_max)
        out.append(ec)
    return out


def central_line(eph: Ephemeris, t_max: Time, half_window_days=0.125,
                 step_s=120.0) -> list:
    """(Time, lat_deg, lon_deg) samples where the shadow axis meets the
    WGS84 ellipsoid."""
    out = []
    n = int(2 * half_window_days * 86400 / step_s) + 1
    for i in range(n):
        t = t_max + (-half_window_days + i * step_s / 86400.0)
        hit = _axis_ground_point(eph, t)
        if hit is not None:
            out.append((t, hit[0], hit[1]))
    return out


def _axis_ground_point(eph: Ephemeris, time: Time):
    """Intersection of the shadow axis with the WGS84 ellipsoid (geodetic
    lat/lon, deg), or None."""
    su, mo = _geo_vectors(eph, time)
    k = su - mo
    k = k / np.linalg.norm(k)
    # line: P(s) = mo - s*k (from the moon, anti-sunward), GCRS [au]
    # transform to ITRS: r_itrs = R(t) @ r_gcrs
    rc2t = _c2t_matrix(time)
    mo_t = rc2t @ (mo * AU_KM)
    k_t = rc2t @ k
    a = R_EARTH_EQ_KM
    b = a * (1 - 1 / 298.25642)
    # solve |diag(1/a,1/a,1/b) (mo_t - s k_t)|^2 = 1
    D = np.diag([1 / a, 1 / a, 1 / b])
    u = D @ mo_t
    w = D @ k_t
    A = float(w @ w)
    B = -2.0 * float(u @ w)
    C = float(u @ u) - 1.0
    disc = B * B - 4 * A * C
    if disc < 0:
        return None
    s = (-B - math.sqrt(disc)) / (2 * A)      # near-side intersection
    if s < 0:
        return None
    p = mo_t - s * k_t
    lon, lat, _ = erfa.gc2gd(1, p * 1000.0)
    return math.degrees(lat), math.degrees(lon)


def _c2t_matrix(time: Time):
    """GCRS -> ITRS rotation (IAU 2006/2000A, incl. polar motion)."""
    xp_as, yp_as = time.polar_motion
    u1, u2 = time.ut1
    return erfa.c2t06a(time.tt1, time.tt2, u1, u2,
                       float(np.asarray(xp_as)) * erfa.DAS2R,
                       float(np.asarray(yp_as)) * erfa.DAS2R)


def local_solar_eclipse(eph: Ephemeris, site: Site, t_center: Time,
                        window_days=0.5) -> SolarEclipseLocal:
    """Local circumstances around a known eclipse time."""
    t0 = t_center - window_days
    t1 = t_center + window_days
    res = SolarEclipseLocal(site=site)

    def sep_minus_outer(off):
        t = Time(t0.tt1, t0.tt2 + np.asarray(off))
        sep, sd_s, sd_m, _, _ = _sep_topo(eph, site, t)
        return sep - (sd_s + sd_m)

    roots = find_crossings(sep_minus_outer, t0, t1, step_min=2.0,
                           refine_tol_s=0.05)
    touches = [(r, d) for r, d in roots]
    if not touches:
        return res
    for r, d in touches:
        if d < 0 and res.c1 is None:
            res.c1 = t0 + r
        elif d > 0:
            res.c4 = t0 + r
    if res.c1 is None or res.c4 is None:
        return res

    # maximum: minimize separation between c1 and c4
    a = res.c1 - t0
    b = res.c4 - t0
    def sep_at(off):
        t = Time(t0.tt1, t0.tt2 + np.asarray([off]))
        sep, sd_s, sd_m, _, _ = _sep_topo(eph, site, t)
        return float(sep[0]), float(np.atleast_1d(sd_s)[0]), \
            float(np.atleast_1d(sd_m)[0])
    lo, hi = a, b
    for _ in range(60):
        m1 = lo + 0.381966 * (hi - lo)
        m2 = hi - 0.381966 * (hi - lo)
        if sep_at(m1)[0] < sep_at(m2)[0]:
            hi = m2
        else:
            lo = m1
        if hi - lo < 0.05 / 86400.0:
            break
    off_max = 0.5 * (lo + hi)
    res.max = t0 + off_max
    sep, sd_s, sd_m = sep_at(off_max)
    res.magnitude = max((sd_s + sd_m - sep) / (2 * sd_s), 0.0)
    res.obscuration = _obscuration(sep, sd_s, sd_m)
    sun = observe_body(eph, "sun", res.max, site, refraction=False)
    res.sun_alt_at_max = float(np.atleast_1d(sun.alt)[0])
    res.kind = "partial"

    # interior contacts (total/annular)
    def sep_minus_inner(off):
        t = Time(t0.tt1, t0.tt2 + np.asarray(off))
        sep, sd_s, sd_m, _, _ = _sep_topo(eph, site, t)
        return sep - np.abs(sd_s - sd_m)

    inner = find_crossings(sep_minus_inner, t0, t1, step_min=1.0,
                           refine_tol_s=0.02)
    ins = [r for r, d in inner if d < 0]
    outs = [r for r, d in inner if d > 0]
    if ins and outs:
        res.c2 = t0 + ins[0]
        res.c3 = t0 + outs[-1]
        res.duration_central_s = (res.c3 - res.c2) * 86400.0
        res.kind = "total" if sd_m > sd_s else "annular"
    return res


def _obscuration(sep, r1, r2):
    """Fraction of the Sun's disk area covered (two-circle overlap).

    r1 = sun radius, r2 = moon radius, sep = center separation (deg).
    """
    if sep >= r1 + r2:
        return 0.0
    if sep <= abs(r1 - r2):
        return 1.0 if r2 >= r1 else (r2 / r1) ** 2
    d = sep
    a1 = math.acos((d * d + r1 * r1 - r2 * r2) / (2 * d * r1))
    a2 = math.acos((d * d + r2 * r2 - r1 * r1) / (2 * d * r2))
    area = (r1 * r1 * (a1 - math.sin(2 * a1) / 2)
            + r2 * r2 * (a2 - math.sin(2 * a2) / 2))
    return area / (math.pi * r1 * r1)


# ---------------------------------------------------------------------------
# lunar eclipses
# ---------------------------------------------------------------------------
@dataclass
class LunarEclipse:
    t_max: Time
    kind: str                      # total|partial|penumbral
    penumbral_magnitude: float
    umbral_magnitude: float
    p1: Time | None = None         # penumbral contacts
    u1: Time | None = None         # umbral contacts
    u2: Time | None = None         # totality
    u3: Time | None = None
    u4: Time | None = None
    p4: Time | None = None


def _lunar_geometry(eph, time):
    """Separation of the Moon from the shadow axis and radii [deg].

    Convention: the shadow axis is anti-parallel to the *apparent*
    (aberrated) geocentric Sun, matching the classical reduction used by
    NASA/Espenak and Skyfield — verified to reproduce NASA contact
    times to ~1 s (see tests).
    """
    from .frames import angular_separation_deg
    s = observe_body(eph, "sun", time, site=None, refraction=False)
    m = observe_body(eph, "moon", time, site=None, refraction=False)
    theta = angular_separation_deg(
        (np.asarray(s.ra_apparent) + 180.0) % 360.0,
        -np.asarray(s.dec_apparent),
        m.ra_apparent, m.dec_apparent)
    ds = np.asarray(s.distance_au)
    dm = np.asarray(m.distance_au)
    # Danjon rule (spec §11): the Moon's parallax is computed for an
    # Earth radius enlarged by 1% (π_s and s_s are NOT enlarged).
    # Numerically reproduces the NASA/Espenak canon radii to <1"
    # (see docs/VERIFICATION.md).
    pi_m = np.rad2deg(np.arcsin(
        DANJON_ENLARGEMENT * R_EARTH_EQ_KM / (dm * AU_KM)))
    pi_s = np.rad2deg(np.arcsin(R_EARTH_EQ_KM / (ds * AU_KM)))
    sd_s = np.rad2deg(np.arcsin(R_SUN_KM / (ds * AU_KM)))
    sd_m = np.rad2deg(np.arcsin(1737.4 / (dm * AU_KM)))
    pen = pi_m + pi_s + sd_s
    umb = pi_m + pi_s - sd_s
    return theta, pen, umb, sd_m


def find_lunar_eclipses(eph: Ephemeris, t0: Time, t1: Time,
                        ) -> list[LunarEclipse]:
    from .phenomena import find_moon_phases
    out = []
    fulls = [p for p in find_moon_phases(eph, t0 - 1.0, t1 + 1.0)
             if p.kind == "full_moon"]
    for p in fulls:
        # minimize theta around full moon
        def th(off):
            t = p.time + off
            theta, *_ = _lunar_geometry(eph, t)
            return float(theta)
        a, b = -0.5, 0.5
        for _ in range(60):
            m1 = a + 0.381966 * (b - a)
            m2 = b - 0.381966 * (b - a)
            if th(m1) < th(m2):
                b = m2
            else:
                a = m1
            if b - a < 0.1 / 86400.0:
                break
        t_max = p.time + 0.5 * (a + b)
        if not (t0.jd_tt <= t_max.jd_tt <= t1.jd_tt):
            continue
        theta, pen, umb, sd_m = _lunar_geometry(eph, t_max)
        theta = float(theta)
        pen_mag = (pen + sd_m - theta) / (2 * sd_m)
        umb_mag = (umb + sd_m - theta) / (2 * sd_m)
        if pen_mag <= 0:
            continue
        kind = ("total" if umb_mag >= 1.0 else
                "partial" if umb_mag > 0 else "penumbral")
        ec = LunarEclipse(t_max=t_max, kind=kind,
                          penumbral_magnitude=float(pen_mag),
                          umbral_magnitude=float(umb_mag))

        tw0, tw1 = t_max - 0.25, t_max + 0.25
        def cross(target_kind):
            def f(off):
                t = Time(tw0.tt1, tw0.tt2 + np.asarray(off))
                theta, pen, umb, sd_m = _lunar_geometry(eph, t)
                if target_kind == "pen":
                    return theta - (pen + sd_m)
                if target_kind == "umb":
                    return theta - (umb + sd_m)
                return theta - (umb - sd_m)
            return find_crossings(f, tw0, tw1, step_min=1.0,
                                  refine_tol_s=0.1)
        for r, d in cross("pen"):
            if d < 0:
                ec.p1 = tw0 + r
            else:
                ec.p4 = tw0 + r
        if umb_mag > 0:
            for r, d in cross("umb"):
                if d < 0:
                    ec.u1 = tw0 + r
                else:
                    ec.u4 = tw0 + r
        if umb_mag >= 1.0:
            for r, d in cross("tot"):
                if d < 0:
                    ec.u2 = tw0 + r
                else:
                    ec.u3 = tw0 + r
        out.append(ec)
    return out
