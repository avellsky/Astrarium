"""Occultations (spec §2): lunar occultations of stars/planets, grazes,
and occultations of stars by asteroids.

Lunar occultations
------------------
Direct topocentric geometry: root-solve the separation between the
Moon's center and the target against the Moon's topocentric
semidiameter (mean limb; Watts/LRO limb corrections are out of scope
and documented — they contribute up to ±2" ≈ ±4 s).  Events carry the
position angle (N through E) and the sunlit/dark limb flag.

Asteroid occultations
---------------------
The shadow of the asteroid (cylinder of the star's light) is tracked
across the Earth: ground track, predicted duration from the assumed
diameter and shadow velocity, and magnitude drop.  Elements are
two-body (orbits.py); for refined predictions use fresh MPC/JPL
elements near the event epoch (documented accuracy in orbits.py).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import erfa
import numpy as np

from .constants import AU_KM
from .ephemeris import Ephemeris
from .frames import (angular_separation_deg, observe_body, observe_star,
                     position_angle_deg)
from .observer import Site
from .orbits import Elements, observe_elements
from .riseset import find_crossings
from .timescale import Time


@dataclass
class OccultationEvent:
    kind: str              # 'immersion' | 'emersion' | 'graze_min'
    time: Time
    pa_deg: float          # position angle of the event point on the limb
    target_alt_deg: float
    moon_illum: float
    dark_limb: bool        # event occurs at the unlit limb (visual!)
    note: str = ""


def moon_semidiameter_topo_deg(eph, time, site):
    m = observe_body(eph, "moon", time, site, refraction=False)
    return np.rad2deg(np.arcsin(
        1737.4 / (np.asarray(m.distance_au) * AU_KM))), m


def lunar_occultation(eph: Ephemeris, site: Site, ra_deg, dec_deg,
                      t0: Time, t1: Time, pmra=0.0, pmdec=0.0,
                      parallax_mas=0.0) -> list[OccultationEvent]:
    """Immersion/emersion (or graze) of a fixed target for one site."""
    def sep_minus_sd(off):
        t = Time(t0.tt1, t0.tt2 + np.asarray(off))
        sd, m = moon_semidiameter_topo_deg(eph, t, site)
        s = observe_star(ra_deg, dec_deg, t, site, refraction=False,
                         pmra_mas_yr=pmra, pmdec_mas_yr=pmdec,
                         parallax_mas=parallax_mas)
        sep = angular_separation_deg(m.ra_apparent, m.dec_apparent,
                                     s.ra_apparent, s.dec_apparent)
        return np.asarray(sep) - np.asarray(sd)

    events = []
    for r, d in find_crossings(sep_minus_sd, t0, t1, step_min=2.0,
                               refine_tol_s=0.05):
        t = t0 + r
        sd, m = moon_semidiameter_topo_deg(eph, t, site)
        s = observe_star(ra_deg, dec_deg, t, site, refraction=False,
                         pmra_mas_yr=pmra, pmdec_mas_yr=pmdec,
                         parallax_mas=parallax_mas)
        pa = position_angle_deg(float(np.atleast_1d(m.ra_apparent)[0]),
                                float(np.atleast_1d(m.dec_apparent)[0]),
                                float(np.atleast_1d(s.ra_apparent)[0]),
                                float(np.atleast_1d(s.dec_apparent)[0]))
        from .bodies import moon_info
        mi = moon_info(eph, t, site)
        # dark limb: angular distance between event PA and bright-limb PA
        dpa = abs((pa - mi.bright_limb_pa_deg + 180) % 360 - 180)
        events.append(OccultationEvent(
            kind="immersion" if d < 0 else "emersion",
            time=t, pa_deg=pa,
            target_alt_deg=float(np.atleast_1d(s.alt)[0]),
            moon_illum=float(np.atleast_1d(mi.illuminated_fraction)[0]),
            dark_limb=dpa > 90.0))
    return events


def scan_lunar_occultations(eph: Ephemeris, site: Site, stars: list,
                            t0: Time, t1: Time,
                            min_alt_deg=0.0) -> list[dict]:
    """Search occultations of catalog stars.

    stars: iterable of dicts with ra_deg, dec_deg (ICRS J2000),
    optionally pmra_mas_yr/pmdec_mas_yr/vmag/name.
    Prefilter: geocentric separation < 1.0° sampled every 20 min
    (moon moves 0.18°/20 min; SD+parallax < 1.27°... margin generous).
    """
    out = []
    span = t1 - t0
    n = max(int(span * 72) + 1, 8)          # 20-min grid
    offs = np.linspace(0.0, span, n)
    times = Time(t0.tt1, t0.tt2 + offs)
    mgeo = observe_body(eph, "moon", times, site=None, refraction=False)
    mra = np.atleast_1d(mgeo.ra_apparent)
    mde = np.atleast_1d(mgeo.dec_apparent)
    for st in stars:
        sep = angular_separation_deg(mra, mde,
                                     st["ra_deg"], st["dec_deg"])
        if np.min(sep) > 1.35:
            continue
        i = int(np.argmin(sep))
        w0 = Time(t0.tt1, t0.tt2 + max(offs[i] - 0.15, 0.0))
        w1 = Time(t0.tt1, t0.tt2 + min(offs[i] + 0.15, span))
        evs = lunar_occultation(eph, site, st["ra_deg"], st["dec_deg"],
                                w0, w1,
                                pmra=st.get("pmra_mas_yr", 0.0),
                                pmdec=st.get("pmdec_mas_yr", 0.0))
        evs = [e for e in evs if e.target_alt_deg > min_alt_deg]
        if evs:
            out.append({"star": st, "events": evs})
    return out


# ---------------------------------------------------------------------------
@dataclass
class AsteroidOccultation:
    star: dict
    t_closest: Time
    min_sep_arcsec: float          # geocentric
    duration_s: float | None      # central duration for given diameter
    mag_drop: float | None
    ground_track: list = field(default_factory=list)  # (Time, lat, lon)
    shadow_velocity_km_s: float | None = None


def asteroid_occultation_search(eph: Ephemeris, el: Elements, star: dict,
                                t0: Time, t1: Time,
                                diameter_km: float | None = None,
                                asteroid_mag=None) -> list[AsteroidOccultation]:
    """Geocentric close approaches of an asteroid to one star, with
    shadow-track prediction for near misses (< 15" ≈ Earth radius at
    1 au is ~9"; threshold covers grazing geometry)."""
    def sep(off):
        t = Time(t0.tt1, t0.tt2 + np.asarray(off))
        bv = observe_elements(eph, el, t, site=None, refraction=False)
        return angular_separation_deg(
            np.asarray(bv.position.ra_icrs),
            np.asarray(bv.position.dec_icrs),
            star["ra_deg"], star["dec_deg"]) * 3600.0

    span = t1 - t0
    n = max(int(span * 24) + 1, 8)      # 1-hour grid
    x = np.linspace(0, span, n)
    y = np.array([float(sep(np.array([xi]))[0]) for xi in x])
    out = []
    for i in range(1, n - 1):
        if y[i] <= y[i - 1] and y[i] <= y[i + 1] and y[i] < 3600.0:
            a, b = x[i - 1], x[i + 1]
            for _ in range(60):
                m1 = a + 0.381966 * (b - a)
                m2 = b - 0.381966 * (b - a)
                if float(sep(np.array([m1]))[0]) < float(sep(np.array([m2]))[0]):
                    b = m2
                else:
                    a = m1
                if b - a < 0.05 / 86400:
                    break
            tc = t0 + 0.5 * (a + b)
            smin = float(sep(np.array([0.5 * (a + b)]))[0])
            # Earth angular radius as seen from the asteroid:
            bv = observe_elements(eph, el, tc, site=None, refraction=False)
            delta_km = float(np.atleast_1d(bv.delta_au)[0]) * AU_KM
            earth_ang = math.degrees(6378.14 / delta_km) * 3600
            if smin > earth_ang + 2.0:
                continue
            occ = AsteroidOccultation(
                star=star, t_closest=tc, min_sep_arcsec=smin,
                duration_s=None, mag_drop=None)
            _shadow_track(eph, el, star, occ, diameter_km)
            if asteroid_mag is not None and "vmag" in star:
                combined = -2.5 * math.log10(
                    10 ** (-0.4 * star["vmag"])
                    + 10 ** (-0.4 * asteroid_mag))
                occ.mag_drop = (asteroid_mag - combined
                                if asteroid_mag else None)
            elif "vmag" in star:
                m_ast = float(np.atleast_1d(bv.magnitude)[0])
                if np.isfinite(m_ast):
                    combined = -2.5 * math.log10(
                        10 ** (-0.4 * star["vmag"])
                        + 10 ** (-0.4 * m_ast))
                    occ.mag_drop = m_ast - combined
            out.append(occ)
    return out


def _shadow_track(eph, el, star, occ: AsteroidOccultation, diameter_km):
    """Ground track of the star-shadow of the asteroid around t_closest."""
    from .frames import observer_bary_pv
    from .eclipses import _c2t_matrix
    n = _unit_radec(star["ra_deg"], star["dec_deg"])
    track = []
    prev = None
    v_shadow = None
    for k in range(-40, 41):
        t = occ.t_closest + k * 15.0 / 86400.0     # 15-s steps
        d1, d2 = t.tdb
        pe, _ = eph.pv_bary("earth", d1, d2)
        pa_h, _ = el.state_icrs(d1 + d2)
        ps, _ = eph.pv_bary("sun", d1, d2)
        pa = ps + pa_h                              # asteroid barycentric
        # shadow line: through asteroid, direction -n (from star)
        rel = (pa - pe) * AU_KM                     # geocentric, km
        rc2t = _c2t_matrix(t)
        p0 = rc2t @ rel
        dvec = rc2t @ (-n)
        hit = _ellipsoid_hit(p0, dvec)
        if hit is not None:
            lon, lat, _ = erfa.gc2gd(1, hit * 1000.0)
            track.append((t, math.degrees(lat), math.degrees(lon)))
            if prev is not None and v_shadow is None:
                v_shadow = np.linalg.norm(hit - prev) / 15.0
            prev = hit
    occ.ground_track = track
    if v_shadow and diameter_km:
        occ.shadow_velocity_km_s = float(v_shadow)
        occ.duration_s = diameter_km / float(v_shadow)


def _unit_radec(ra_deg, dec_deg):
    ra, dec = math.radians(ra_deg), math.radians(dec_deg)
    return np.array([math.cos(dec) * math.cos(ra),
                     math.cos(dec) * math.sin(ra), math.sin(dec)])


def _ellipsoid_hit(p0_km, d_unit):
    a = 6378.1366
    b = a * (1 - 1 / 298.25642)
    D = np.diag([1 / a, 1 / a, 1 / b])
    u = D @ p0_km
    w = D @ d_unit
    A = float(w @ w)
    B = 2.0 * float(u @ w)
    C = float(u @ u) - 1.0
    disc = B * B - 4 * A * C
    if disc < 0:
        return None
    s = (-B - math.sqrt(disc)) / (2 * A)
    if s < 0:
        return None
    return p0_km + s * d_unit
